import { createClient } from 'https://esm.sh/@supabase/supabase-js@2';

const corsHeaders = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Headers': 'authorization, x-client-info, apikey, content-type',
  'Access-Control-Allow-Methods': 'POST, OPTIONS',
};

Deno.serve(async (req) => {
  if (req.method === 'OPTIONS') return new Response('ok', { headers: corsHeaders });

  try {
    const { imageUrl, mode } = await req.json();
    const apiKey = Deno.env.get('ONSPACE_AI_API_KEY');
    const baseUrl = Deno.env.get('ONSPACE_AI_BASE_URL');

    // Improved prompts for accurate BUY/SELL detection and result reading
    const systemPrompt = mode === 'result'
      ? `You are a professional forex trading result analyst. Look at this TradingView screenshot showing a completed trade.

TASK: Extract the trade result information.

Look for:
- Green/profit = WIN, Red/loss = LOSS
- Pips gained or lost (look for "+X pips" or "-X pips" text, or calculate from entry vs close price)
- Result indication (checkmark, profit indicator, etc.)

Respond ONLY with valid JSON, no other text:
{"result": "win", "pips": "+45", "notes": "Target hit at resistance level"}

Rules:
- result must be exactly "win" or "loss"  
- pips: use "+" prefix for win (e.g. "+45"), "-" prefix for loss (e.g. "-20")
- If values unclear, use empty string ""
- NEVER add text outside the JSON`
      : `You are an expert TradingView chart analyst. Analyze this forex/gold/crypto signal screenshot.

TASK: Extract ALL trading signal parameters with HIGH ACCURACY.

CRITICAL RULES FOR DIRECTION DETECTION:
- If you see a BUY arrow (↑ upward green arrow), or "Long", or price going up = direction is "BUY"
- If you see a SELL arrow (↓ downward red arrow), or "Short", or price going down = direction is "SELL"  
- Look for order block labels, entry labels, and arrow colors
- Green arrow/label = BUY, Red arrow/label = SELL
- If entry > take_profit (price going down) = SELL
- If entry < take_profit (price going up) = BUY
- DOUBLE CHECK: Does the stop_loss make sense for the direction?
  - BUY: stop_loss MUST be BELOW entry price
  - SELL: stop_loss MUST be ABOVE entry price

EXTRACT:
1. pair: The exact trading pair (e.g. "EUR/USD", "XAU/USD", "XAUUSD", "BTC/USDT")
2. direction: "BUY" or "SELL" (use the rules above carefully)
3. type: "forex" (for currency pairs), "gold" (for XAU, GOLD), or "crypto" (for BTC, ETH, etc.)
4. entry: Entry price as exact number
5. stop_loss: Stop loss price  
6. take_profit: Take profit price (use first TP if multiple)
7. notes: Brief analysis (max 15 words)

Respond ONLY with valid JSON, no other text:
{"pair": "XAU/USD", "direction": "BUY", "type": "gold", "entry": "2315.50", "stop_loss": "2298.00", "take_profit": "2345.00", "notes": "Bullish breakout above key resistance zone"}

NEVER add text outside the JSON.`;

    const response = await fetch(`${baseUrl}/chat/completions`, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'Authorization': `Bearer ${apiKey}`,
      },
      body: JSON.stringify({
        model: 'google/gemini-3-flash-preview',
        messages: [
          { role: 'system', content: systemPrompt },
          {
            role: 'user',
            content: [
              {
                type: 'text',
                text: mode === 'result'
                  ? 'Please analyze this trading result screenshot and extract win/loss and pips:'
                  : 'Please analyze this TradingView chart screenshot and extract all signal parameters. Pay special attention to the direction (BUY or SELL) based on the arrows and price levels:'
              },
              { type: 'image_url', image_url: { url: imageUrl } }
            ]
          }
        ],
        temperature: 0.1, // Lower temperature for more deterministic output
      }),
    });

    const aiData = await response.json();
    const text = aiData.choices?.[0]?.message?.content ?? '';

    // Parse JSON from response
    let parsed: Record<string, string> = {};
    try {
      const jsonMatch = text.match(/\{[\s\S]*?\}/);
      if (jsonMatch) {
        parsed = JSON.parse(jsonMatch[0]);
        // Validate and normalize direction
        if (parsed.direction) {
          const dir = parsed.direction.toUpperCase().trim();
          parsed.direction = (dir === 'SELL' || dir === 'SHORT' || dir === 'S') ? 'SELL' : 'BUY';
        }
        // Validate direction logic: if SL > entry => it's actually a SELL
        if (parsed.entry && parsed.stop_loss && parsed.direction) {
          const entry = parseFloat(parsed.entry);
          const sl = parseFloat(parsed.stop_loss);
          if (!isNaN(entry) && !isNaN(sl)) {
            if (sl > entry && parsed.direction === 'BUY') {
              // SL above entry → this is actually a SELL signal
              parsed.direction = 'SELL';
            } else if (sl < entry && parsed.direction === 'SELL') {
              // SL below entry → this is actually a BUY signal
              parsed.direction = 'BUY';
            }
          }
        }
        // Normalize type
        if (parsed.pair) {
          const pairUpper = parsed.pair.toUpperCase();
          if (pairUpper.includes('XAU') || pairUpper.includes('GOLD')) {
            parsed.type = 'gold';
          } else if (pairUpper.includes('BTC') || pairUpper.includes('ETH') || pairUpper.includes('USDT') || pairUpper.includes('DOGE') || pairUpper.includes('SOL')) {
            parsed.type = 'crypto';
          } else {
            parsed.type = parsed.type || 'forex';
          }
        }
      }
    } catch {
      parsed = {};
    }

    return new Response(JSON.stringify({ success: true, data: parsed }), {
      headers: { ...corsHeaders, 'Content-Type': 'application/json' },
    });
  } catch (err) {
    return new Response(JSON.stringify({ error: String(err) }), {
      status: 500,
      headers: { ...corsHeaders, 'Content-Type': 'application/json' },
    });
  }
});
