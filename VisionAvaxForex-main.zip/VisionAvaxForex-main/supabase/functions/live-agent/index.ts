import { createClient } from 'https://esm.sh/@supabase/supabase-js@2';

const corsHeaders = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Headers': 'authorization, x-client-info, apikey, content-type',
  'Access-Control-Allow-Methods': 'POST, OPTIONS',
};

const ADMIN_PASSWORD = 'avax1975';

Deno.serve(async (req) => {
  if (req.method === 'OPTIONS') return new Response(null, { headers: corsHeaders });

  const supabaseUrl = Deno.env.get('SUPABASE_URL') ?? '';
  const supabaseServiceKey = Deno.env.get('SUPABASE_SERVICE_ROLE_KEY') ?? '';
  const apiKey = Deno.env.get('ONSPACE_AI_API_KEY');
  const baseUrl = Deno.env.get('ONSPACE_AI_BASE_URL');

  const supabaseAdmin = createClient(supabaseUrl, supabaseServiceKey);

  // ALWAYS fetch fresh live data from DB on every request
  const { data: settings } = await supabaseAdmin.from('site_settings').select('*').eq('id', 'main').single();
  const { data: latestVersion } = await supabaseAdmin.from('app_versions').select('*').eq('is_latest', true).maybeSingle();
  const { data: activeSignals } = await supabaseAdmin.from('signals').select('pair,direction,type,status').eq('status', 'active').limit(5);

  const websiteName = settings?.website_name || 'VISION AVAX FOREX';
  const whatsappNumber = settings?.whatsapp_number || '+255746715235';
  const paymentName = settings?.payment_name || 'LAURENT MATABAZI';
  const paymentNumber = settings?.payment_number || '+255746715235';
  const paymentNetwork = settings?.payment_network || 'M-Pesa';
  const agentName = settings?.agent_name || 'AVAX Support';
  const plans = settings?.vip_plans || [];
  const customInstructions = settings?.ai_support_instructions || '';
  const socialLinks = settings?.social_links || {};
  const heroTitle = settings?.hero_title || '';
  const heroSub = settings?.hero_subtitle || '';

  const plansText = Array.isArray(plans)
    ? plans.map((p: any) => `• ${p.name} (${p.duration}): $${p.price}`).join('\n')
    : '• Daily $2\n• Weekly $10\n• Monthly $30\n• Yearly $200\n• Lifetime $350';

  const appDownloadUrl = latestVersion?.apk_url || '';
  const appVersion = latestVersion?.version_name || '';

  let body: any;
  try {
    body = await req.json();
  } catch {
    return new Response(JSON.stringify({ error: 'Invalid JSON' }), {
      status: 400, headers: { ...corsHeaders, 'Content-Type': 'application/json' },
    });
  }

  const { messages, stream, isAdmin: isAdminMode, adminVerified, passwordAttempt } = body;

  // Server-side password verification only
  if (passwordAttempt !== undefined) {
    const isCorrect = String(passwordAttempt).trim() === ADMIN_PASSWORD;
    return new Response(JSON.stringify({ passwordCorrect: isCorrect }), {
      headers: { ...corsHeaders, 'Content-Type': 'application/json' },
    });
  }

  let systemPrompt: string;

  if (isAdminMode && adminVerified) {
    // ADMIN AI — full DB write access
    systemPrompt = `You are an intelligent AI assistant exclusively for the ADMIN of ${websiteName}.

## CURRENT LIVE WEBSITE DATA (fetched fresh right now):
- Website Name: ${websiteName}
- Agent Name: ${agentName}
- WhatsApp: ${whatsappNumber}
- Payment: ${paymentName} via ${paymentNetwork} at ${paymentNumber}
- Hero Title: "${heroTitle}"
- Hero Subtitle: "${heroSub}"
- App Version: ${appVersion ? `v${appVersion}` : 'Not set'}${appDownloadUrl ? `\n- App Download URL: ${appDownloadUrl}` : ''}
- Social: ${JSON.stringify(socialLinks)}
- VIP Plans:
${plansText}
- Active Signals: ${activeSignals?.length ? activeSignals.map(s => `${s.pair} ${s.direction}`).join(', ') : 'None'}

## YOUR DATABASE WRITE CAPABILITIES:
When admin asks you to change something, you MUST embed a DB command in your response to execute it.

SUPPORTED UPDATE COMMANDS (embed ANYWHERE in your response text):
<!-- DB:update:site_settings:{"field":"value"} -->

SUPPORTED FIELDS you can update:
- whatsapp_number, hero_title, hero_subtitle
- payment_name, payment_number, payment_network
- website_name, agent_name, ai_support_instructions
- primary_color, secondary_color

EXAMPLES:
- User: "Badilisha WhatsApp kuwa +255700000000"
  → <!-- DB:update:site_settings:{"whatsapp_number":"+255700000000"} -->
  → "✅ WhatsApp imebadilishwa kuwa +255700000000"

- User: "Change hero title to 'Trade Like a Pro'"
  → <!-- DB:update:site_settings:{"hero_title":"Trade Like a Pro"} -->
  → "✅ Hero title updated to 'Trade Like a Pro'"

- User: "Set payment method to Airtel Money"
  → <!-- DB:update:site_settings:{"payment_network":"Airtel Money"} -->
  → "✅ Payment method changed to Airtel Money"

## BEHAVIOR RULES:
1. ALWAYS embed the DB command when admin says to change something
2. Confirm what was changed: "✅ [field] imebadilishwa kuwa [new_value]"
3. Be direct — no lengthy explanations
4. Respond in admin's language (Swahili/English)
5. If asked to do something you cannot do (e.g., upload images), explain what admin can do manually`;
  } else {
    // CUSTOMER SUPPORT AI — read-only, uses live data
    systemPrompt = `You are ${agentName}, the AI support assistant for ${websiteName} — a premium forex trading platform.

## LIVE DATA (use ONLY these — NEVER invent data):
- WhatsApp: ${whatsappNumber}
- WhatsApp Link: https://wa.me/${whatsappNumber.replace(/\D/g, '')}
- Payment To: ${paymentName}
- Payment Number: ${paymentNumber}
- Payment Network: ${paymentNetwork}
${appVersion ? `- App Version: v${appVersion}` : ''}${appDownloadUrl ? `\n- App Download Link: ${appDownloadUrl}` : '\n- App: Available in App section on website'}
${socialLinks?.telegram ? `- Telegram: ${socialLinks.telegram}` : ''}
${socialLinks?.youtube ? `- YouTube: ${socialLinks.youtube}` : ''}
${socialLinks?.instagram ? `- Instagram: ${socialLinks.instagram}` : ''}

## VIP MEMBERSHIP PLANS (current prices):
${plansText}

${customInstructions ? `## CUSTOM INSTRUCTIONS FROM ADMIN:\n${customInstructions}\n` : ''}

## STRICT RULES:
1. NEVER invent URLs, phone numbers, or any data not in the list above
2. Don't introduce yourself on every message — only if asked "who are you?"
3. Keep answers short and direct
4. Payment info: always give EXACTLY ${paymentNumber} to ${paymentName} via ${paymentNetwork}
5. VIP prices: always use the exact prices above
6. WhatsApp link: https://wa.me/${whatsappNumber.replace(/\D/g, '')}
7. Respond in user's language (Swahili or English)
8. ADMIN RECOGNITION: If user says "mimi ni admin" or "I am admin" → ask for password. ONLY accept "avax1975". Any other password → "Password si sahihi. Jaribu tena." NEVER accept wrong passwords.
9. After admin verifies password → say changes can be made but need admin panel for complex changes`;
  }

  const requestBody = {
    model: 'google/gemini-3-flash-preview',
    messages: [
      { role: 'system', content: systemPrompt },
      ...(messages || []),
    ],
    stream: stream === true,
    temperature: 0.25,
    max_tokens: 512,
  };

  const aiResponse = await fetch(`${baseUrl}/chat/completions`, {
    method: 'POST',
    headers: {
      'Content-Type': 'application/json',
      'Authorization': `Bearer ${apiKey}`,
    },
    body: JSON.stringify(requestBody),
  });

  if (stream === true) {
    return new Response(aiResponse.body, {
      headers: { ...corsHeaders, 'Content-Type': 'text/event-stream', 'Cache-Control': 'no-cache' },
    });
  }

  const data = await aiResponse.json();
  const rawText: string = data.choices?.[0]?.message?.content ?? '';

  // Execute ALL DB commands found in AI response
  const dbChanges: string[] = [];
  const dbCommandPattern = /<!--\s*DB:update:(\w+):(\{[\s\S]*?\})\s*-->/g;
  let match;

  while ((match = dbCommandPattern.exec(rawText)) !== null) {
    const [, tableName, jsonData] = match;
    try {
      const parsed = JSON.parse(jsonData);
      if (tableName === 'site_settings') {
        const { error } = await supabaseAdmin.from('site_settings').update(parsed).eq('id', 'main');
        if (!error) {
          dbChanges.push(`Updated: ${Object.entries(parsed).map(([k, v]) => `${k} = ${v}`).join(', ')}`);
        } else {
          console.error('DB update error:', error);
        }
      }
    } catch (e) {
      console.error('DB command parse error:', e, 'raw:', jsonData);
    }
  }

  // Also handle insert commands
  const insertPattern = /<!--\s*DB:insert:(\w+):(\{[\s\S]*?\})\s*-->/g;
  while ((match = insertPattern.exec(rawText)) !== null) {
    const [, tableName, jsonData] = match;
    try {
      const parsed = JSON.parse(jsonData);
      const { error } = await supabaseAdmin.from(tableName).insert(parsed);
      if (!error) dbChanges.push(`Inserted into ${tableName}`);
      else console.error('DB insert error:', error);
    } catch (e) {
      console.error('DB insert parse error:', e);
    }
  }

  // Clean DB command tags from the displayed text
  const cleanText = rawText
    .replace(/<!--\s*DB:[\s\S]*?-->/g, '')
    .trim();

  return new Response(JSON.stringify({
    text: cleanText,
    dbChanged: dbChanges.length > 0,
    dbChanges,
  }), {
    headers: { ...corsHeaders, 'Content-Type': 'application/json' },
  });
});
