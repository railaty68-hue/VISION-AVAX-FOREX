import { Toaster } from "@/components/ui/toaster";
import { Toaster as Sonner } from "@/components/ui/sonner";
import { TooltipProvider } from "@/components/ui/tooltip";
import { QueryClient, QueryClientProvider } from "@tanstack/react-query";
import { BrowserRouter, Routes, Route, useLocation } from "react-router-dom";
import { AuthProvider } from "@/contexts/AuthContext";
import Index from "./pages/Index";
import Auth from "./pages/Auth";
import Signals from "./pages/Signals";
import Courses from "./pages/Courses";
import VIPRoom from "./pages/VIPRoom";
import Settings from "./pages/Settings";
import Admin from "./pages/Admin";
import Messenger from "./pages/Messenger";
import CoursePlayer from "./pages/CoursePlayer";
import Profile from "./pages/Profile";
import NotFound from "./pages/NotFound";
import Header from "@/components/layout/Header";
import BottomNav from "@/components/layout/BottomNav";
import WhatsAppButton from "@/components/layout/WhatsAppButton";

const queryClient = new QueryClient();

function AppLayout() {
  const location = useLocation();
  const isVIPRoom = location.pathname === '/vip';
  const isMessenger = location.pathname === '/messenger' || location.pathname.startsWith('/messenger');

  return (
    <div className="min-h-screen bg-background">
      {!isVIPRoom && !isMessenger && <Header />}
      <Routes>
        <Route path="/" element={<Index />} />
        <Route path="/signals" element={<Signals />} />
        <Route path="/courses" element={<Courses />} />
        <Route path="/courses/:courseId" element={<CoursePlayer />} />
        <Route path="/vip" element={<VIPRoom />} />
        <Route path="/settings" element={<Settings />} />
        <Route path="/admin" element={<Admin />} />
        <Route path="/messenger" element={<Messenger />} />
        <Route path="/profile/:userId" element={<Profile />} />
        <Route path="*" element={<NotFound />} />
      </Routes>
      <BottomNav />
      <WhatsAppButton />
    </div>
  );
}

const App = () => (
  <QueryClientProvider client={queryClient}>
    <TooltipProvider>
      <Toaster />
      <Sonner position="top-center" richColors />
      <AuthProvider>
        <BrowserRouter>
          <Routes>
            <Route path="/auth" element={<Auth />} />
            <Route path="/*" element={<AppLayout />} />
          </Routes>
        </BrowserRouter>
      </AuthProvider>
    </TooltipProvider>
  </QueryClientProvider>
);

export default App;
