import { createClient } from '@supabase/supabase-js';

const supabaseUrl = import.meta.env.VITE_SUPABASE_URL;
const supabaseAnonKey = import.meta.env.VITE_SUPABASE_ANON_KEY;

export const supabase = createClient(supabaseUrl, supabaseAnonKey, {
  auth: { persistSession: true, autoRefreshToken: true },
});

export const ADMIN_EMAIL = 'visionavaxforex@gmail.com';
export const WHATSAPP_NUMBER = '+255746715235';
export const PAYMENT_NAME = 'LAURENT MATABAZI';

export async function uploadFile(bucket: string, path: string, file: File): Promise<string> {
  const { error } = await supabase.storage.from(bucket).upload(path, file, { upsert: true });
  if (error) throw error;
  const { data } = supabase.storage.from(bucket).getPublicUrl(path);
  return data.publicUrl;
}

export function getPublicUrl(bucket: string, path: string): string {
  const { data } = supabase.storage.from(bucket).getPublicUrl(path);
  return data.publicUrl;
}

export function openWhatsApp(number: string, message: string) {
  const clean = number.replace(/\D/g, '');
  const encoded = encodeURIComponent(message);
  window.open(`https://wa.me/${clean}?text=${encoded}`, '_blank');
}

export function isVIPActive(profile: { is_vip: boolean; vip_expires_at?: string | null }): boolean {
  if (!profile.is_vip) return false;
  if (!profile.vip_expires_at) return true;
  return new Date(profile.vip_expires_at) > new Date();
}

export function generateReferralCode(userId: string): string {
  return `VAF${userId.slice(0, 6).toUpperCase()}`;
}
