import { useState, useEffect, useRef } from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import {
  MessageCircle, Phone, Share2, Camera, Crown, Clock, User, ArrowLeft,
  UserPlus, UserCheck
} from 'lucide-react';
import { supabase, isVIPActive, uploadFile } from '@/lib/supabase';
import { useAuth } from '@/contexts/AuthContext';
import { UserProfile } from '@/types';
import type { BadgeStyle } from '@/types';
import VIPBadge from '@/components/features/VIPBadge';
import BadgeSelector from '@/components/features/BadgeSelector';
import ImageCropper from '@/components/features/ImageCropper';
import PaymentModal from '@/components/features/PaymentModal';
import { toast } from 'sonner';

const defaultPlan = { id: 'monthly', name: 'Monthly', duration: '30 days', days: 30, price: 30 };

export default function Profile() {
  const { userId } = useParams<{ userId: string }>();
  const navigate = useNavigate();
  const { user, profile: myProfile, isAdmin, refreshProfile, theme } = useAuth();
  const [profile, setProfile] = useState<UserProfile | null>(null);
  const [loading, setLoading] = useState(true);
  const [uploadingCover, setUploadingCover] = useState(false);
  const [uploadingAvatar, setUploadingAvatar] = useState(false);
  const [payModal, setPayModal] = useState(false);
  const [showBadgeSelector, setShowBadgeSelector] = useState(false);

  // Cropper state
  const [coverCropFile, setCoverCropFile] = useState<File | null>(null);
  const [avatarCropFile, setAvatarCropFile] = useState<File | null>(null);

  // Follow state
  const [isFollowing, setIsFollowing] = useState(false);
  const [followersCount, setFollowersCount] = useState(0);
  const [followingCount, setFollowingCount] = useState(0);

  const coverInputRef = useRef<HTMLInputElement>(null);
  const avatarInputRef = useRef<HTMLInputElement>(null);

  const [globalCoverUrl, setGlobalCoverUrl] = useState<string>('');
  const iHaveAccess = isAdmin || (myProfile ? isVIPActive(myProfile) : false);
  const isOwnProfile = user?.id === userId;

  useEffect(() => {
    // Load global cover from settings
    supabase.from('site_settings').select('global_cover_url').eq('id', 'main').single()
      .then(({ data }) => { if (data && (data as any).global_cover_url) setGlobalCoverUrl((data as any).global_cover_url); });
  }, []);

  useEffect(() => {
    if (!userId) return;
    Promise.all([
      supabase.from('user_profiles').select('*').eq('id', userId).single(),
      supabase.from('user_follows').select('*', { count: 'exact', head: true }).eq('following_id', userId),
      supabase.from('user_follows').select('*', { count: 'exact', head: true }).eq('follower_id', userId),
    ]).then(([profileRes, followersRes, followingRes]) => {
      if (profileRes.data) setProfile(profileRes.data);
      setFollowersCount(followersRes.count || 0);
      setFollowingCount(followingRes.count || 0);
      setLoading(false);
    });

    // Check if current user follows this profile
    if (user && userId && user.id !== userId) {
      supabase.from('user_follows')
        .select('id')
        .eq('follower_id', user.id)
        .eq('following_id', userId)
        .single()
        .then(({ data }) => setIsFollowing(!!data));
    }
  }, [userId, user]);

  async function toggleFollow() {
    if (!user || !userId) return;
    if (!iHaveAccess) { setPayModal(true); return; }
    if (isFollowing) {
      await supabase.from('user_follows').delete().eq('follower_id', user.id).eq('following_id', userId);
      setIsFollowing(false);
      setFollowersCount(c => Math.max(0, c - 1));
      toast.success('Unfollowed');
    } else {
      await supabase.from('user_follows').insert({ follower_id: user.id, following_id: userId });
      setIsFollowing(true);
      setFollowersCount(c => c + 1);
      toast.success('Following!');
    }
  }

  async function startChat() {
    if (!user) { navigate('/auth'); return; }
    if (!iHaveAccess) { setPayModal(true); return; }
    navigate(`/messenger?user=${userId}`);
  }

  function callUser() {
    if (!profile?.phone_number) { toast.error('This user has not shared their phone number'); return; }
    window.location.href = `tel:${profile.phone_number}`;
  }

  async function shareProfile() {
    const url = `${window.location.origin}/profile/${userId}`;
    if (navigator.share) {
      navigator.share({ title: profile?.username || 'Member', url });
    } else {
      navigator.clipboard.writeText(url);
      toast.success('Profile link copied!');
    }
  }

  /* ── Cover: open gallery → crop → upload ── */
  function handleCoverFileSelect(e: React.ChangeEvent<HTMLInputElement>) {
    const file = e.target.files?.[0];
    if (!file) return;
    if (!['image/jpeg', 'image/png', 'image/webp'].includes(file.type)) { toast.error('Please select JPG, PNG or WEBP'); return; }
    if (file.size > 15 * 1024 * 1024) { toast.error('Image must be under 15MB'); return; }
    setCoverCropFile(file);
    e.target.value = '';
  }

  async function handleCoverCropped(blob: Blob) {
    if (!user) return;
    setCoverCropFile(null);
    setUploadingCover(true);
    try {
      const file = new File([blob], `cover_${Date.now()}.jpg`, { type: 'image/jpeg' });
      const url = await uploadFile('banners', `cover_${user.id}_${Date.now()}`, file);
      await supabase.from('user_profiles').update({ cover_url: url } as any).eq('id', user.id);
      setProfile(p => p ? { ...p, cover_url: url } as any : p);
      await refreshProfile();
      toast.success('Cover photo updated!');
    } catch { toast.error('Upload failed.'); }
    finally { setUploadingCover(false); }
  }

  /* ── Avatar: open gallery → crop → upload ── */
  function handleAvatarFileSelect(e: React.ChangeEvent<HTMLInputElement>) {
    const file = e.target.files?.[0];
    if (!file) return;
    if (!['image/jpeg', 'image/png', 'image/webp'].includes(file.type)) { toast.error('Please select JPG, PNG or WEBP'); return; }
    if (file.size > 10 * 1024 * 1024) { toast.error('Image must be under 10MB'); return; }
    setAvatarCropFile(file);
    e.target.value = '';
  }

  async function handleAvatarCropped(blob: Blob) {
    if (!user) return;
    setAvatarCropFile(null);
    setUploadingAvatar(true);
    try {
      const file = new File([blob], `avatar_${Date.now()}.jpg`, { type: 'image/jpeg' });
      const url = await uploadFile('avatars', `${user.id}/avatar_${Date.now()}`, file);
      await supabase.from('user_profiles').update({ avatar_url: url }).eq('id', user.id);
      setProfile(p => p ? { ...p, avatar_url: url } : p);
      await refreshProfile();
      toast.success('Profile photo updated!');
    } catch { toast.error('Upload failed.'); }
    finally { setUploadingAvatar(false); }
  }

  async function handleBadgeSelect(style: BadgeStyle) {
    if (!user) return;
    await supabase.from('user_profiles').update({ badge_style: style } as any).eq('id', user.id);
    setProfile(p => p ? { ...p, badge_style: style } as any : p);
    await refreshProfile();
    toast.success('Verification badge updated!');
  }

  if (loading) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-background">
        <div className="w-8 h-8 border-2 border-primary border-t-transparent rounded-full animate-spin" />
      </div>
    );
  }

  if (!profile) {
    return (
      <div className="min-h-screen flex flex-col items-center justify-center px-4 bg-background">
        <div className="w-16 h-16 rounded-2xl bg-muted flex items-center justify-center mb-4">
          <User className="w-8 h-8 text-muted-foreground" />
        </div>
        <h2 className="text-lg font-black text-foreground mb-2">Profile Not Found</h2>
        <p className="text-sm text-muted-foreground mb-6 text-center">This member may have deleted their account.</p>
        <button onClick={() => navigate(-1)} className="px-5 py-2.5 gradient-pink rounded-xl text-white font-bold press pink-glow-xs">Go Back</button>
      </div>
    );
  }

  const coverUrl = (profile as any).cover_url || globalCoverUrl;
  const displayName = profile.full_name || profile.username || profile.email?.split('@')[0] || 'Member';
  const handle = profile.username || profile.email?.split('@')[0] || 'member';
  const isOnline = profile.is_online;
  const profileIsVIP = isVIPActive(profile) || (profile.is_vip && profile.vip_expires_at && new Date(profile.vip_expires_at) > new Date());
  const showPhone = profile.phone_number && (isOwnProfile || profile.phone_privacy === 'public');
  const badgeStyle = ((profile as any).badge_style as BadgeStyle) || 'blue_shield';
  const hasBadge = profile.blue_tick || profileIsVIP || isAdmin;

  const pageBg = theme === 'light' ? 'bg-[#f3f4f6]' : 'bg-background';
  const cardBg = theme === 'light' ? 'bg-white' : 'bg-card';
  const textPrimary = theme === 'light' ? 'text-gray-900' : 'text-foreground';
  const textSub = theme === 'light' ? 'text-gray-500' : 'text-muted-foreground';
  const borderCol = theme === 'light' ? 'border-gray-200' : 'border-border';

  return (
    <>
      {/* Croppers */}
      {coverCropFile && (
        <ImageCropper
          imageFile={coverCropFile}
          aspectRatio={16 / 9}
          isCircular={false}
          title="Crop Cover Photo"
          onCrop={handleCoverCropped}
          onCancel={() => setCoverCropFile(null)}
        />
      )}
      {avatarCropFile && (
        <ImageCropper
          imageFile={avatarCropFile}
          aspectRatio={1}
          isCircular={true}
          title="Crop Profile Photo"
          onCrop={handleAvatarCropped}
          onCancel={() => setAvatarCropFile(null)}
        />
      )}

      {payModal && <PaymentModal plan={defaultPlan} onClose={() => setPayModal(false)} />}

      {showBadgeSelector && isOwnProfile && (
        <BadgeSelector
          currentStyle={badgeStyle}
          isVIP={iHaveAccess}
          onSelect={handleBadgeSelect}
          onClose={() => setShowBadgeSelector(false)}
          onUpgrade={() => setPayModal(true)}
        />
      )}

      <div className={`min-h-screen ${pageBg} pb-28 animate-fade-in`}>

        {/* ── Back + Edit overlay ── */}
        <div
          className="absolute top-0 left-0 right-0 z-30 flex items-center justify-between px-4"
          style={{ paddingTop: 'max(14px, env(safe-area-inset-top))' }}
        >
          <button
            onClick={() => navigate(-1)}
            className="w-9 h-9 rounded-full bg-black/35 backdrop-blur-sm flex items-center justify-center press hover:bg-black/50 transition-all"
          >
            <ArrowLeft className="w-4 h-4 text-white" />
          </button>
          {isOwnProfile && (
            <button
              onClick={() => navigate('/settings')}
              className="px-3 py-1.5 rounded-full bg-black/35 backdrop-blur-sm text-white text-xs font-bold press hover:bg-black/50 transition-all"
            >
              Edit Profile
            </button>
          )}
        </div>

        {/* ── Cover Photo ── */}
        <div className="relative" style={{ height: '52vw', maxHeight: 260, minHeight: 180 }}>
          {coverUrl
            ? <img src={coverUrl} alt="cover" className="w-full h-full object-cover" />
            : (
              <div className="w-full h-full" style={{ background: 'linear-gradient(135deg,#3D0033 0%,#7B0055 35%,#CC006A 65%,#FF1493 100%)' }}>
                <div className="absolute inset-0" style={{ backgroundImage: 'radial-gradient(circle at 30% 70%,rgba(255,255,255,0.18) 0%,transparent 50%)' }} />
              </div>
            )
          }

          {isOwnProfile && (
            <>
              <button
                type="button"
                onClick={() => coverInputRef.current?.click()}
                className="absolute bottom-3 right-3 flex items-center gap-1.5 px-3 py-2 bg-black/50 backdrop-blur-sm border border-white/20 rounded-2xl text-white text-xs font-bold hover:bg-black/65 transition-all press"
              >
                {uploadingCover
                  ? <div className="w-3.5 h-3.5 border-2 border-white border-t-transparent rounded-full animate-spin" />
                  : <Camera className="w-3.5 h-3.5" />
                }
                {uploadingCover ? 'Uploading...' : 'Change Cover'}
              </button>
              <input
                ref={coverInputRef}
                type="file"
                accept="image/jpeg,image/png,image/webp"
                className="hidden"
                onChange={handleCoverFileSelect}
              />
            </>
          )}
        </div>

        {/* ── Avatar ── */}
        <div className="flex justify-center" style={{ marginTop: '-52px', position: 'relative', zIndex: 10 }}>
          <div className="relative">
            <div
              className="rounded-full p-[4px]"
              style={{
                background: 'linear-gradient(135deg,#FF1493,#FF69B4,#FF1493)',
                boxShadow: `0 0 0 3px ${theme === 'light' ? '#f3f4f6' : 'hsl(var(--background))'}`,
              }}
            >
              <div className="w-[96px] h-[96px] rounded-full overflow-hidden bg-muted flex items-center justify-center gradient-pink relative">
                {profile.avatar_url
                  ? <img src={profile.avatar_url} alt={displayName} className="w-full h-full object-cover" />
                  : <span className="text-4xl font-black text-white">{displayName[0]?.toUpperCase()}</span>
                }
                {uploadingAvatar && (
                  <div className="absolute inset-0 bg-black/60 rounded-full flex items-center justify-center">
                    <div className="w-6 h-6 border-2 border-white border-t-transparent rounded-full animate-spin" />
                  </div>
                )}
              </div>
            </div>

            {isOnline && (
              <span
                className="absolute bottom-1 right-1 w-4 h-4 rounded-full bg-green-400 border-[3px]"
                style={{ borderColor: theme === 'light' ? '#f3f4f6' : 'hsl(var(--background))' }}
              />
            )}

            {isOwnProfile && (
              <>
                <button
                  type="button"
                  onClick={() => avatarInputRef.current?.click()}
                  className="absolute bottom-0 right-0 w-8 h-8 rounded-full gradient-pink flex items-center justify-center press shadow-xl border-2 border-background"
                >
                  {uploadingAvatar
                    ? <div className="w-3.5 h-3.5 border-2 border-white border-t-transparent rounded-full animate-spin" />
                    : <Camera className="w-3.5 h-3.5 text-white" />
                  }
                </button>
                <input
                  ref={avatarInputRef}
                  type="file"
                  accept="image/jpeg,image/png,image/webp"
                  className="hidden"
                  onChange={handleAvatarFileSelect}
                />
              </>
            )}
          </div>
        </div>

        {/* ── Name + Badge ── */}
        <div className="flex flex-col items-center px-6 mt-3 mb-1">
          <div className="flex items-center gap-2 flex-wrap justify-center">
            <h1
              className="font-black leading-tight text-center"
              style={{ fontSize: 'clamp(22px,5.5vw,28px)', color: theme === 'light' ? '#111827' : 'hsl(var(--foreground))' }}
            >
              {displayName}
            </h1>
            {hasBadge && (
              <VIPBadge
                size="lg"
                badgeStyle={badgeStyle}
                animate
                onClick={isOwnProfile ? () => setShowBadgeSelector(true) : undefined}
              />
            )}
          </div>

          {isOwnProfile && hasBadge && (
            <p className="text-[10px] text-muted-foreground mt-0.5">Tap badge to customize</p>
          )}

          {/* Followers / Following counts */}
          <div className="flex items-center gap-5 mt-2">
            <div className="text-center">
              <p className="text-sm font-black text-foreground">{followersCount}</p>
              <p className="text-[10px] text-muted-foreground">Followers</p>
            </div>
            <div className="w-px h-8 bg-border" />
            <div className="text-center">
              <p className="text-sm font-black text-foreground">{followingCount}</p>
              <p className="text-[10px] text-muted-foreground">Following</p>
            </div>
          </div>

          {/* Online status */}
          <div className="flex items-center gap-1.5 mt-2">
            {isOnline ? (
              <span className={`text-[13px] font-medium ${textSub} flex items-center gap-1`}>
                <span className="w-2 h-2 rounded-full bg-green-400 animate-pulse inline-block" />
                Online now
              </span>
            ) : profile.last_seen ? (
              <span className={`text-[13px] ${textSub} flex items-center gap-1`}>
                <Clock className="w-3 h-3" />
                Last seen {new Date(profile.last_seen).toLocaleDateString([], { month: 'short', day: 'numeric' })}
              </span>
            ) : (
              <span className={`text-[13px] ${textSub}`}>@{handle}</span>
            )}
            {profileIsVIP && (
              <span className="ml-1 flex items-center gap-0.5 px-2 py-0.5 gradient-pink rounded-full text-white text-[10px] font-black">
                <Crown className="w-2.5 h-2.5" />VIP
              </span>
            )}
          </div>
        </div>

        {/* ── Phone ── */}
        {showPhone && (
          <div className="flex justify-center px-6 mt-3 mb-1">
            <div className={`px-6 py-2.5 rounded-2xl border ${borderCol} ${cardBg}`}>
              <p className="font-black text-center tracking-wide" style={{ fontSize: 'clamp(17px,4.5vw,22px)', color: theme === 'light' ? '#111827' : 'hsl(var(--foreground))' }}>
                {profile.phone_number}
              </p>
            </div>
          </div>
        )}

        {/* ── Action Buttons ── */}
        <div className="px-5 mt-5 grid grid-cols-3 gap-3 max-w-sm mx-auto">
          {[
            { label: 'message', icon: MessageCircle, onClick: startChat },
            { label: 'audio', icon: Phone, onClick: callUser },
            { label: 'share', icon: Share2, onClick: shareProfile },
          ].map(({ label, icon: Icon, onClick }) => (
            <button
              key={label}
              onClick={onClick}
              className={`flex flex-col items-center gap-2 py-4 rounded-2xl border ${borderCol} ${cardBg} press active:scale-95 transition-all hover:border-primary/30`}
            >
              <Icon className="w-7 h-7" style={{ color: theme === 'light' ? '#1565C0' : 'hsl(var(--primary))' }} strokeWidth={1.8} />
              <span className="text-xs font-semibold underline" style={{ color: theme === 'light' ? '#1565C0' : 'hsl(var(--primary))' }}>{label}</span>
            </button>
          ))}
        </div>

        {/* ── Follow button (for other profiles) ── */}
        {!isOwnProfile && (
          <div className="px-5 mt-3 max-w-sm mx-auto">
            <button
              onClick={toggleFollow}
              className={`w-full flex items-center justify-center gap-2 py-3 rounded-2xl font-bold text-sm press transition-all ${
                isFollowing
                  ? `border ${borderCol} ${cardBg} text-foreground`
                  : 'gradient-pink text-white pink-glow-xs'
              }`}
            >
              {isFollowing ? <UserCheck className="w-4 h-4" /> : <UserPlus className="w-4 h-4" />}
              {isFollowing ? 'Following' : 'Follow'}
            </button>
          </div>
        )}

        {/* ── Info section ── */}
        <div className="px-5 mt-5 max-w-sm mx-auto space-y-3">
          {profileIsVIP && profile.vip_expires_at && (
            <div className={`rounded-2xl border p-4 ${cardBg}`} style={{ borderColor: 'rgba(255,20,147,0.25)' }}>
              <p className={`text-xs ${textSub} mb-1 font-medium`}>VIP Expires</p>
              <p className="text-sm font-bold text-primary">
                {new Date(profile.vip_expires_at).toLocaleDateString([], { year: 'numeric', month: 'long', day: 'numeric' })}
              </p>
            </div>
          )}

          {!iHaveAccess && !isOwnProfile && (
            <div className={`rounded-2xl border p-4 flex items-start gap-3 ${cardBg}`} style={{ borderColor: 'rgba(255,20,147,0.2)' }}>
              <div className="w-9 h-9 rounded-xl gradient-pink flex items-center justify-center flex-shrink-0">
                <Crown className="w-4 h-4 text-white" />
              </div>
              <div className="flex-1">
                <p className={`text-sm font-bold ${textPrimary} mb-0.5`}>Premium Feature</p>
                <p className={`text-xs ${textSub}`}>Upgrade to VIP to message & call this member.</p>
                <button onClick={() => setPayModal(true)} className="mt-2 text-xs text-primary font-bold press">Upgrade to VIP →</button>
              </div>
            </div>
          )}
        </div>

        {profile.joined_at && (
          <div className="px-5 mt-3 max-w-sm mx-auto">
            <p className={`text-center text-xs ${textSub}`}>
              Member since {new Date(profile.joined_at).toLocaleDateString([], { year: 'numeric', month: 'long' })}
            </p>
          </div>
        )}
      </div>
    </>
  );
}
