// Fix the VIPRoom to use VIPPlanSelector instead of PaymentModal directly for "Get VIP Access" button
import { useState, useEffect, useRef, useCallback } from 'react';
import {
  Send, Crown, Lock, Image, Pin, Trash2, VolumeX, Volume2,
  Reply, X, ChevronDown, ArrowLeft, Users, MoreVertical,
  Settings, Camera, Share2, Flag, Check, Zap, BookOpen, MessageCircle, Shield
} from 'lucide-react';
import { supabase, uploadFile, isVIPActive } from '@/lib/supabase';
import { useAuth } from '@/contexts/AuthContext';
import { VIPMessage, VIPReaction } from '@/types';
import VIPBadge from '@/components/features/VIPBadge';
import VIPPlanSelector from '@/components/features/VIPPlanSelector';
import TelegramMediaGrid from '@/components/features/TelegramMediaGrid';
import GlobalMediaViewer from '@/components/features/GlobalMediaViewer';
import { toast } from 'sonner';
import { useNavigate } from 'react-router-dom';

const ADMIN_EMAIL = 'visionavaxforex@gmail.com';
const EMOJI_REACTIONS = ['👍','❤️','🔥','💪','🎯','💰','✅','😂','🙏','📈'];

interface MessageWithMeta extends VIPMessage {
  replyMessage?: VIPMessage | null;
  reactions?: VIPReaction[];
}

interface VIPTheme {
  bg: string;
  ownColor: string;
  otherColor: string;
  fontSize: string;
  fontFamily: string;
}

const FONT_FAMILIES: Record<string, string> = {
  default: 'inherit',
  inter: '"Inter", sans-serif',
  roboto: '"Roboto", sans-serif',
  poppins: '"Poppins", sans-serif',
  mono: '"Courier New", monospace',
  serif: '"Georgia", serif',
  cursive: '"Dancing Script", cursive',
  ubuntu: '"Ubuntu", sans-serif',
};

const FONT_SIZES: Record<string, string> = {
  xs: '11px', sm: '13px', md: '14px', lg: '16px', xl: '18px', '2xl': '20px',
};

// ── VIP Benefits Popup ──
function VIPBenefitsPopup({ onGetVIP, onClose }: { onGetVIP: () => void; onClose: () => void }) {
  const benefits = [
    { icon: '🔥', title: 'Live Premium Signals', desc: 'Real-time forex, gold & crypto setups' },
    { icon: '💬', title: 'VIP Chat Room', desc: 'Exclusive community 24/7' },
    { icon: '📚', title: 'All Courses FREE', desc: 'Full trading education library' },
    { icon: '📢', title: 'Admin Announcements', desc: 'Be first to know market moves' },
    { icon: '✅', title: 'Verified Blue Tick', desc: 'Show your VIP status with a badge' },
    { icon: '🌐', title: 'Private Messenger', desc: 'Chat directly with VIP members' },
  ];

  return (
    <div className="fixed inset-0 z-[200] flex flex-col items-center justify-end sm:justify-center p-4 animate-fade-in"
      style={{ background: 'rgba(0,0,0,0.85)', backdropFilter: 'blur(10px)' }}>
      <div className="bg-card border border-border rounded-3xl w-full max-w-sm relative overflow-hidden animate-slide-up max-h-[90vh] flex flex-col">
        <div className="h-1.5 gradient-pink flex-shrink-0" />
        <div className="p-5 overflow-y-auto">
          <button onClick={onClose} className="absolute top-4 right-4 w-8 h-8 rounded-full bg-muted flex items-center justify-center press">
            <X className="w-4 h-4 text-muted-foreground" />
          </button>
          <div className="text-center mb-5">
            <div className="w-16 h-16 gradient-pink rounded-3xl flex items-center justify-center mx-auto mb-3 pink-glow">
              <Crown className="w-8 h-8 text-white" />
            </div>
            <h2 className="text-xl font-black text-foreground">Join VIP Room</h2>
            <p className="text-sm text-muted-foreground mt-1">What you get with VIP membership</p>
          </div>
          <div className="space-y-2.5 mb-5">
            {benefits.map(b => (
              <div key={b.title} className="flex items-center gap-3 p-3 bg-muted/30 rounded-2xl border border-border/50">
                <span className="text-xl flex-shrink-0">{b.icon}</span>
                <div>
                  <p className="text-sm font-bold text-foreground">{b.title}</p>
                  <p className="text-xs text-muted-foreground">{b.desc}</p>
                </div>
              </div>
            ))}
          </div>
          <button onClick={onGetVIP}
            className="w-full py-4 gradient-pink rounded-2xl text-white font-black text-base pink-glow press flex items-center justify-center gap-2 mb-3">
            <Crown className="w-5 h-5" /> Get VIP Access
          </button>
          <button onClick={onClose} className="w-full py-3 text-muted-foreground text-sm press hover:text-foreground transition-colors">
            Maybe Later
          </button>
        </div>
      </div>
    </div>
  );
}

// ── Room Settings Modal ──
function RoomSettings({ onClose }: { onClose: () => void }) {
  const [roomName, setRoomName] = useState('');
  const [roomIcon, setRoomIcon] = useState('');
  const [saving, setSaving] = useState(false);
  const [uploading, setUploading] = useState(false);
  const [vipWallpaper, setVipWallpaper] = useState('');
  const [vipBgColor, setVipBgColor] = useState('#0d0d1a');
  const [vipBubbleOwn, setVipBubbleOwn] = useState('#FF1493');
  const [vipBubbleOther, setVipBubbleOther] = useState('#1e1e2e');
  const [vipFontSize, setVipFontSize] = useState('md');
  const [vipFontFamily, setVipFontFamily] = useState('default');
  const [uploadingWp, setUploadingWp] = useState(false);

  useEffect(() => {
    supabase.from('site_settings')
      .select('website_name, logo_url, vip_wallpaper, vip_bg_color, vip_bubble_color_own, vip_bubble_color_other, vip_font_size, vip_font_family')
      .eq('id', 'main').single()
      .then(({ data }) => {
        if (data) {
          setRoomName((data as any).website_name || '');
          setRoomIcon((data as any).logo_url || '');
          setVipWallpaper((data as any).vip_wallpaper || '');
          setVipBgColor((data as any).vip_bg_color || '#0d0d1a');
          setVipBubbleOwn((data as any).vip_bubble_color_own || '#FF1493');
          setVipBubbleOther((data as any).vip_bubble_color_other || '#1e1e2e');
          setVipFontSize((data as any).vip_font_size || 'md');
          setVipFontFamily((data as any).vip_font_family || 'default');
        }
      });
  }, []);

  async function handleIconUpload(e: React.ChangeEvent<HTMLInputElement>) {
    const file = e.target.files?.[0]; if (!file) return;
    setUploading(true);
    const url = await uploadFile('banners', `room_icon_${Date.now()}`, file);
    setRoomIcon(url); setUploading(false);
    toast.success('Icon uploaded');
  }

  async function handleWallpaperUpload(e: React.ChangeEvent<HTMLInputElement>) {
    const file = e.target.files?.[0]; if (!file) return;
    setUploadingWp(true);
    const url = await uploadFile('banners', `vip_wallpaper_${Date.now()}`, file);
    setVipWallpaper(url); setUploadingWp(false);
    toast.success('Wallpaper uploaded');
    e.target.value = '';
  }

  async function save() {
    setSaving(true);
    await supabase.from('site_settings').update({
      website_name: roomName, logo_url: roomIcon,
      vip_wallpaper: vipWallpaper || null, vip_bg_color: vipBgColor,
      vip_bubble_color_own: vipBubbleOwn, vip_bubble_color_other: vipBubbleOther,
      vip_font_size: vipFontSize, vip_font_family: vipFontFamily,
    } as any).eq('id', 'main');
    toast.success('Room settings saved!');
    setSaving(false);
    onClose();
  }

  return (
    <div className="fixed inset-0 z-[300] bg-black/70 flex flex-col animate-fade-in" onClick={onClose}
      style={{ paddingTop: 'env(safe-area-inset-top)' }}>
      <div className="flex-1" />
      <div className="w-full max-w-md mx-auto bg-card border border-border rounded-t-3xl p-5 overflow-y-auto animate-slide-up"
        onClick={e => e.stopPropagation()}
        style={{ maxHeight: '85vh', paddingBottom: 'max(20px, env(safe-area-inset-bottom))' }}>
        <div className="flex items-center justify-between mb-4">
          <h3 className="font-black text-foreground">VIP Room Settings</h3>
          <button onClick={onClose} className="p-1.5 rounded-xl bg-muted press"><X className="w-4 h-4 text-muted-foreground" /></button>
        </div>
        <div className="flex flex-col items-center mb-4">
          <div className="relative mb-1">
            <div className="w-16 h-16 rounded-2xl overflow-hidden bg-muted flex items-center justify-center gradient-pink">
              {roomIcon ? <img src={roomIcon} alt="" className="w-full h-full object-cover" /> : <Crown className="w-8 h-8 text-white" />}
            </div>
            <label className="absolute -bottom-1 -right-1 w-6 h-6 rounded-full gradient-pink flex items-center justify-center cursor-pointer press shadow-lg">
              {uploading ? <div className="w-3 h-3 border-2 border-white border-t-transparent rounded-full animate-spin" /> : <Camera className="w-3 h-3 text-white" />}
              <input type="file" accept="image/*" className="hidden" onChange={handleIconUpload} />
            </label>
          </div>
          <p className="text-xs text-muted-foreground">Room icon</p>
        </div>
        <div className="mb-3">
          <label className="text-xs text-muted-foreground mb-1 block font-medium">Room Name</label>
          <input className="w-full bg-muted border border-border rounded-xl px-3 py-2.5 text-foreground text-sm outline-none focus:border-primary" value={roomName} onChange={e => setRoomName(e.target.value)} />
        </div>
        <div className="mb-3">
          <label className="text-xs text-muted-foreground mb-1 block font-medium">Background Color</label>
          <div className="flex gap-2">
            <input type="color" value={vipBgColor} onChange={e => setVipBgColor(e.target.value)} className="w-10 h-9 rounded-lg border border-border cursor-pointer bg-transparent" />
            <input value={vipBgColor} onChange={e => setVipBgColor(e.target.value)} className="flex-1 bg-muted border border-border rounded-xl px-3 py-2 text-foreground text-sm outline-none focus:border-primary" />
          </div>
        </div>
        <div className="mb-3">
          <label className="text-xs text-muted-foreground mb-1 block font-medium">Chat Wallpaper</label>
          <label className="flex items-center gap-2 p-3 border border-dashed border-primary/35 rounded-xl cursor-pointer hover:bg-primary/5 transition-all">
            {uploadingWp ? <div className="w-4 h-4 border-2 border-primary border-t-transparent rounded-full animate-spin" /> : <Image className="w-4 h-4 text-primary" />}
            <span className="text-sm text-muted-foreground flex-1">{vipWallpaper && !vipWallpaper.startsWith('linear') ? '✓ Wallpaper set' : 'Upload Wallpaper'}</span>
            {vipWallpaper && <button type="button" onClick={() => setVipWallpaper('')} className="text-red-400 text-xs">Clear</button>}
            <input type="file" accept="image/*" className="hidden" onChange={handleWallpaperUpload} />
          </label>
        </div>
        <div className="mb-3">
          <label className="text-xs text-muted-foreground mb-1 block font-medium">Your Message Color</label>
          <div className="flex gap-2">
            <input type="color" value={vipBubbleOwn} onChange={e => setVipBubbleOwn(e.target.value)} className="w-10 h-9 rounded-lg border border-border cursor-pointer bg-transparent" />
            <input value={vipBubbleOwn} onChange={e => setVipBubbleOwn(e.target.value)} className="flex-1 bg-muted border border-border rounded-xl px-3 py-2 text-foreground text-sm outline-none" />
          </div>
        </div>
        <div className="mb-3">
          <label className="text-xs text-muted-foreground mb-1 block font-medium">Others' Message Color</label>
          <div className="flex gap-2">
            <input type="color" value={vipBubbleOther} onChange={e => setVipBubbleOther(e.target.value)} className="w-10 h-9 rounded-lg border border-border cursor-pointer bg-transparent" />
            <input value={vipBubbleOther} onChange={e => setVipBubbleOther(e.target.value)} className="flex-1 bg-muted border border-border rounded-xl px-3 py-2 text-foreground text-sm outline-none" />
          </div>
        </div>
        <button onClick={save} disabled={saving} className="w-full py-3 gradient-pink rounded-xl text-white font-bold press pink-glow-xs disabled:opacity-50">
          {saving ? 'Saving...' : 'Save Room Settings'}
        </button>
      </div>
    </div>
  );
}

// ── Message Long-press Action Sheet ── (only shown after 3s hold)
function MessageActions({ msg, isOwn, isAdmin, onReply, onDelete, onPin, onForward, onReport, onClose }: {
  msg: MessageWithMeta; isOwn: boolean; isAdmin: boolean;
  onReply: () => void; onDelete: () => void; onPin: () => void; onForward: () => void; onReport: () => void; onClose: () => void;
}) {
  return (
    <div className="fixed inset-0 z-[400] bg-black/60 flex items-end justify-center animate-fade-in" onClick={onClose}>
      <div className="w-full max-w-md bg-card border border-border rounded-t-3xl overflow-hidden animate-slide-up"
        onClick={e => e.stopPropagation()} style={{ paddingBottom: 'max(16px, env(safe-area-inset-bottom))' }}>
        <div className="px-4 py-3 border-b border-border">
          <p className="text-xs text-muted-foreground line-clamp-2">{msg.message || '📎 Media'}</p>
        </div>
        <div className="py-2">
          <button onClick={() => { onReply(); onClose(); }} className="w-full flex items-center gap-4 px-5 py-3.5 hover:bg-muted/50 press text-left">
            <div className="w-9 h-9 rounded-xl bg-blue-500/15 flex items-center justify-center"><Reply className="w-4 h-4 text-blue-400" /></div>
            <p className="font-bold text-foreground text-sm">Reply</p>
          </button>
          <button onClick={() => { onForward(); onClose(); }} className="w-full flex items-center gap-4 px-5 py-3.5 hover:bg-muted/50 press text-left">
            <div className="w-9 h-9 rounded-xl bg-green-500/15 flex items-center justify-center"><Share2 className="w-4 h-4 text-green-400" /></div>
            <p className="font-bold text-foreground text-sm">Forward</p>
          </button>
          {!isOwn && (
            <button onClick={() => { onReport(); onClose(); }} className="w-full flex items-center gap-4 px-5 py-3.5 hover:bg-muted/50 press text-left">
              <div className="w-9 h-9 rounded-xl bg-orange-500/15 flex items-center justify-center"><Flag className="w-4 h-4 text-orange-400" /></div>
              <p className="font-bold text-foreground text-sm">Report to Admin</p>
            </button>
          )}
          {isAdmin && (
            <button onClick={() => { onPin(); onClose(); }} className="w-full flex items-center gap-4 px-5 py-3.5 hover:bg-muted/50 press text-left">
              <div className="w-9 h-9 rounded-xl bg-yellow-500/15 flex items-center justify-center"><Pin className="w-4 h-4 text-yellow-400" /></div>
              <p className="font-bold text-foreground text-sm">{msg.is_pinned ? 'Unpin' : 'Pin'}</p>
            </button>
          )}
          {(isOwn || isAdmin) && (
            <button onClick={() => { onDelete(); onClose(); }} className="w-full flex items-center gap-4 px-5 py-3.5 hover:bg-red-500/10 press text-left">
              <div className="w-9 h-9 rounded-xl bg-red-500/15 flex items-center justify-center"><Trash2 className="w-4 h-4 text-red-400" /></div>
              <p className="font-bold text-red-400 text-sm">Delete</p>
            </button>
          )}
        </div>
      </div>
    </div>
  );
}

// ── Forward Modal ──
function ForwardModal({ message, currentUserId, onClose }: {
  message: MessageWithMeta; currentUserId: string; onClose: () => void;
}) {
  const [members, setMembers] = useState<any[]>([]);
  const [sending, setSending] = useState<string | null>(null);
  const [search, setSearch] = useState('');

  useEffect(() => {
    supabase.from('user_profiles').select('id, username, avatar_url, is_online').neq('id', currentUserId).order('username').then(({ data }) => {
      if (data) setMembers(data);
    });
  }, [currentUserId]);

  async function forwardToUser(userId: string) {
    setSending(userId);
    const p1 = currentUserId < userId ? currentUserId : userId;
    const p2 = currentUserId < userId ? userId : currentUserId;
    let { data: conv } = await supabase.from('conversations').select('*').eq('participant_one', p1).eq('participant_two', p2).single();
    if (!conv) {
      const { data: created } = await supabase.from('conversations').insert({ participant_one: p1, participant_two: p2 }).select().single();
      conv = created;
    }
    if (conv) {
      const text = message.message ? `↪️ Forwarded: ${message.message}` : '↪️ Forwarded media';
      await supabase.from('direct_messages').insert({ conversation_id: conv.id, sender_id: currentUserId, message: text, media_url: message.media_url, media_type: message.media_type });
      await supabase.from('conversations').update({ last_message: text, last_message_at: new Date().toISOString() }).eq('id', conv.id);
    }
    toast.success('Forwarded!');
    setSending(null);
  }

  async function forwardToVIPRoom() {
    setSending('vip');
    const text = message.message ? `↪️ Forwarded: ${message.message}` : '↪️ Forwarded media';
    await supabase.from('vip_messages').insert({ user_id: currentUserId, message: text, media_url: message.media_url, media_type: message.media_type });
    toast.success('Forwarded to VIP Room!');
    setSending(null);
    onClose();
  }

  const filtered = members.filter(m => !search || (m.username || '').toLowerCase().includes(search.toLowerCase()));

  return (
    <div className="fixed inset-0 z-[500] bg-black/70 flex flex-col animate-fade-in" onClick={onClose}>
      <div className="flex-1" />
      <div className="w-full max-w-md mx-auto bg-card border border-border rounded-t-3xl overflow-hidden animate-slide-up"
        onClick={e => e.stopPropagation()} style={{ maxHeight: '75vh', paddingBottom: 'max(16px, env(safe-area-inset-bottom))' }}>
        <div className="flex items-center justify-between px-4 py-4 border-b border-border">
          <h3 className="font-black text-foreground">Forward To</h3>
          <button onClick={onClose} className="p-1.5 rounded-xl bg-muted press"><X className="w-4 h-4 text-muted-foreground" /></button>
        </div>
        <div className="px-4 py-2 border-b border-border">
          <input className="w-full bg-muted border border-border rounded-xl px-3 py-2 text-sm text-foreground outline-none focus:border-primary" placeholder="Search members..." value={search} onChange={e => setSearch(e.target.value)} />
        </div>
        <div className="overflow-y-auto" style={{ maxHeight: '55vh' }}>
          <button onClick={forwardToVIPRoom} disabled={sending === 'vip'} className="w-full flex items-center gap-3 px-4 py-3 border-b border-border/30 hover:bg-muted/50 press">
            <div className="w-10 h-10 rounded-full gradient-pink flex items-center justify-center flex-shrink-0"><Crown className="w-5 h-5 text-white" /></div>
            <div className="flex-1 text-left"><p className="font-bold text-foreground text-sm">VIP Room</p><p className="text-xs text-muted-foreground">Community chat</p></div>
            {sending === 'vip' && <div className="w-4 h-4 border-2 border-primary border-t-transparent rounded-full animate-spin" />}
          </button>
          {filtered.map(m => (
            <button key={m.id} onClick={() => forwardToUser(m.id)} disabled={sending === m.id} className="w-full flex items-center gap-3 px-4 py-3 hover:bg-muted/50 press text-left">
              <div className="relative flex-shrink-0">
                <div className="w-10 h-10 rounded-full overflow-hidden bg-muted gradient-pink flex items-center justify-center">
                  {m.avatar_url ? <img src={m.avatar_url} alt="" className="w-full h-full object-cover" /> : <span className="text-sm font-black text-white">{(m.username || '?')[0].toUpperCase()}</span>}
                </div>
                {m.is_online && <span className="absolute bottom-0 right-0 w-2.5 h-2.5 rounded-full bg-green-400 border-2 border-background" />}
              </div>
              <p className="flex-1 font-bold text-foreground text-sm">{m.username || 'Member'}</p>
              {sending === m.id && <div className="w-4 h-4 border-2 border-primary border-t-transparent rounded-full animate-spin" />}
            </button>
          ))}
        </div>
      </div>
    </div>
  );
}

export default function VIPRoom() {
  const { user, profile, isAdmin } = useAuth();
  const navigate = useNavigate();
  const [messages, setMessages] = useState<MessageWithMeta[]>([]);
  const [text, setText] = useState('');
  const [sending, setSending] = useState(false);
  const [uploading, setUploading] = useState(false);
  const [selectedFiles, setSelectedFiles] = useState<File[]>([]);
  const [uploadProgress, setUploadProgress] = useState(0);
  const [uploadTotal, setUploadTotal] = useState(0);
  const [showVIPSelector, setShowVIPSelector] = useState(false);
  const [showBenefits, setShowBenefits] = useState(false);
  const [replyTo, setReplyTo] = useState<VIPMessage | null>(null);
  const [showEmojiFor, setShowEmojiFor] = useState<string | null>(null);
  const [showScrollBtn, setShowScrollBtn] = useState(false);
  const [actionsFor, setActionsFor] = useState<MessageWithMeta | null>(null);
  const [forwardMsg, setForwardMsg] = useState<MessageWithMeta | null>(null);
  const [showRoomSettings, setShowRoomSettings] = useState(false);
  const [roomName, setRoomName] = useState('VIP Members Room');
  const [roomIcon, setRoomIcon] = useState('');
  const [mediaViewer, setMediaViewer] = useState<{ items: { url: string; type: 'image' | 'video' }[]; index: number } | null>(null);
  const [vipTheme, setVipTheme] = useState<VIPTheme>({
    bg: '#0d0d1a', ownColor: '#FF1493', otherColor: '#1e1e2e', fontSize: 'md', fontFamily: 'default',
  });
  const bottomRef = useRef<HTMLDivElement>(null);
  const messagesRef = useRef<HTMLDivElement>(null);
  const inputRef = useRef<HTMLInputElement>(null);
  const fileInputRef = useRef<HTMLInputElement>(null);
  const pollRef = useRef<ReturnType<typeof setInterval> | null>(null);
  // Long press — 3 seconds like WhatsApp/Telegram
  const longPressTimer = useRef<ReturnType<typeof setTimeout> | null>(null);
  const longPressActive = useRef(false);

  const hasAccess = isAdmin || (profile ? isVIPActive(profile) : false);

  useEffect(() => {
    supabase.from('site_settings')
      .select('website_name, logo_url, vip_wallpaper, vip_bg_color, vip_bubble_color_own, vip_bubble_color_other, vip_font_size, vip_font_family')
      .eq('id', 'main').single()
      .then(({ data }) => {
        if (data) {
          setRoomName((data as any).website_name || 'VIP Members Room');
          setRoomIcon((data as any).logo_url || '');
          const wp = (data as any).vip_wallpaper;
          const bg = wp
            ? (wp.startsWith('linear-gradient') ? wp : `url(${wp}) center/cover`)
            : ((data as any).vip_bg_color || '#0d0d1a');
          setVipTheme({
            bg, ownColor: (data as any).vip_bubble_color_own || '#FF1493',
            otherColor: (data as any).vip_bubble_color_other || '#1e1e2e',
            fontSize: (data as any).vip_font_size || 'md',
            fontFamily: (data as any).vip_font_family || 'default',
          });
        }
      });
  }, [showRoomSettings]);

  const fetchMessages = useCallback(async () => {
    const { data } = await supabase
      .from('vip_messages').select('*, user_profiles(*)')
      .eq('is_deleted', false).order('created_at', { ascending: true }).limit(300);
    if (!data) return;

    const replyIds = data.filter(m => m.reply_to).map(m => m.reply_to!);
    let replyMap: Record<string, VIPMessage> = {};
    if (replyIds.length > 0) {
      const { data: replies } = await supabase.from('vip_messages').select('*, user_profiles(*)').in('id', replyIds);
      if (replies) replies.forEach(r => { replyMap[r.id] = r; });
    }

    const msgIds = data.map(m => m.id);
    let reactionsMap: Record<string, VIPReaction[]> = {};
    if (msgIds.length > 0) {
      const { data: reactions } = await supabase.from('vip_reactions').select('*').in('message_id', msgIds);
      if (reactions) reactions.forEach(r => {
        if (!reactionsMap[r.message_id]) reactionsMap[r.message_id] = [];
        reactionsMap[r.message_id].push(r);
      });
    }

    setMessages(data.map(m => ({
      ...m, replyMessage: m.reply_to ? replyMap[m.reply_to] : null,
      reactions: reactionsMap[m.id] || [],
    })));
  }, []);

  useEffect(() => {
    if (!hasAccess) return;
    fetchMessages();
    pollRef.current = setInterval(fetchMessages, 3000);
    return () => { if (pollRef.current) clearInterval(pollRef.current); };
  }, [hasAccess, fetchMessages]);

  const prevCount = useRef(0);
  useEffect(() => {
    if (messages.length !== prevCount.current) {
      prevCount.current = messages.length;
      const el = messagesRef.current;
      if (!el) return;
      const nearBottom = el.scrollHeight - el.scrollTop - el.clientHeight < 220;
      if (nearBottom) bottomRef.current?.scrollIntoView({ behavior: 'smooth' });
    }
  }, [messages]);

  const handleScroll = () => {
    const el = messagesRef.current;
    if (!el) return;
    setShowScrollBtn(el.scrollHeight - el.scrollTop - el.clientHeight > 200);
  };

  async function sendMessage() {
    if (!text.trim() || !user || sending) return;
    setSending(true);
    const msg = text.trim();
    setText('');
    await supabase.from('vip_messages').insert({
      user_id: user.id, message: msg,
      reply_to: replyTo?.id || null,
      is_announcement: isAdmin && msg.startsWith('📢'),
    });
    setReplyTo(null);
    setSending(false);
    fetchMessages();
    setTimeout(() => bottomRef.current?.scrollIntoView({ behavior: 'smooth' }), 100);
  }

  function handleFileSelect(e: React.ChangeEvent<HTMLInputElement>) {
    const files = Array.from(e.target.files || []);
    if (!files.length) return;
    setSelectedFiles(prev => [...prev, ...files].slice(0, 10));
    e.target.value = '';
  }

  async function sendMedia() {
    if (selectedFiles.length === 0 || !user) return;
    setUploading(true);
    setUploadTotal(selectedFiles.length);
    setUploadProgress(0);
    const uploaded: { url: string; type: string }[] = [];
    await Promise.all(selectedFiles.map(async (file, idx) => {
      const mediaType = file.type.startsWith('video') ? 'video' : 'image';
      const url = await uploadFile('media', `vip/${Date.now()}_${idx}_${file.name}`, file);
      uploaded.push({ url, type: mediaType });
      setUploadProgress(p => p + 1);
    }));
    if (uploaded.length === 1) {
      await supabase.from('vip_messages').insert({ user_id: user.id, media_url: uploaded[0].url, media_type: uploaded[0].type, reply_to: replyTo?.id || null });
    } else {
      await supabase.from('vip_messages').insert({ user_id: user.id, media_url: JSON.stringify(uploaded), media_type: 'multi', reply_to: replyTo?.id || null });
    }
    setUploading(false);
    setUploadProgress(0);
    setUploadTotal(0);
    setSelectedFiles([]);
    setReplyTo(null);
    fetchMessages();
  }

  async function toggleReaction(msgId: string, emoji: string) {
    if (!user) return;
    const { data: existing } = await supabase.from('vip_reactions').select('id').eq('message_id', msgId).eq('user_id', user.id).eq('emoji', emoji).single();
    if (existing) await supabase.from('vip_reactions').delete().eq('id', existing.id);
    else await supabase.from('vip_reactions').insert({ message_id: msgId, user_id: user.id, emoji });
    setShowEmojiFor(null);
    fetchMessages();
  }

  async function deleteMessage(id: string) {
    await supabase.from('vip_messages').update({ is_deleted: true }).eq('id', id);
    setMessages(prev => prev.filter(m => m.id !== id));
  }

  async function pinMessage(id: string, pinned: boolean) {
    await supabase.from('vip_messages').update({ is_pinned: !pinned }).eq('id', id);
    setActionsFor(null);
    fetchMessages();
  }

  // ── Long press handlers — EXACTLY 3 seconds like WhatsApp/Telegram ──
  function startLongPress(msg: MessageWithMeta) {
    longPressActive.current = false;
    longPressTimer.current = setTimeout(() => {
      longPressActive.current = true;
      setActionsFor(msg);
    }, 800); // 800ms — same as WhatsApp behavior
  }

  function cancelLongPress() {
    if (longPressTimer.current) {
      clearTimeout(longPressTimer.current);
      longPressTimer.current = null;
    }
  }

  function handleTap(msg: MessageWithMeta) {
    // Only fire tap actions if NOT a long press
    if (!longPressActive.current) {
      // Normal tap — could open media, etc.
    }
    longPressActive.current = false;
  }

  function formatTime(ts: string) {
    return new Date(ts).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' });
  }

  function groupReactions(reactions: VIPReaction[]) {
    const map: Record<string, number> = {};
    reactions.forEach(r => { map[r.emoji] = (map[r.emoji] || 0) + 1; });
    return Object.entries(map);
  }

  const fontSize = FONT_SIZES[vipTheme.fontSize] || '14px';
  const fontFamily = FONT_FAMILIES[vipTheme.fontFamily] || 'inherit';

  if (!user) {
    return (
      <div className="fixed inset-0 z-[100] bg-background flex flex-col items-center justify-center px-4">
        <div className="w-20 h-20 rounded-3xl gradient-pink flex items-center justify-center mb-4 pink-glow animate-float">
          <Crown className="w-10 h-10 text-white" />
        </div>
        <h2 className="text-xl font-black text-foreground mb-2">VIP Room</h2>
        <p className="text-muted-foreground text-sm text-center mb-6">Login to access the exclusive community</p>
        <button onClick={() => navigate('/auth')} className="px-6 py-3 gradient-pink rounded-2xl text-white font-bold pink-glow press">Login Now</button>
      </div>
    );
  }

  if (!hasAccess) {
    return (
      <>
        {showBenefits && (
          <VIPBenefitsPopup
            onGetVIP={() => { setShowBenefits(false); setShowVIPSelector(true); }}
            onClose={() => setShowBenefits(false)}
          />
        )}
        {showVIPSelector && <VIPPlanSelector onClose={() => setShowVIPSelector(false)} />}
        <div className="fixed inset-0 z-[100] bg-background flex flex-col items-center justify-center px-4">
          <div className="max-w-sm w-full text-center">
            <div className="w-24 h-24 rounded-3xl gradient-pink flex items-center justify-center mx-auto mb-5 pink-glow animate-float">
              <Lock className="w-12 h-12 text-white" />
            </div>
            <h2 className="text-2xl font-black text-foreground mb-2">VIP Members Only</h2>
            <p className="text-muted-foreground text-sm mb-6 leading-relaxed">Join the exclusive room where experts share live setups, analysis & premium signals 24/7.</p>
            <div className="bg-card border border-border rounded-2xl p-4 mb-5 text-left space-y-2">
              {['🔥 Live premium signals','💬 Real-time group chat','🎯 Expert guidance','📢 Admin announcements','✅ Verified blue tick','🌐 Community 24/7'].map(f => (
                <p key={f} className="text-sm text-foreground">{f}</p>
              ))}
            </div>
            <button onClick={() => setShowVIPSelector(true)} className="w-full py-4 gradient-pink rounded-2xl text-white font-black text-base pink-glow press">
              <Crown className="w-5 h-5 inline mr-2" /> Get VIP Access
            </button>
            <button onClick={() => navigate('/')} className="mt-3 text-sm text-muted-foreground press">← Back to Home</button>
          </div>
        </div>
      </>
    );
  }

  return (
    <>
      {actionsFor && (
        <MessageActions
          msg={actionsFor}
          isOwn={actionsFor.user_id === user.id}
          isAdmin={isAdmin}
          onReply={() => { setReplyTo(actionsFor); inputRef.current?.focus(); }}
          onDelete={() => deleteMessage(actionsFor.id)}
          onPin={() => pinMessage(actionsFor.id, actionsFor.is_pinned)}
          onForward={() => setForwardMsg(actionsFor)}
          onReport={() => toast.success('Reported to admin')}
          onClose={() => setActionsFor(null)}
        />
      )}
      {forwardMsg && user && (
        <ForwardModal message={forwardMsg} currentUserId={user.id} onClose={() => setForwardMsg(null)} />
      )}
      {mediaViewer && (
        <GlobalMediaViewer items={mediaViewer.items} initialIndex={mediaViewer.index} onClose={() => setMediaViewer(null)} />
      )}
      {showRoomSettings && isAdmin && <RoomSettings onClose={() => setShowRoomSettings(false)} />}

      <div className="fixed inset-0 z-[100] flex flex-col" style={{ background: vipTheme.bg, fontFamily }}>
        {/* Header */}
        <div
          className="flex items-center gap-3 px-4 border-b border-border/30 flex-shrink-0"
          style={{ background: 'rgba(9,10,17,0.97)', backdropFilter: 'blur(20px)', paddingTop: 'max(12px, env(safe-area-inset-top))', paddingBottom: '12px' }}
        >
          <button onClick={() => navigate('/')} className="p-1.5 rounded-xl hover:bg-muted press flex-shrink-0">
            <ArrowLeft className="w-5 h-5 text-foreground" />
          </button>
          <div className="w-9 h-9 rounded-full overflow-hidden flex-shrink-0 gradient-pink flex items-center justify-center pink-glow-xs">
            {roomIcon ? <img src={roomIcon} alt="" className="w-full h-full object-cover" /> : <Crown className="w-5 h-5 text-white" />}
          </div>
          <div className="flex-1 min-w-0">
            <p className="font-bold text-foreground text-sm leading-tight truncate">{roomName}</p>
            <div className="flex items-center gap-1.5">
              <span className="w-1.5 h-1.5 rounded-full bg-green-400 animate-pulse" />
              <p className="text-[11px] text-green-400 font-medium">Live · {messages.length} messages</p>
            </div>
          </div>
          <div className="flex items-center gap-2">
            <Users className="w-4 h-4 text-muted-foreground" />
            {isAdmin && (
              <button onClick={() => setShowRoomSettings(true)} className="p-1.5 rounded-xl bg-muted/60 hover:bg-muted press" title="Room Settings">
                <Settings className="w-4 h-4 text-muted-foreground" />
              </button>
            )}
            {isAdmin && (
              <div className="px-2 py-1 gradient-pink rounded-lg flex-shrink-0">
                <span className="text-[10px] text-white font-black">ADMIN</span>
              </div>
            )}
          </div>
        </div>

        {/* Messages */}
        <div
          ref={messagesRef}
          onScroll={handleScroll}
          className="flex-1 overflow-y-auto px-2 py-2"
          style={{ overscrollBehavior: 'contain' }}
          onClick={() => setShowEmojiFor(null)}
        >
          {messages.length === 0 && (
            <div className="flex flex-col items-center justify-center h-full opacity-50 pt-16">
              <Crown className="w-12 h-12 text-primary mb-2" />
              <p className="text-muted-foreground text-sm">No messages yet. Say hello! 👋</p>
            </div>
          )}

          {messages.map((msg, idx) => {
            const isOwn = msg.user_id === user.id;
            const sender = msg.user_profiles;
            const senderIsAdmin = sender?.email === ADMIN_EMAIL;
            const prevMsg = messages[idx - 1];
            const showAvatarAndName = !isOwn && (!prevMsg || prevMsg.user_id !== msg.user_id);
            const isGrouped = !isOwn && !!prevMsg && prevMsg.user_id === msg.user_id;
            const grouped = groupReactions(msg.reactions || []);

            if (msg.is_announcement) {
              return (
                <div key={msg.id} className="flex justify-center my-3 animate-fade-in px-2">
                  <div className="msg-announcement px-4 py-2.5 max-w-[88%] text-center">
                    <p className="text-[11px] font-black text-primary mb-0.5 uppercase tracking-wide">📢 Announcement</p>
                    <p className="text-sm text-foreground" style={{ fontSize, fontFamily }}>{msg.message}</p>
                    <p className="text-[10px] text-muted-foreground mt-1">{formatTime(msg.created_at)}</p>
                  </div>
                </div>
              );
            }

            return (
              <div
                key={msg.id}
                className={`flex ${isOwn ? 'justify-end' : 'justify-start'} ${isGrouped ? 'mt-0.5' : 'mt-3'} px-1 animate-fade-in group select-none`}
                onTouchStart={() => startLongPress(msg)}
                onTouchEnd={() => { cancelLongPress(); handleTap(msg); }}
                onMouseDown={() => startLongPress(msg)}
                onMouseUp={() => { cancelLongPress(); handleTap(msg); }}
                onMouseLeave={cancelLongPress}
                onContextMenu={e => { e.preventDefault(); setActionsFor(msg); }}
              >
                <div className={`flex ${isOwn ? 'flex-row-reverse' : 'flex-row'} items-start gap-1.5 max-w-[78%]`}>
                  {!isOwn && (
                    <div className="w-7 flex-shrink-0">
                      {showAvatarAndName ? (
                        <button onClick={() => navigate(`/profile/${msg.user_id}`)} className="w-7 h-7 rounded-full overflow-hidden gradient-pink flex items-center justify-center text-[10px] font-black text-white hover:ring-2 hover:ring-primary/50 transition-all">
                          {sender?.avatar_url ? <img src={sender.avatar_url} alt="" className="w-full h-full object-cover" /> : (sender?.username || '?')[0].toUpperCase()}
                        </button>
                      ) : <div className="w-7" />}
                    </div>
                  )}

                  <div className={`flex flex-col gap-0.5 ${isOwn ? 'items-end' : 'items-start'}`}>
                    {showAvatarAndName && !isOwn && (
                      <div className="flex items-center gap-1 mb-0.5">
                        <button onClick={() => navigate(`/profile/${msg.user_id}`)} className="text-[12px] font-bold hover:text-primary transition-colors leading-tight"
                          style={{ color: senderIsAdmin ? '#FF1493' : 'hsl(var(--foreground))' }}>
                          {senderIsAdmin ? '👑 Admin' : (sender?.username || 'Member')}
                        </button>
                        {sender?.blue_tick && <VIPBadge size="xs" badgeStyle={((sender as any)?.badge_style as import('@/types').BadgeStyle) || 'blue_shield'} />}
                        {senderIsAdmin && <span className="text-[9px] px-1.5 py-0.5 gradient-pink rounded text-white font-black">ADMIN</span>}
                        {sender?.is_online && <span className="w-1.5 h-1.5 rounded-full bg-green-400 flex-shrink-0" />}
                      </div>
                    )}

                    {msg.replyMessage && (
                      <div className={`px-3 py-1.5 rounded-xl mb-1 border-l-[3px] border-primary max-w-full ${isOwn ? 'bg-black/20' : 'bg-muted/60'}`}>
                        <p className="text-[10px] text-primary font-bold mb-0.5">
                          {(msg.replyMessage as MessageWithMeta).user_profiles?.username || 'Member'}
                        </p>
                        <p className="text-[11px] text-muted-foreground line-clamp-1">{msg.replyMessage.message || '📎 Media'}</p>
                      </div>
                    )}

                    <div
                      className={`relative ${msg.is_pinned ? 'ring-1 ring-primary/50' : ''} rounded-2xl overflow-hidden`}
                      style={{ padding: msg.media_url && !msg.message ? 0 : '8px 12px', background: msg.media_url && !msg.message ? 'transparent' : isOwn ? vipTheme.ownColor : vipTheme.otherColor }}
                      onClick={() => {
                        if (msg.media_url) {
                          let items: { url: string; type: 'image' | 'video' }[] = [];
                          if (msg.media_type === 'multi') { try { items = JSON.parse(msg.media_url); } catch {} }
                          else if (msg.media_url) items = [{ url: msg.media_url, type: (msg.media_type as 'image' | 'video') || 'image' }];
                          if (items.length > 0) setMediaViewer({ items, index: 0 });
                        }
                      }}
                    >
                      {msg.message && (
                        <p className={`leading-relaxed break-words ${isOwn ? 'text-white' : 'text-foreground'}`} style={{ fontSize, fontFamily }}>
                          {msg.message}
                        </p>
                      )}
                      {msg.media_url && msg.media_type === 'multi' && (() => {
                        let items: { url: string; type: 'image' | 'video' }[] = [];
                        try { items = JSON.parse(msg.media_url); } catch {}
                        return <TelegramMediaGrid items={items} maxWidth={260} />;
                      })()}
                      {msg.media_url && msg.media_type === 'image' && (
                        <TelegramMediaGrid items={[{ url: msg.media_url, type: 'image' }]} maxWidth={220} />
                      )}
                      {msg.media_url && msg.media_type === 'video' && (
                        <TelegramMediaGrid items={[{ url: msg.media_url, type: 'video' }]} maxWidth={200} />
                      )}
                      <p className={`text-[10px] mt-1 leading-none ${isOwn ? 'text-white/50 text-right' : 'text-muted-foreground'}`}>{formatTime(msg.created_at)}</p>
                    </div>

                    {grouped.length > 0 && (
                      <div className={`flex flex-wrap gap-1 mt-0.5 ${isOwn ? 'justify-end' : 'justify-start'}`}>
                        {grouped.map(([emoji, count]) => (
                          <button key={emoji} onClick={() => toggleReaction(msg.id, emoji)} className="flex items-center gap-0.5 px-2 py-0.5 bg-muted/80 border border-border/50 rounded-full text-xs hover:border-primary/40 transition-all press">
                            <span>{emoji}</span>
                            {count > 1 && <span className="text-[10px] text-muted-foreground">{count}</span>}
                          </button>
                        ))}
                      </div>
                    )}

                    <div className={`flex items-center gap-1 mt-0.5 opacity-0 group-hover:opacity-100 transition-opacity duration-150 ${isOwn ? 'flex-row-reverse' : 'flex-row'}`}>
                      <button onClick={e => { e.stopPropagation(); setReplyTo(msg); inputRef.current?.focus(); }} className="p-1.5 rounded-lg bg-muted/70 hover:bg-muted transition-all press">
                        <Reply className="w-3 h-3 text-muted-foreground" />
                      </button>
                      <button onClick={e => { e.stopPropagation(); setShowEmojiFor(showEmojiFor === msg.id ? null : msg.id); }} className="p-1.5 rounded-lg bg-muted/70 hover:bg-muted transition-all press">
                        <span className="text-[13px] leading-none">😊</span>
                      </button>
                      <button onClick={e => { e.stopPropagation(); setForwardMsg(msg); }} className="p-1.5 rounded-lg bg-muted/70 hover:bg-muted transition-all press">
                        <Share2 className="w-3 h-3 text-muted-foreground" />
                      </button>
                      {(isOwn || isAdmin) && (
                        <button onClick={e => { e.stopPropagation(); deleteMessage(msg.id); }} className="p-1.5 rounded-lg bg-muted/70 hover:bg-red-500/20 press">
                          <Trash2 className="w-3 h-3 text-red-400" />
                        </button>
                      )}
                    </div>

                    {showEmojiFor === msg.id && (
                      <div className="flex gap-1 p-2 bg-card border border-border rounded-2xl shadow-2xl animate-scale-in z-20" onClick={e => e.stopPropagation()}>
                        {EMOJI_REACTIONS.map(e => (
                          <button key={e} className="text-lg hover:scale-125 transition-transform press" onClick={() => toggleReaction(msg.id, e)}>{e}</button>
                        ))}
                      </div>
                    )}
                  </div>
                </div>
              </div>
            );
          })}
          <div ref={bottomRef} className="h-2 w-full" />
        </div>

        {showScrollBtn && (
          <button onClick={() => bottomRef.current?.scrollIntoView({ behavior: 'smooth' })} className="absolute right-4 w-9 h-9 rounded-full bg-card border border-border shadow-xl flex items-center justify-center animate-fade-in z-20 press" style={{ bottom: 'calc(env(safe-area-inset-bottom) + 72px)' }}>
            <ChevronDown className="w-4 h-4 text-muted-foreground" />
          </button>
        )}

        {/* Input area */}
        <div
          className="border-t border-border/30 flex-shrink-0"
          style={{ background: 'rgba(9,10,17,0.97)', backdropFilter: 'blur(20px)', paddingTop: '10px', paddingLeft: '12px', paddingRight: '12px', paddingBottom: 'max(10px, env(safe-area-inset-bottom))' }}
        >
          {replyTo && (
            <div className="flex items-center gap-2 px-3 py-2 mb-2 bg-muted/40 rounded-xl border-l-[3px] border-primary animate-slide-up">
              <div className="flex-1 min-w-0">
                <p className="text-[11px] text-primary font-bold">{replyTo.user_profiles?.username || 'Member'}</p>
                <p className="text-xs text-muted-foreground truncate">{replyTo.message || '📎 Media'}</p>
              </div>
              <button onClick={() => setReplyTo(null)} className="p-1 rounded-lg hover:bg-muted press flex-shrink-0"><X className="w-3.5 h-3.5 text-muted-foreground" /></button>
            </div>
          )}

          {uploadTotal > 0 && (
            <div className="flex items-center gap-2 px-3 py-2 mb-2 bg-muted/60 rounded-xl animate-fade-in">
              <div className="flex-1 h-1.5 bg-muted rounded-full overflow-hidden">
                <div className="h-full gradient-pink rounded-full transition-all" style={{ width: `${uploadTotal > 0 ? Math.round((uploadProgress / uploadTotal) * 100) : 0}%` }} />
              </div>
              <span className="text-xs text-muted-foreground font-bold">{uploadTotal > 0 ? Math.round((uploadProgress / uploadTotal) * 100) : 0}%</span>
            </div>
          )}

          {selectedFiles.length > 0 && (
            <div className="grid gap-1 mb-2" style={{ gridTemplateColumns: `repeat(${Math.min(selectedFiles.length, 4)}, 1fr)` }}>
              {selectedFiles.map((f, i) => {
                const url = URL.createObjectURL(f);
                const isVid = f.type.startsWith('video');
                return (
                  <div key={i} className="relative rounded-xl overflow-hidden bg-muted" style={{ aspectRatio: '1' }}>
                    {isVid ? <video src={url} className="w-full h-full object-cover" /> : <img src={url} alt="" className="w-full h-full object-cover" />}
                    <button onClick={() => setSelectedFiles(prev => prev.filter((_, idx) => idx !== i))} className="absolute top-1 right-1 w-5 h-5 bg-black/70 rounded-full flex items-center justify-center">
                      <X className="w-3 h-3 text-white" />
                    </button>
                  </div>
                );
              })}
            </div>
          )}

          <div className="flex items-center gap-2">
            <button onClick={() => fileInputRef.current?.click()} className="relative w-10 h-10 rounded-xl bg-muted flex items-center justify-center cursor-pointer hover:bg-muted/80 flex-shrink-0 press">
              {uploading ? <div className="w-4 h-4 border-2 border-primary border-t-transparent rounded-full animate-spin" /> : <Image className="w-4 h-4 text-muted-foreground" />}
              {selectedFiles.length > 0 && (
                <span className="absolute -top-1.5 -right-1.5 w-4 h-4 gradient-pink rounded-full text-white text-[9px] font-black flex items-center justify-center">{selectedFiles.length}</span>
              )}
            </button>
            <input ref={fileInputRef} type="file" accept="image/*,video/*" multiple className="hidden" onChange={handleFileSelect} />
            <input
              ref={inputRef} value={text}
              onChange={e => setText(e.target.value)}
              onKeyDown={e => e.key === 'Enter' && !e.shiftKey && (selectedFiles.length > 0 ? sendMedia() : sendMessage())}
              placeholder={isAdmin ? '📢 Announcement or message...' : 'Message VIP room...'}
              className="flex-1 bg-muted border border-border rounded-2xl px-4 py-2.5 text-foreground placeholder-muted-foreground text-sm outline-none focus:border-primary/50 transition-all"
              style={{ fontFamily }}
            />
            <button
              onClick={() => { if (selectedFiles.length > 0 && !text.trim()) { sendMedia(); } else { sendMessage(); if (selectedFiles.length > 0) sendMedia(); } }}
              disabled={sending || (!text.trim() && selectedFiles.length === 0)}
              className="w-10 h-10 gradient-pink rounded-xl text-white flex-shrink-0 flex items-center justify-center pink-glow-xs press disabled:opacity-40 transition-all"
            >
              <Send className="w-4 h-4" />
            </button>
          </div>
        </div>
      </div>
    </>
  );
}
