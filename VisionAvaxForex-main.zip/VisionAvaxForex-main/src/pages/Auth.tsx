import { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { supabase } from '@/lib/supabase';
import { useAuth } from '@/contexts/AuthContext';
import { User } from '@supabase/supabase-js';
import { toast } from 'sonner';
import { Eye, EyeOff, Mail, Lock, ArrowLeft, TrendingUp, Shield } from 'lucide-react';

type Step = 'choice' | 'login' | 'register-email' | 'register-otp' | 'register-pass';

function mapUser(user: User) {
  return {
    id: user.id,
    email: user.email!,
    username: user.user_metadata?.username || user.email!.split('@')[0],
    avatar: user.user_metadata?.avatar_url,
    is_admin: user.email === 'visionavaxforex@gmail.com',
  };
}

export default function Auth() {
  const { login } = useAuth();
  const navigate = useNavigate();
  const [step, setStep] = useState<Step>('choice');
  const [email, setEmail] = useState('');
  const [otp, setOtp] = useState('');
  const [password, setPassword] = useState('');
  const [showPass, setShowPass] = useState(false);
  const [loading, setLoading] = useState(false);
  const [authBgUrl, setAuthBgUrl] = useState('');

  useEffect(() => {
    const params = new URLSearchParams(window.location.search);
    const ref = params.get('ref');
    if (ref) localStorage.setItem('vaf_ref', ref);
    // Load auth bg from settings
    supabase.from('site_settings').select('auth_bg_url').eq('id', 'main').single().then(({ data }) => {
      if (data && (data as any).auth_bg_url) setAuthBgUrl((data as any).auth_bg_url);
    });
  }, []);

  async function handleSendOTP() {
    if (!email) return toast.error('Enter your email');
    setLoading(true);
    const { error } = await supabase.auth.signInWithOtp({ email, options: { shouldCreateUser: true } });
    if (error) { toast.error(error.message); setLoading(false); return; }
    toast.success('Verification code sent!');
    setStep('register-otp');
    setLoading(false);
  }

  async function handleVerifyOTP() {
    if (!otp) return toast.error('Enter the verification code');
    setLoading(true);
    const { error } = await supabase.auth.verifyOtp({ email, token: otp, type: 'email' });
    if (error) { toast.error(error.message); setLoading(false); return; }
    setStep('register-pass');
    setLoading(false);
  }

  async function handleSetPassword() {
    if (password.length < 6) return toast.error('Password must be at least 6 characters');
    setLoading(true);
    const username = email.split('@')[0];
    const { data, error } = await supabase.auth.updateUser({ password, data: { username } });
    if (error) { toast.error(error.message); setLoading(false); return; }
    if (data.user) {
      login(mapUser(data.user));
      // Track referral registration
      const ref = localStorage.getItem('vaf_ref');
      if (ref) {
        await supabase.from('referral_events').insert({ referral_code: ref, user_id: data.user.id, event_type: 'register', user_email: email });
        await supabase.rpc('increment_referral_registrations', { code: ref }).catch(() => {});
        localStorage.removeItem('vaf_ref');
      }
      navigate('/');
    }
    setLoading(false);
  }

  async function handleLogin() {
    if (!email || !password) return toast.error('Enter email and password');
    setLoading(true);
    const { data, error } = await supabase.auth.signInWithPassword({ email, password });
    if (error) { toast.error(error.message); setLoading(false); return; }
    if (data.user) { login(mapUser(data.user)); navigate('/'); }
  }

  const inputClass = "w-full bg-muted border border-border rounded-xl px-4 py-3.5 text-foreground placeholder-muted-foreground text-sm focus:border-primary outline-none transition-all";

  return (
    <div className="min-h-screen bg-background flex flex-col">
      {/* Hero top */}
      <div className="gradient-pink-dark px-6 pt-16 pb-14 relative overflow-hidden" style={authBgUrl ? { backgroundImage: `url(${authBgUrl})`, backgroundSize: 'cover', backgroundPosition: 'center' } : {}}>
        <div className="absolute inset-0">
          <div className="absolute top-6 right-6 w-36 h-36 rounded-full bg-white/10 blur-3xl" />
          <div className="absolute bottom-0 left-8 w-24 h-24 rounded-full bg-white/8 blur-2xl" />
        </div>
        <div className="relative">
          <div className="flex items-center gap-2 mb-5">
            <div className="w-8 h-8 rounded-xl bg-white/20 flex items-center justify-center">
              <TrendingUp className="w-5 h-5 text-white" />
            </div>
            <span className="text-white/75 text-xs font-black tracking-widest uppercase">Vision Avax Forex</span>
          </div>
          <h1 className="text-3xl font-black text-white mb-1.5 leading-tight">
            {step === 'choice' && 'Welcome Back'}
            {step === 'login' && 'Sign In'}
            {step === 'register-email' && 'Create Account'}
            {step === 'register-otp' && 'Verify Email'}
            {step === 'register-pass' && 'Set Password'}
          </h1>
          <p className="text-white/60 text-sm">
            {step === 'choice' && 'Premium forex trading community'}
            {step === 'login' && 'Enter your credentials to continue'}
            {step === 'register-email' && "We'll send a 4-digit code to verify your email"}
            {step === 'register-otp' && `Code sent to ${email}`}
            {step === 'register-pass' && 'Choose a secure password to protect your account'}
          </p>
        </div>
      </div>

      {/* Form card */}
      <div className="flex-1 px-4 -mt-6 relative z-10">
        <div className="bg-card border border-border/60 rounded-3xl p-6 shadow-2xl animate-slide-up">

          {step === 'choice' && (
            <div className="space-y-3">
              <button onClick={() => setStep('login')} className="w-full py-4 gradient-pink rounded-2xl text-white font-bold text-base pink-glow hover:opacity-90 transition-all press">
                Login to Account
              </button>
              <button onClick={() => setStep('register-email')} className="w-full py-4 border border-primary/35 rounded-2xl text-primary font-bold text-base hover:bg-primary/5 transition-all press">
                Create New Account
              </button>
              <div className="flex items-center gap-2 mt-4 p-3 bg-muted/50 rounded-2xl">
                <Shield className="w-4 h-4 text-primary flex-shrink-0" />
                <p className="text-xs text-muted-foreground">Secured with end-to-end encryption</p>
              </div>
            </div>
          )}

          {step === 'login' && (
            <div className="space-y-4">
              <button onClick={() => setStep('choice')} className="flex items-center gap-2 text-muted-foreground text-sm mb-1 press">
                <ArrowLeft className="w-4 h-4" /> Back
              </button>
              <div className="relative">
                <Mail className="absolute left-3.5 top-3.5 w-4 h-4 text-muted-foreground" />
                <input className={`${inputClass} pl-10`} type="email" placeholder="Email address" value={email} onChange={e => setEmail(e.target.value)} onKeyDown={e => e.key === 'Enter' && handleLogin()} />
              </div>
              <div className="relative">
                <Lock className="absolute left-3.5 top-3.5 w-4 h-4 text-muted-foreground" />
                <input className={`${inputClass} pl-10 pr-11`} type={showPass ? 'text' : 'password'} placeholder="Password" value={password} onChange={e => setPassword(e.target.value)} onKeyDown={e => e.key === 'Enter' && handleLogin()} />
                <button onClick={() => setShowPass(!showPass)} className="absolute right-3.5 top-3.5 press">
                  {showPass ? <EyeOff className="w-4 h-4 text-muted-foreground" /> : <Eye className="w-4 h-4 text-muted-foreground" />}
                </button>
              </div>
              <button onClick={handleLogin} disabled={loading} className="w-full py-4 gradient-pink rounded-2xl text-white font-bold text-base pink-glow disabled:opacity-50 press">
                {loading ? 'Signing in...' : 'Login'}
              </button>
              <p className="text-center text-sm text-muted-foreground">
                No account? <button onClick={() => setStep('register-email')} className="text-primary font-bold press">Register</button>
              </p>
            </div>
          )}

          {step === 'register-email' && (
            <div className="space-y-4">
              <button onClick={() => setStep('choice')} className="flex items-center gap-2 text-muted-foreground text-sm mb-1 press">
                <ArrowLeft className="w-4 h-4" /> Back
              </button>
              <div className="relative">
                <Mail className="absolute left-3.5 top-3.5 w-4 h-4 text-muted-foreground" />
                <input className={`${inputClass} pl-10`} type="email" placeholder="Your email address" value={email} onChange={e => setEmail(e.target.value)} onKeyDown={e => e.key === 'Enter' && handleSendOTP()} />
              </div>
              <button onClick={handleSendOTP} disabled={loading} className="w-full py-4 gradient-pink rounded-2xl text-white font-bold text-base pink-glow disabled:opacity-50 press">
                {loading ? 'Sending Code...' : 'Send Verification Code →'}
              </button>
              <p className="text-center text-sm text-muted-foreground">
                Already registered? <button onClick={() => setStep('login')} className="text-primary font-bold press">Login</button>
              </p>
            </div>
          )}

          {step === 'register-otp' && (
            <div className="space-y-4">
              <button onClick={() => setStep('register-email')} className="flex items-center gap-2 text-muted-foreground text-sm mb-1 press">
                <ArrowLeft className="w-4 h-4" /> Change email
              </button>
              <div className="p-3 bg-primary/10 border border-primary/20 rounded-xl">
                <p className="text-xs text-muted-foreground">Code sent to <span className="text-foreground font-bold">{email}</span></p>
              </div>
              <input
                className="w-full bg-muted border border-border rounded-xl px-4 py-5 text-foreground text-center text-4xl tracking-[0.7em] font-black focus:border-primary outline-none transition-all"
                type="text"
                inputMode="numeric"
                placeholder="0000"
                maxLength={4}
                value={otp}
                onChange={e => setOtp(e.target.value.replace(/\D/g, ''))}
              />
              <button onClick={handleVerifyOTP} disabled={loading || otp.length < 4} className="w-full py-4 gradient-pink rounded-2xl text-white font-bold text-base pink-glow disabled:opacity-50 press">
                {loading ? 'Verifying...' : 'Verify Code →'}
              </button>
              <button onClick={handleSendOTP} className="w-full text-sm text-muted-foreground hover:text-primary transition-colors press">Resend code</button>
            </div>
          )}

          {step === 'register-pass' && (
            <div className="space-y-4">
              <div className="p-3 bg-green-500/10 border border-green-500/20 rounded-xl flex items-center gap-2">
                <div className="w-4 h-4 rounded-full bg-green-500 flex items-center justify-center flex-shrink-0">
                  <span className="text-white text-[8px] font-black">✓</span>
                </div>
                <p className="text-xs text-green-400 font-medium">Email verified successfully!</p>
              </div>
              <div className="relative">
                <Lock className="absolute left-3.5 top-3.5 w-4 h-4 text-muted-foreground" />
                <input
                  className={`${inputClass} pl-10 pr-11`}
                  type={showPass ? 'text' : 'password'}
                  placeholder="Create password (min 6 characters)"
                  value={password}
                  onChange={e => setPassword(e.target.value)}
                  onKeyDown={e => e.key === 'Enter' && handleSetPassword()}
                />
                <button onClick={() => setShowPass(!showPass)} className="absolute right-3.5 top-3.5 press">
                  {showPass ? <EyeOff className="w-4 h-4 text-muted-foreground" /> : <Eye className="w-4 h-4 text-muted-foreground" />}
                </button>
              </div>
              <button onClick={handleSetPassword} disabled={loading} className="w-full py-4 gradient-pink rounded-2xl text-white font-bold text-base pink-glow disabled:opacity-50 press">
                {loading ? 'Creating Account...' : 'Create Account ✓'}
              </button>
            </div>
          )}
        </div>

        <p className="text-center text-xs text-muted-foreground mt-6 pb-10">
          By continuing you agree to our Terms of Service
        </p>
      </div>
    </div>
  );
}
