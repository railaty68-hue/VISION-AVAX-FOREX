import { useState, useEffect } from 'react';
import { Link, Plus, Copy, Users, MousePointer, CreditCard, Trash2 } from 'lucide-react';
import { supabase } from '@/lib/supabase';
import { ReferralLink } from '@/types';
import { toast } from 'sonner';

export default function AdminReferrals() {
  const [links, setLinks] = useState<ReferralLink[]>([]);
  const [events, setEvents] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);
  const [newLabel, setNewLabel] = useState('');
  const [saving, setSaving] = useState(false);

  useEffect(() => { fetchData(); }, []);

  async function fetchData() {
    setLoading(true);
    const [l, e] = await Promise.all([
      supabase.from('referral_links').select('*').order('created_at', { ascending: false }),
      supabase.from('referral_events').select('*').order('created_at', { ascending: false }).limit(50),
    ]);
    if (l.data) setLinks(l.data);
    if (e.data) setEvents(e.data);
    setLoading(false);
  }

  function generateCode() {
    return Math.random().toString(36).substring(2, 8).toUpperCase();
  }

  async function createLink() {
    if (!newLabel) return toast.error('Enter a label');
    setSaving(true);
    const code = generateCode();
    await supabase.from('referral_links').insert({ code, label: newLabel });
    toast.success('Referral link created!');
    setNewLabel('');
    fetchData();
    setSaving(false);
  }

  function copyLink(code: string) {
    const url = `${window.location.origin}?ref=${code}`;
    navigator.clipboard.writeText(url);
    toast.success('Link copied!');
  }

  async function deleteLink(id: string) {
    await supabase.from('referral_links').delete().eq('id', id);
    fetchData();
    toast.success('Link deleted');
  }

  const totalClicks = links.reduce((a, l) => a + l.clicks, 0);
  const totalRegs = links.reduce((a, l) => a + l.registrations, 0);
  const totalPays = links.reduce((a, l) => a + l.payments, 0);

  return (
    <div className="space-y-5">
      {/* Stats */}
      <div className="grid grid-cols-3 gap-3">
        {[
          { icon: MousePointer, val: totalClicks, label: 'Total Clicks', color: 'text-blue-400', bg: 'bg-blue-500/10' },
          { icon: Users, val: totalRegs, label: 'Registrations', color: 'text-green-400', bg: 'bg-green-500/10' },
          { icon: CreditCard, val: totalPays, label: 'Payments', color: 'text-primary', bg: 'bg-primary/10' },
        ].map(({ icon: Icon, val, label, color, bg }) => (
          <div key={label} className={`${bg} rounded-2xl p-3 text-center border border-border`}>
            <Icon className={`w-4 h-4 ${color} mx-auto mb-1`} />
            <p className={`text-lg font-black ${color}`}>{val}</p>
            <p className="text-[10px] text-muted-foreground">{label}</p>
          </div>
        ))}
      </div>

      {/* Create link */}
      <div className="bg-card border border-border rounded-2xl p-4">
        <h3 className="font-bold text-white mb-4 flex items-center gap-2"><Link className="w-4 h-4 text-primary" /> Create Referral Link</h3>
        <div className="flex gap-2">
          <input className="flex-1 bg-muted border border-border rounded-xl px-3 py-2.5 text-white text-sm outline-none focus:border-primary" placeholder="Label (e.g. Instagram post, WhatsApp)" value={newLabel} onChange={e => setNewLabel(e.target.value)} />
          <button onClick={createLink} disabled={saving} className="px-4 py-2.5 gradient-pink rounded-xl text-white text-sm font-bold flex items-center gap-1.5 disabled:opacity-50 flex-shrink-0">
            <Plus className="w-4 h-4" /> Create
          </button>
        </div>
      </div>

      {/* Links list */}
      <div className="bg-card border border-border rounded-2xl p-4">
        <h3 className="font-bold text-white mb-4">Your Referral Links ({links.length})</h3>
        {loading ? (
          <div className="space-y-2">{Array.from({ length: 3 }).map((_, i) => <div key={i} className="h-16 bg-muted/30 rounded-xl animate-pulse" />)}</div>
        ) : links.length === 0 ? (
          <div className="text-center py-8">
            <Link className="w-8 h-8 text-muted-foreground mx-auto mb-2" />
            <p className="text-sm text-muted-foreground">No referral links yet</p>
          </div>
        ) : (
          <div className="space-y-3">
            {links.map(link => (
              <div key={link.id} className="p-3 bg-muted/20 rounded-xl border border-border">
                <div className="flex items-start justify-between gap-2 mb-2">
                  <div>
                    <p className="text-sm font-bold text-white">{link.label}</p>
                    <p className="text-xs text-muted-foreground font-mono">{window.location.origin}?ref={link.code}</p>
                  </div>
                  <div className="flex gap-1.5">
                    <button onClick={() => copyLink(link.code)} className="p-1.5 rounded-lg bg-muted hover:bg-muted/80"><Copy className="w-4 h-4 text-muted-foreground" /></button>
                    <button onClick={() => deleteLink(link.id)} className="p-1.5 rounded-lg bg-red-500/10 hover:bg-red-500/20"><Trash2 className="w-4 h-4 text-red-400" /></button>
                  </div>
                </div>
                <div className="grid grid-cols-3 gap-2">
                  <div className="text-center bg-blue-500/10 rounded-lg p-1.5">
                    <p className="text-sm font-black text-blue-400">{link.clicks}</p>
                    <p className="text-[10px] text-muted-foreground">Clicks</p>
                  </div>
                  <div className="text-center bg-green-500/10 rounded-lg p-1.5">
                    <p className="text-sm font-black text-green-400">{link.registrations}</p>
                    <p className="text-[10px] text-muted-foreground">Joined</p>
                  </div>
                  <div className="text-center bg-primary/10 rounded-lg p-1.5">
                    <p className="text-sm font-black text-primary">{link.payments}</p>
                    <p className="text-[10px] text-muted-foreground">Paid</p>
                  </div>
                </div>
              </div>
            ))}
          </div>
        )}
      </div>

      {/* Recent events */}
      <div className="bg-card border border-border rounded-2xl p-4">
        <h3 className="font-bold text-white mb-4">Recent Activity</h3>
        {events.length === 0 ? (
          <p className="text-sm text-muted-foreground text-center py-4">No activity yet</p>
        ) : (
          <div className="space-y-2">
            {events.slice(0, 20).map(e => (
              <div key={e.id} className="flex items-center gap-3 p-2 rounded-xl bg-muted/20">
                <span className={`w-2 h-2 rounded-full flex-shrink-0 ${e.event_type === 'click' ? 'bg-blue-400' : e.event_type === 'register' ? 'bg-green-400' : 'bg-primary'}`} />
                <div className="flex-1 min-w-0">
                  <p className="text-xs text-white font-medium capitalize">{e.event_type} — ref: {e.referral_code}</p>
                  {e.user_email && <p className="text-[10px] text-muted-foreground truncate">{e.user_email}</p>}
                </div>
                <p className="text-[10px] text-muted-foreground flex-shrink-0">{new Date(e.created_at).toLocaleDateString()}</p>
              </div>
            ))}
          </div>
        )}
      </div>
    </div>
  );
}
