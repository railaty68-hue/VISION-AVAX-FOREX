import { useState, useEffect } from 'react';
import { Users, Search, CheckCircle, XCircle, Crown, Trash2, Volume2, VolumeX } from 'lucide-react';
import { supabase } from '@/lib/supabase';
import { UserProfile } from '@/types';
import VIPBadge from '@/components/features/VIPBadge';
import { toast } from 'sonner';

export default function AdminUsers() {
  const [users, setUsers] = useState<UserProfile[]>([]);
  const [loading, setLoading] = useState(true);
  const [search, setSearch] = useState('');

  useEffect(() => {
    fetchUsers();
  }, []);

  async function fetchUsers() {
    setLoading(true);
    const { data } = await supabase.from('user_profiles').select('*').order('joined_at', { ascending: false });
    if (data) setUsers(data);
    setLoading(false);
  }

  async function toggleVIP(user: UserProfile) {
    const expires = user.is_vip ? null : new Date(Date.now() + 30 * 24 * 60 * 60 * 1000).toISOString();
    await supabase.from('user_profiles').update({ is_vip: !user.is_vip, vip_expires_at: expires, blue_tick: !user.is_vip }).eq('id', user.id);
    toast.success(`VIP ${user.is_vip ? 'removed' : 'activated'}`);
    fetchUsers();
  }

  async function toggleBlueTick(user: UserProfile) {
    await supabase.from('user_profiles').update({ blue_tick: !user.blue_tick }).eq('id', user.id);
    toast.success(`Blue tick ${user.blue_tick ? 'removed' : 'added'}`);
    fetchUsers();
  }

  async function toggleBan(user: UserProfile) {
    await supabase.from('user_profiles').update({ is_banned: !user.is_banned }).eq('id', user.id);
    toast.success(`User ${user.is_banned ? 'unbanned' : 'banned'}`);
    fetchUsers();
  }

  async function toggleMute(user: UserProfile) {
    await supabase.from('user_profiles').update({ is_muted: !user.is_muted }).eq('id', user.id);
    toast.success(`User ${user.is_muted ? 'unmuted' : 'muted'}`);
    fetchUsers();
  }

  async function deleteUser(id: string) {
    if (!confirm('Delete this user? This cannot be undone.')) return;
    await supabase.from('user_profiles').delete().eq('id', id);
    toast.success('User deleted');
    fetchUsers();
  }

  const filtered = users.filter(u => u.email?.toLowerCase().includes(search.toLowerCase()) || u.username?.toLowerCase().includes(search.toLowerCase()));

  return (
    <div className="space-y-4">
      <div className="bg-card border border-border rounded-2xl p-4">
        <div className="flex items-center justify-between mb-4">
          <h3 className="font-bold text-white flex items-center gap-2"><Users className="w-4 h-4 text-primary" /> All Users ({users.length})</h3>
        </div>

        <div className="relative mb-4">
          <Search className="absolute left-3 top-2.5 w-4 h-4 text-muted-foreground" />
          <input className="w-full bg-muted border border-border rounded-xl pl-9 pr-4 py-2 text-white text-sm outline-none focus:border-primary" placeholder="Search users..." value={search} onChange={e => setSearch(e.target.value)} />
        </div>

        {/* Stats */}
        <div className="grid grid-cols-3 gap-2 mb-4">
          <div className="bg-muted/50 rounded-xl p-2 text-center">
            <p className="text-sm font-black text-white">{users.length}</p>
            <p className="text-[10px] text-muted-foreground">Total</p>
          </div>
          <div className="bg-primary/10 rounded-xl p-2 text-center">
            <p className="text-sm font-black text-primary">{users.filter(u => u.is_vip).length}</p>
            <p className="text-[10px] text-muted-foreground">VIP</p>
          </div>
          <div className="bg-red-500/10 rounded-xl p-2 text-center">
            <p className="text-sm font-black text-red-400">{users.filter(u => u.is_banned).length}</p>
            <p className="text-[10px] text-muted-foreground">Banned</p>
          </div>
        </div>

        {loading ? (
          <div className="space-y-2">
            {Array.from({ length: 4 }).map((_, i) => <div key={i} className="h-16 bg-muted/30 rounded-xl animate-pulse" />)}
          </div>
        ) : (
          <div className="space-y-2">
            {filtered.map(u => (
              <div key={u.id} className={`p-3 rounded-xl border ${u.is_banned ? 'border-red-500/30 bg-red-500/5' : 'border-border bg-muted/20'}`}>
                <div className="flex items-center gap-3 mb-2">
                  <div className="w-9 h-9 rounded-full gradient-pink flex items-center justify-center text-white text-sm font-bold flex-shrink-0">
                    {(u.username || u.email || '?')[0].toUpperCase()}
                  </div>
                  <div className="flex-1 min-w-0">
                    <div className="flex items-center gap-1.5">
                      <p className="text-sm font-bold text-white truncate">{u.username || 'No username'}</p>
                      {u.blue_tick && <VIPBadge />}
                      {u.is_vip && <Crown className="w-3.5 h-3.5 text-primary" />}
                    </div>
                    <p className="text-xs text-muted-foreground truncate">{u.email}</p>
                  </div>
                  <div className="flex items-center gap-1">
                    {u.is_banned ? (
                      <span className="text-[10px] px-1.5 py-0.5 bg-red-500/20 text-red-400 rounded font-bold">BANNED</span>
                    ) : u.is_vip ? (
                      <span className="text-[10px] px-1.5 py-0.5 bg-primary/20 text-primary rounded font-bold">VIP</span>
                    ) : null}
                  </div>
                </div>
                <div className="flex gap-1.5 flex-wrap">
                  <button onClick={() => toggleVIP(u)} className={`px-2.5 py-1 rounded-lg text-[11px] font-bold flex items-center gap-1 transition-all ${u.is_vip ? 'bg-primary/20 text-primary' : 'bg-muted text-muted-foreground hover:text-white'}`}>
                    <Crown className="w-3 h-3" />{u.is_vip ? 'Remove VIP' : 'Give VIP'}
                  </button>
                  <button onClick={() => toggleBlueTick(u)} className={`px-2.5 py-1 rounded-lg text-[11px] font-bold flex items-center gap-1 ${u.blue_tick ? 'bg-blue-500/20 text-blue-400' : 'bg-muted text-muted-foreground hover:text-white'}`}>
                    <CheckCircle className="w-3 h-3" />{u.blue_tick ? 'Remove ✓' : 'Add ✓'}
                  </button>
                  <button onClick={() => toggleMute(u)} className={`px-2.5 py-1 rounded-lg text-[11px] font-bold flex items-center gap-1 ${u.is_muted ? 'bg-yellow-500/20 text-yellow-400' : 'bg-muted text-muted-foreground hover:text-white'}`}>
                    {u.is_muted ? <Volume2 className="w-3 h-3" /> : <VolumeX className="w-3 h-3" />}{u.is_muted ? 'Unmute' : 'Mute'}
                  </button>
                  <button onClick={() => toggleBan(u)} className={`px-2.5 py-1 rounded-lg text-[11px] font-bold flex items-center gap-1 ${u.is_banned ? 'bg-green-500/20 text-green-400' : 'bg-red-500/20 text-red-400'}`}>
                    <XCircle className="w-3 h-3" />{u.is_banned ? 'Unban' : 'Ban'}
                  </button>
                  <button onClick={() => deleteUser(u.id)} className="px-2.5 py-1 rounded-lg text-[11px] font-bold bg-red-500/10 text-red-400 flex items-center gap-1 hover:bg-red-500/20">
                    <Trash2 className="w-3 h-3" />Delete
                  </button>
                </div>
              </div>
            ))}
          </div>
        )}
      </div>
    </div>
  );
}
