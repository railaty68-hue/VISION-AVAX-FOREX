import { useState, useEffect } from 'react';
import { BarChart, Bar, PieChart, Pie, Cell, XAxis, YAxis, Tooltip, ResponsiveContainer, Legend } from 'recharts';
import { TrendingUp, Target, Award, AlertTriangle } from 'lucide-react';
import { supabase } from '@/lib/supabase';
import { Signal } from '@/types';

const COLORS = {
  win: '#4ADE80',
  loss: '#F87171',
  pending: '#FBBF24',
  forex: '#4DAEFF',
  gold: '#FFD700',
  crypto: '#FF6B6B',
};

interface Stats {
  totalSignals: number;
  wins: number;
  losses: number;
  active: number;
  winRate: number;
  totalPips: number;
  byCategory: { name: string; win: number; loss: number; active: number }[];
  pieData: { name: string; value: number; color: string }[];
}

export default function AdminSignalAnalytics() {
  const [signals, setSignals] = useState<Signal[]>([]);
  const [loading, setLoading] = useState(true);
  const [period, setPeriod] = useState<'7d' | '30d' | 'all'>('30d');

  useEffect(() => { fetchSignals(); }, [period]);

  async function fetchSignals() {
    setLoading(true);
    let query = supabase.from('signals').select('*').order('created_at', { ascending: false });

    if (period !== 'all') {
      const days = period === '7d' ? 7 : 30;
      const since = new Date(Date.now() - days * 24 * 60 * 60 * 1000).toISOString();
      query = query.gte('created_at', since);
    }

    const { data } = await query;
    if (data) setSignals(data);
    setLoading(false);
  }

  const stats: Stats = (() => {
    const wins = signals.filter(s => s.result === 'win').length;
    const losses = signals.filter(s => s.result === 'loss').length;
    const active = signals.filter(s => s.status === 'active').length;
    const closed = wins + losses;
    const winRate = closed > 0 ? Math.round((wins / closed) * 100) : 0;

    const totalPips = signals.reduce((sum, s) => {
      const pips = parseFloat(s.pips || '0');
      return sum + (isNaN(pips) ? 0 : pips);
    }, 0);

    const cats = ['forex', 'gold', 'crypto'] as const;
    const byCategory = cats.map(cat => ({
      name: cat.charAt(0).toUpperCase() + cat.slice(1),
      win: signals.filter(s => s.type === cat && s.result === 'win').length,
      loss: signals.filter(s => s.type === cat && s.result === 'loss').length,
      active: signals.filter(s => s.type === cat && s.status === 'active').length,
    }));

    const pieData = [
      { name: 'Win', value: wins, color: COLORS.win },
      { name: 'Loss', value: losses, color: COLORS.loss },
      { name: 'Active', value: active, color: COLORS.pending },
    ].filter(d => d.value > 0);

    return { totalSignals: signals.length, wins, losses, active, winRate, totalPips, byCategory, pieData };
  })();

  const CustomTooltip = ({ active, payload, label }: any) => {
    if (!active || !payload?.length) return null;
    return (
      <div className="bg-card border border-border rounded-xl p-3 text-xs shadow-2xl">
        <p className="font-bold text-foreground mb-1">{label}</p>
        {payload.map((p: any) => (
          <p key={p.name} style={{ color: p.fill }}>{p.name}: <strong>{p.value}</strong></p>
        ))}
      </div>
    );
  };

  if (loading) return (
    <div className="space-y-3">
      {Array.from({ length: 4 }).map((_, i) => <div key={i} className="h-20 bg-muted/30 rounded-2xl animate-pulse" />)}
    </div>
  );

  return (
    <div className="space-y-4">
      {/* Period filter */}
      <div className="flex gap-2">
        {(['7d', '30d', 'all'] as const).map(p => (
          <button
            key={p}
            onClick={() => setPeriod(p)}
            className={`flex-1 py-2 rounded-xl text-xs font-bold transition-all press ${period === p ? 'gradient-pink text-white' : 'bg-muted text-muted-foreground'}`}
          >
            {p === 'all' ? 'All Time' : p === '7d' ? 'Last 7 Days' : 'Last 30 Days'}
          </button>
        ))}
      </div>

      {/* Summary cards */}
      <div className="grid grid-cols-2 gap-2">
        <div className="bg-card border border-border rounded-2xl p-4">
          <div className="flex items-center gap-2 mb-1">
            <Target className="w-4 h-4 text-green-400" />
            <p className="text-xs text-muted-foreground">Win Rate</p>
          </div>
          <p className="text-2xl font-black text-green-400">{stats.winRate}%</p>
          <p className="text-[10px] text-muted-foreground">{stats.wins}W · {stats.losses}L</p>
        </div>
        <div className="bg-card border border-border rounded-2xl p-4">
          <div className="flex items-center gap-2 mb-1">
            <TrendingUp className="w-4 h-4 text-primary" />
            <p className="text-xs text-muted-foreground">Total Pips</p>
          </div>
          <p className="text-2xl font-black text-primary">{stats.totalPips > 0 ? '+' : ''}{stats.totalPips.toFixed(0)}</p>
          <p className="text-[10px] text-muted-foreground">This period</p>
        </div>
        <div className="bg-card border border-border rounded-2xl p-4">
          <div className="flex items-center gap-2 mb-1">
            <Award className="w-4 h-4 text-yellow-400" />
            <p className="text-xs text-muted-foreground">Active</p>
          </div>
          <p className="text-2xl font-black text-yellow-400">{stats.active}</p>
          <p className="text-[10px] text-muted-foreground">Live signals</p>
        </div>
        <div className="bg-card border border-border rounded-2xl p-4">
          <div className="flex items-center gap-2 mb-1">
            <AlertTriangle className="w-4 h-4 text-red-400" />
            <p className="text-xs text-muted-foreground">Total Signals</p>
          </div>
          <p className="text-2xl font-black text-foreground">{stats.totalSignals}</p>
          <p className="text-[10px] text-muted-foreground">This period</p>
        </div>
      </div>

      {/* Pie Chart — Win rate */}
      {stats.pieData.length > 0 && (
        <div className="bg-card border border-border rounded-2xl p-4">
          <h3 className="font-bold text-foreground mb-3 text-sm">Signal Outcomes</h3>
          <ResponsiveContainer width="100%" height={200}>
            <PieChart>
              <Pie
                data={stats.pieData}
                cx="50%"
                cy="50%"
                innerRadius={55}
                outerRadius={85}
                dataKey="value"
                strokeWidth={0}
                label={({ name, value }) => `${name}: ${value}`}
                labelLine={false}
              >
                {stats.pieData.map((entry, index) => (
                  <Cell key={index} fill={entry.color} />
                ))}
              </Pie>
              <Tooltip content={<CustomTooltip />} />
              <Legend
                formatter={(value, entry: any) => <span style={{ color: entry.color, fontSize: 11 }}>{value}</span>}
              />
            </PieChart>
          </ResponsiveContainer>
          {/* Win rate center label */}
          <div className="text-center -mt-2">
            <p className="text-sm text-muted-foreground">Overall win rate: <span className="font-black text-green-400">{stats.winRate}%</span></p>
          </div>
        </div>
      )}

      {/* Bar Chart — By Category */}
      <div className="bg-card border border-border rounded-2xl p-4">
        <h3 className="font-bold text-foreground mb-3 text-sm">Performance by Category</h3>
        {stats.byCategory.every(c => c.win + c.loss + c.active === 0) ? (
          <div className="text-center py-8 text-muted-foreground text-sm">No signal data for this period</div>
        ) : (
          <ResponsiveContainer width="100%" height={200}>
            <BarChart data={stats.byCategory} barGap={4}>
              <XAxis dataKey="name" tick={{ fill: 'hsl(var(--muted-foreground))', fontSize: 11 }} axisLine={false} tickLine={false} />
              <YAxis tick={{ fill: 'hsl(var(--muted-foreground))', fontSize: 11 }} axisLine={false} tickLine={false} />
              <Tooltip content={<CustomTooltip />} />
              <Bar dataKey="win" name="Win" fill={COLORS.win} radius={[4, 4, 0, 0]} />
              <Bar dataKey="loss" name="Loss" fill={COLORS.loss} radius={[4, 4, 0, 0]} />
              <Bar dataKey="active" name="Active" fill={COLORS.pending} radius={[4, 4, 0, 0]} />
            </BarChart>
          </ResponsiveContainer>
        )}
      </div>

      {/* Category breakdown */}
      <div className="bg-card border border-border rounded-2xl p-4">
        <h3 className="font-bold text-foreground mb-3 text-sm">Category Breakdown</h3>
        <div className="space-y-3">
          {stats.byCategory.map(cat => {
            const total = cat.win + cat.loss;
            const wr = total > 0 ? Math.round((cat.win / total) * 100) : 0;
            const catColor = cat.name === 'Forex' ? COLORS.forex : cat.name === 'Gold' ? COLORS.gold : COLORS.crypto;
            return (
              <div key={cat.name} className="flex items-center gap-3">
                <div className="w-16 flex-shrink-0">
                  <p className="text-xs font-bold text-foreground">{cat.name}</p>
                  <p className="text-[10px] text-muted-foreground">{cat.win}W · {cat.loss}L</p>
                </div>
                <div className="flex-1 h-2.5 bg-muted rounded-full overflow-hidden">
                  <div
                    className="h-full rounded-full transition-all duration-500"
                    style={{ width: `${wr}%`, background: catColor }}
                  />
                </div>
                <p className="text-xs font-black w-10 text-right" style={{ color: catColor }}>{wr}%</p>
              </div>
            );
          })}
        </div>
      </div>
    </div>
  );
}
