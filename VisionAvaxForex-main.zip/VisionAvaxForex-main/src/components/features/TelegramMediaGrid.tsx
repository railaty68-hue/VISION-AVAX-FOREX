import { useState, useRef, useEffect } from 'react';
import { Play } from 'lucide-react';
import GlobalMediaViewer from './GlobalMediaViewer';

interface MediaItem {
  url: string;
  type: 'image' | 'video';
}

interface Props {
  items: MediaItem[];
  maxWidth?: number;
  gridStyle?: string; // 'telegram' | 'whatsapp' | 'grid2' | 'grid3' | 'mosaic' | 'strip'
}

type AspectRatio = 'portrait' | 'landscape' | 'square';

interface ImgDimensions { ratio: AspectRatio; w: number; h: number }

function useImageDimensions(url: string): ImgDimensions {
  const [dims, setDims] = useState<ImgDimensions>({ ratio: 'landscape', w: 4, h: 3 });
  useEffect(() => {
    if (!url) return;
    const img = new Image();
    img.onload = () => {
      const r = img.naturalWidth / img.naturalHeight;
      setDims({
        ratio: r < 0.8 ? 'portrait' : r > 1.3 ? 'landscape' : 'square',
        w: img.naturalWidth,
        h: img.naturalHeight,
      });
    };
    img.src = url;
  }, [url]);
  return dims;
}

function MediaThumb({ item, idx, style, onClick }: { item: MediaItem; idx: number; style?: React.CSSProperties; onClick: () => void }) {
  const isVideo = item.type === 'video';
  return (
    <div
      className="relative overflow-hidden bg-muted/40 cursor-pointer select-none rounded-[2px]"
      style={style}
      onClick={onClick}
    >
      {isVideo ? (
        <>
          <video src={item.url} className="w-full h-full object-cover" muted playsInline preload="metadata" />
          <div className="absolute inset-0 flex items-center justify-center bg-black/20">
            <div className="w-10 h-10 rounded-full bg-black/60 flex items-center justify-center shadow-lg">
              <Play className="w-5 h-5 text-white fill-white ml-0.5" />
            </div>
          </div>
        </>
      ) : (
        <img src={item.url} alt="" className="w-full h-full object-cover" loading="lazy" />
      )}
    </div>
  );
}

// Single image component that auto-detects aspect ratio
function SingleMedia({ item, onClick, maxWidth }: { item: MediaItem; onClick: () => void; maxWidth: number }) {
  const [naturalRatio, setNaturalRatio] = useState<number | null>(null);
  const isVideo = item.type === 'video';

  useEffect(() => {
    if (isVideo) return;
    const img = new Image();
    img.onload = () => setNaturalRatio(img.naturalWidth / img.naturalHeight);
    img.src = item.url;
  }, [item.url, isVideo]);

  // Determine display dimensions based on natural ratio
  let displayHeight: number;
  const w = maxWidth;
  if (naturalRatio === null) {
    displayHeight = w * 0.75; // fallback 4:3
  } else if (naturalRatio < 0.6) {
    // Very portrait (like 9:16) — show tall
    displayHeight = Math.min(w * 1.4, 420);
  } else if (naturalRatio < 0.9) {
    // Mildly portrait
    displayHeight = Math.min(w * 1.1, 360);
  } else if (naturalRatio > 1.8) {
    // Very wide
    displayHeight = w * 0.45;
  } else {
    // Landscape or square
    displayHeight = w * 0.65;
  }

  return (
    <div style={{ width: w, maxWidth: '100%' }} className="rounded-2xl overflow-hidden">
      <div className="relative overflow-hidden cursor-pointer select-none bg-muted/40" style={{ width: '100%', height: displayHeight }} onClick={onClick}>
        {isVideo ? (
          <>
            <video src={item.url} className="w-full h-full object-cover" muted playsInline preload="metadata" />
            <div className="absolute inset-0 flex items-center justify-center bg-black/20">
              <div className="w-12 h-12 rounded-full bg-black/60 flex items-center justify-center shadow-xl">
                <Play className="w-6 h-6 text-white fill-white ml-0.5" />
              </div>
            </div>
          </>
        ) : (
          <img src={item.url} alt="" className="w-full h-full object-cover" loading="lazy" />
        )}
      </div>
    </div>
  );
}

export default function TelegramMediaGrid({ items, maxWidth = 260, gridStyle = 'telegram' }: Props) {
  const [viewerIndex, setViewerIndex] = useState<number | null>(null);

  if (items.length === 0) return null;

  const open = (idx: number) => setViewerIndex(idx);
  const close = () => setViewerIndex(null);
  const count = items.length;
  const w = maxWidth;
  const GAP = 2;

  let gridEl: JSX.Element;

  // ── Grid Style: TELEGRAM (default Telegram-like smart layout) ──
  if (gridStyle === 'telegram' || !gridStyle) {
    if (count === 1) {
      gridEl = <SingleMedia item={items[0]} onClick={() => open(0)} maxWidth={w} />;
    } else if (count === 2) {
      // 2 items: side by side portrait-friendly
      const cellH = Math.round(w * 0.7);
      gridEl = (
        <div style={{ width: w, maxWidth: '100%', display: 'flex', gap: GAP }} className="rounded-2xl overflow-hidden">
          <MediaThumb item={items[0]} idx={0} style={{ flex: 1, height: cellH }} onClick={() => open(0)} />
          <MediaThumb item={items[1]} idx={1} style={{ flex: 1, height: cellH }} onClick={() => open(1)} />
        </div>
      );
    } else if (count === 3) {
      // LEFT: 1 tall portrait | RIGHT: 2 stacked (like the WhatsApp image in request)
      const totalH = Math.round(w * 0.85);
      const rightH = Math.round((totalH - GAP) / 2);
      gridEl = (
        <div style={{ width: w, maxWidth: '100%', display: 'flex', gap: GAP, height: totalH }} className="rounded-2xl overflow-hidden">
          <div style={{ flex: '0 0 55%', height: totalH }}>
            <MediaThumb item={items[0]} idx={0} style={{ width: '100%', height: '100%' }} onClick={() => open(0)} />
          </div>
          <div style={{ flex: 1, display: 'flex', flexDirection: 'column', gap: GAP, height: totalH }}>
            <MediaThumb item={items[1]} idx={1} style={{ flex: 1, height: rightH }} onClick={() => open(1)} />
            <MediaThumb item={items[2]} idx={2} style={{ flex: 1, height: rightH }} onClick={() => open(2)} />
          </div>
        </div>
      );
    } else if (count === 4) {
      // 2×2 grid
      const cellH = Math.round((w - GAP) / 2 * 0.85);
      gridEl = (
        <div style={{ width: w, maxWidth: '100%', display: 'grid', gridTemplateColumns: '1fr 1fr', gap: GAP }} className="rounded-2xl overflow-hidden">
          {items.map((item, i) => <MediaThumb key={i} item={item} idx={i} style={{ height: cellH }} onClick={() => open(i)} />)}
        </div>
      );
    } else if (count === 5) {
      // Top row: 2, bottom row: 3
      const topH = Math.round(w * 0.45);
      const botH = Math.round(w * 0.33);
      gridEl = (
        <div style={{ width: w, maxWidth: '100%' }} className="rounded-2xl overflow-hidden">
          <div style={{ display: 'flex', gap: GAP, marginBottom: GAP }}>
            {items.slice(0, 2).map((item, i) => <MediaThumb key={i} item={item} idx={i} style={{ flex: 1, height: topH }} onClick={() => open(i)} />)}
          </div>
          <div style={{ display: 'flex', gap: GAP }}>
            {items.slice(2, 5).map((item, i) => <MediaThumb key={i + 2} item={item} idx={i + 2} style={{ flex: 1, height: botH }} onClick={() => open(i + 2)} />)}
          </div>
        </div>
      );
    } else {
      // 6+: top big + grid of 4, with overflow indicator
      const topH = Math.round(w * 0.55);
      const botH = Math.round(w * 0.3);
      const showExtra = count > 5;
      const extra = count - 5;
      gridEl = (
        <div style={{ width: w, maxWidth: '100%' }} className="rounded-2xl overflow-hidden">
          <div style={{ marginBottom: GAP }}>
            <MediaThumb item={items[0]} idx={0} style={{ width: '100%', height: topH }} onClick={() => open(0)} />
          </div>
          <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr 1fr 1fr', gap: GAP }}>
            {items.slice(1, 5).map((item, i) => (
              <div key={i + 1} className="relative">
                <MediaThumb item={item} idx={i + 1} style={{ height: botH }} onClick={() => open(i + 1)} />
                {i === 3 && showExtra && (
                  <div className="absolute inset-0 bg-black/70 flex items-center justify-center cursor-pointer rounded-[2px]" onClick={() => open(5)}>
                    <span className="text-white text-lg font-black">+{extra}</span>
                  </div>
                )}
              </div>
            ))}
          </div>
        </div>
      );
    }
  }
  // ── Grid Style: WHATSAPP (left big + stacked right, always) ──
  else if (gridStyle === 'whatsapp') {
    if (count === 1) {
      gridEl = <SingleMedia item={items[0]} onClick={() => open(0)} maxWidth={w} />;
    } else if (count === 2) {
      const h = Math.round(w * 0.6);
      gridEl = (
        <div style={{ width: w, maxWidth: '100%', display: 'flex', gap: GAP, height: h }} className="rounded-2xl overflow-hidden">
          <MediaThumb item={items[0]} idx={0} style={{ flex: 1, height: h }} onClick={() => open(0)} />
          <MediaThumb item={items[1]} idx={1} style={{ flex: 1, height: h }} onClick={() => open(1)} />
        </div>
      );
    } else {
      const totalH = Math.round(w * 0.9);
      const extra = count - 3;
      gridEl = (
        <div style={{ width: w, maxWidth: '100%', display: 'flex', gap: GAP, height: totalH }} className="rounded-2xl overflow-hidden">
          <div style={{ flex: '0 0 60%', height: totalH }}>
            <MediaThumb item={items[0]} idx={0} style={{ width: '100%', height: '100%' }} onClick={() => open(0)} />
          </div>
          <div style={{ flex: 1, display: 'flex', flexDirection: 'column', gap: GAP, height: totalH }}>
            <MediaThumb item={items[1]} idx={1} style={{ flex: 1 }} onClick={() => open(1)} />
            <div className="relative flex-1">
              <MediaThumb item={items[2]} idx={2} style={{ width: '100%', height: '100%' }} onClick={() => open(2)} />
              {extra > 0 && (
                <div className="absolute inset-0 bg-black/70 flex items-center justify-center cursor-pointer rounded-[2px]" onClick={() => open(3)}>
                  <span className="text-white text-xl font-black">+{extra}</span>
                </div>
              )}
            </div>
          </div>
        </div>
      );
    }
  }
  // ── Grid Style: 2-COLUMN ──
  else if (gridStyle === 'grid2') {
    const cellH = Math.round((w - GAP) / 2 * 0.9);
    gridEl = (
      <div style={{ width: w, maxWidth: '100%', display: 'grid', gridTemplateColumns: '1fr 1fr', gap: GAP }} className="rounded-2xl overflow-hidden">
        {items.map((item, i) => <MediaThumb key={i} item={item} idx={i} style={{ height: cellH }} onClick={() => open(i)} />)}
      </div>
    );
  }
  // ── Grid Style: 3-COLUMN ──
  else if (gridStyle === 'grid3') {
    const cellH = Math.round((w - 2 * GAP) / 3 * 0.9);
    gridEl = (
      <div style={{ width: w, maxWidth: '100%', display: 'grid', gridTemplateColumns: '1fr 1fr 1fr', gap: GAP }} className="rounded-2xl overflow-hidden">
        {items.map((item, i) => <MediaThumb key={i} item={item} idx={i} style={{ height: cellH }} onClick={() => open(i)} />)}
      </div>
    );
  }
  // ── Grid Style: STRIP (horizontal scroll) ──
  else if (gridStyle === 'strip') {
    const cellH = Math.round(w * 0.45);
    const cellW = Math.round(cellH * 0.75);
    gridEl = (
      <div style={{ display: 'flex', gap: GAP, overflowX: 'auto' }} className="rounded-2xl overflow-hidden scrollbar-hide">
        {items.map((item, i) => (
          <div key={i} style={{ flex: `0 0 ${cellW}px`, height: cellH }}>
            <MediaThumb item={item} idx={i} style={{ width: '100%', height: '100%' }} onClick={() => open(i)} />
          </div>
        ))}
      </div>
    );
  }
  // ── Grid Style: MOSAIC (Pinterest-like alternating big/small) ──
  else if (gridStyle === 'mosaic') {
    const bigH = Math.round(w * 0.6);
    const smallH = Math.round(bigH * 0.48);
    const pairs: JSX.Element[] = [];
    for (let i = 0; i < items.length; i += 3) {
      const bigLeft = i % 6 === 0;
      const group = items.slice(i, i + 3);
      pairs.push(
        <div key={i} style={{ display: 'flex', gap: GAP, marginBottom: GAP, height: bigH }}>
          {bigLeft ? (
            <>
              <div style={{ flex: '0 0 55%', height: bigH }}>
                {group[0] && <MediaThumb item={group[0]} idx={i} style={{ width: '100%', height: '100%' }} onClick={() => open(i)} />}
              </div>
              <div style={{ flex: 1, display: 'flex', flexDirection: 'column', gap: GAP }}>
                {group[1] && <MediaThumb item={group[1]} idx={i + 1} style={{ flex: 1 }} onClick={() => open(i + 1)} />}
                {group[2] && <MediaThumb item={group[2]} idx={i + 2} style={{ flex: 1 }} onClick={() => open(i + 2)} />}
              </div>
            </>
          ) : (
            <>
              <div style={{ flex: 1, display: 'flex', flexDirection: 'column', gap: GAP }}>
                {group[0] && <MediaThumb item={group[0]} idx={i} style={{ flex: 1 }} onClick={() => open(i)} />}
                {group[1] && <MediaThumb item={group[1]} idx={i + 1} style={{ flex: 1 }} onClick={() => open(i + 1)} />}
              </div>
              <div style={{ flex: '0 0 55%', height: bigH }}>
                {group[2] && <MediaThumb item={group[2]} idx={i + 2} style={{ width: '100%', height: '100%' }} onClick={() => open(i + 2)} />}
              </div>
            </>
          )}
        </div>
      );
    }
    gridEl = <div style={{ width: w, maxWidth: '100%' }} className="rounded-2xl overflow-hidden">{pairs}</div>;
  }
  // ── Default fallback ──
  else {
    gridEl = <SingleMedia item={items[0]} onClick={() => open(0)} maxWidth={w} />;
  }

  return (
    <>
      {gridEl}
      {viewerIndex !== null && (
        <GlobalMediaViewer items={items} initialIndex={viewerIndex} onClose={close} />
      )}
    </>
  );
}
