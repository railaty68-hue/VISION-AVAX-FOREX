import { useState } from 'react';
import { X, Crown, Check } from 'lucide-react';
import VIPBadge from '@/components/features/VIPBadge';
import type { BadgeStyle } from '@/types';

interface BadgeSelectorProps {
  currentStyle: BadgeStyle;
  isVIP: boolean;
  onSelect: (style: BadgeStyle) => void;
  onClose: () => void;
  onUpgrade?: () => void;
}

// All available badge options grouped by color
const BADGE_GROUPS: { label: string; color: string; styles: BadgeStyle[] }[] = [
  {
    label: 'Blue',
    color: '#1877F2',
    styles: ['blue_shield', 'blue_star', 'blue_burst', 'blue_circle', 'blue_wavy'],
  },
  {
    label: 'Green',
    color: '#15803D',
    styles: ['green_shield', 'green_star', 'green_burst', 'green_circle'],
  },
  {
    label: 'Red',
    color: '#E00000',
    styles: ['red_shield', 'red_star', 'red_burst'],
  },
  {
    label: 'Gold',
    color: '#C47600',
    styles: ['gold_shield', 'gold_star', 'gold_burst'],
  },
  {
    label: 'Black',
    color: '#2a2a2a',
    styles: ['black_shield', 'black_star', 'black_burst', 'black_circle'],
  },
  {
    label: 'Gray',
    color: '#6B7280',
    styles: ['gray_shield', 'gray_star', 'gray_burst'],
  },
];

const SHAPE_LABELS: Record<string, string> = {
  shield: 'Shield',
  star:   'Star Seal',
  burst:  'Starburst',
  circle: 'Circle',
  wavy:   'Cloud',
};

export default function BadgeSelector({
  currentStyle,
  isVIP,
  onSelect,
  onClose,
  onUpgrade,
}: BadgeSelectorProps) {
  const [preview, setPreview] = useState<BadgeStyle>(currentStyle);
  const [saving, setSaving] = useState(false);

  async function handleSelect() {
    if (!isVIP) return;
    setSaving(true);
    await onSelect(preview);
    setSaving(false);
    onClose();
  }

  return (
    <div
      className="fixed inset-0 z-[500] bg-black/75 flex items-end justify-center animate-fade-in"
      onClick={onClose}
    >
      <div
        className="w-full max-w-md bg-card border border-border rounded-t-3xl overflow-hidden animate-slide-up"
        style={{ paddingBottom: 'max(24px, env(safe-area-inset-bottom))' }}
        onClick={e => e.stopPropagation()}
      >
        {/* ── Header ── */}
        <div className="flex items-center justify-between px-5 pt-5 pb-4 border-b border-border/50">
          <div>
            <h3 className="font-black text-foreground text-base">Verification Badge</h3>
            <p className="text-xs text-muted-foreground mt-0.5">
              {isVIP ? 'Choose your premium badge style' : 'Premium members only'}
            </p>
          </div>
          <button onClick={onClose} className="w-8 h-8 rounded-xl bg-muted flex items-center justify-center press">
            <X className="w-4 h-4 text-muted-foreground" />
          </button>
        </div>

        {/* ── Non-VIP gate ── */}
        {!isVIP ? (
          <div className="px-5 py-8 flex flex-col items-center text-center">
            <div className="w-16 h-16 rounded-2xl gradient-pink flex items-center justify-center mb-4 pink-glow animate-float">
              <Crown className="w-8 h-8 text-white" />
            </div>
            <h4 className="font-black text-foreground mb-1">VIP Feature</h4>
            <p className="text-sm text-muted-foreground mb-5 max-w-xs">
              Upgrade to a premium plan to unlock custom verification badges and stand out in the community.
            </p>
            <button
              onClick={() => { onClose(); onUpgrade?.(); }}
              className="px-6 py-3 gradient-pink rounded-xl text-white font-bold text-sm press pink-glow-xs"
            >
              Upgrade to VIP
            </button>
          </div>
        ) : (
          <>
            {/* ── Live preview ── */}
            <div className="flex items-center justify-center gap-3 py-5 border-b border-border/50 bg-muted/20">
              <div className="flex items-center gap-2.5 bg-card border border-border rounded-2xl px-5 py-3 shadow-lg">
                <div className="w-9 h-9 rounded-full gradient-pink flex items-center justify-center">
                  <span className="text-white text-sm font-black">V</span>
                </div>
                <span className="font-black text-foreground">Username</span>
                <VIPBadge size="md" badgeStyle={preview} animate />
              </div>
            </div>

            {/* ── Badge grid ── */}
            <div className="px-4 py-4 space-y-4 max-h-[42vh] overflow-y-auto scrollbar-hide">
              {BADGE_GROUPS.map(group => (
                <div key={group.label}>
                  <div className="flex items-center gap-2 mb-2.5">
                    <div
                      className="w-3 h-3 rounded-full flex-shrink-0"
                      style={{ background: group.color }}
                    />
                    <p className="text-xs font-bold text-muted-foreground uppercase tracking-wide">
                      {group.label}
                    </p>
                  </div>
                  <div className="grid grid-cols-3 gap-2">
                    {group.styles.map(style => {
                      const shape = style.split('_')[1];
                      const isSelected = preview === style;
                      const isActive = currentStyle === style;
                      return (
                        <button
                          key={style}
                          onClick={() => setPreview(style)}
                          className={`flex flex-col items-center gap-2 py-3 rounded-2xl border-2 transition-all press ${
                            isSelected
                              ? 'border-primary bg-primary/10'
                              : 'border-border bg-muted/30 hover:border-border/60'
                          }`}
                        >
                          <div className="relative">
                            <VIPBadge size="lg" badgeStyle={style} animate={isSelected} />
                            {isActive && (
                              <div className="absolute -top-1 -right-1 w-4 h-4 rounded-full bg-green-500 border-2 border-background flex items-center justify-center">
                                <Check className="w-2 h-2 text-white" strokeWidth={3} />
                              </div>
                            )}
                          </div>
                          <p className={`text-[10px] font-semibold leading-none ${isSelected ? 'text-primary' : 'text-muted-foreground'}`}>
                            {SHAPE_LABELS[shape]}
                          </p>
                        </button>
                      );
                    })}
                  </div>
                </div>
              ))}
            </div>

            {/* ── Apply button ── */}
            <div className="px-4 pt-2">
              <button
                onClick={handleSelect}
                disabled={saving || preview === currentStyle}
                className="w-full py-3.5 gradient-pink rounded-2xl text-white font-black text-sm press pink-glow-xs disabled:opacity-40 transition-all"
              >
                {saving ? (
                  <span className="flex items-center justify-center gap-2">
                    <div className="w-4 h-4 border-2 border-white border-t-transparent rounded-full animate-spin" />
                    Applying...
                  </span>
                ) : preview === currentStyle ? 'Badge Selected ✓' : 'Apply This Badge'}
              </button>
            </div>
          </>
        )}
      </div>
    </div>
  );
}
