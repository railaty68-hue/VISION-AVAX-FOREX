import { useState, useEffect } from 'react';
import { Download, RefreshCw, X, Smartphone, AlertCircle } from 'lucide-react';
import { supabase } from '@/lib/supabase';
import { AppVersion } from '@/types';
import { toast } from 'sonner';

interface Props {
  minimal?: boolean; // show just buttons without banner
}

export default function APKSection({ minimal = false }: Props) {
  const [version, setVersion] = useState<AppVersion | null>(null);
  const [dismissed, setDismissed] = useState(false);

  useEffect(() => {
    supabase
      .from('app_versions')
      .select('*')
      .eq('is_latest', true)
      .order('created_at', { ascending: false })
      .limit(1)
      .then(({ data }) => {
        if (data?.[0]) setVersion(data[0]);
      });

    // check if already dismissed this version
    const key = localStorage.getItem('vaf_dismissed_version');
    if (key) setDismissed(true);
  }, []);

  function handleDownload() {
    if (!version?.apk_url) {
      toast.info('APK not available yet. Contact admin on WhatsApp.');
      return;
    }
    window.open(version.apk_url, '_blank');
    toast.success('APK download started!');
  }

  function handleUpdate() {
    if (!version?.apk_url) {
      toast.info('No update available yet.');
      return;
    }
    window.open(version.apk_url, '_blank');
    toast.success('Downloading latest version...');
  }

  function dismiss() {
    if (version) localStorage.setItem('vaf_dismissed_version', version.id);
    setDismissed(true);
  }

  if (minimal) {
    return (
      <div className="space-y-2.5">
        <button
          onClick={handleDownload}
          className="w-full flex items-center gap-3 bg-card border border-border rounded-2xl p-4 hover:border-primary/30 transition-all press"
        >
          <div className="w-9 h-9 rounded-xl gradient-pink flex items-center justify-center flex-shrink-0 pink-glow-xs">
            <Download className="w-4 h-4 text-white" />
          </div>
          <div className="flex-1 text-left">
            <p className="font-bold text-foreground text-sm">Download APK</p>
            <p className="text-xs text-muted-foreground">
              {version ? `v${version.version_name}` : 'Install the mobile app'}
            </p>
          </div>
          <Smartphone className="w-4 h-4 text-muted-foreground" />
        </button>

        <button
          onClick={handleUpdate}
          className="w-full flex items-center gap-3 bg-card border border-border rounded-2xl p-4 hover:border-primary/30 transition-all press"
        >
          <div className="w-9 h-9 rounded-xl bg-primary/10 flex items-center justify-center flex-shrink-0">
            <RefreshCw className="w-4 h-4 text-primary" />
          </div>
          <div className="flex-1 text-left">
            <p className="font-bold text-foreground text-sm">Update New Vision</p>
            <p className="text-xs text-muted-foreground">
              {version ? `Latest: v${version.version_name}` : 'Check for updates'}
            </p>
          </div>
          {version && (
            <span className="text-[10px] px-2 py-0.5 gradient-pink rounded-full text-white font-bold">NEW</span>
          )}
        </button>
      </div>
    );
  }

  // Banner for home page
  if (!version || dismissed) return null;

  return (
    <div className="update-banner rounded-2xl p-4 animate-slide-down">
      <div className="flex items-start gap-3">
        <div className="w-9 h-9 rounded-xl gradient-pink flex items-center justify-center flex-shrink-0 pink-glow-xs flex-shrink-0">
          <Smartphone className="w-5 h-5 text-white" />
        </div>
        <div className="flex-1 min-w-0">
          <div className="flex items-center gap-2 mb-0.5">
            <AlertCircle className="w-3.5 h-3.5 text-primary" />
            <p className="text-xs font-black text-primary uppercase tracking-wide">App Available</p>
          </div>
          <p className="text-sm font-bold text-foreground">Vision Avax Forex v{version.version_name}</p>
          {version.release_notes && (
            <p className="text-xs text-muted-foreground mt-0.5 line-clamp-2">{version.release_notes}</p>
          )}
          <div className="flex gap-2 mt-3">
            <button
              onClick={handleDownload}
              className="flex-1 py-2 gradient-pink rounded-xl text-white text-xs font-bold flex items-center justify-center gap-1.5 pink-glow-xs press"
            >
              <Download className="w-3.5 h-3.5" /> Download APK
            </button>
            <button
              onClick={dismiss}
              className="px-3 py-2 bg-muted rounded-xl text-muted-foreground text-xs font-bold press"
            >
              Later
            </button>
          </div>
        </div>
        <button onClick={dismiss} className="p-1 rounded-lg hover:bg-muted transition-all flex-shrink-0">
          <X className="w-4 h-4 text-muted-foreground" />
        </button>
      </div>
    </div>
  );
}
