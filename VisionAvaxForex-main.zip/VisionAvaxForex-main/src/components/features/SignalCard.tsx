import { Lock, Pin, TrendingUp, TrendingDown, Crown, Eye, Image as ImageIcon } from 'lucide-react';
import { Signal } from '@/types';
import { useNavigate } from 'react-router-dom';
import VIPPlanSelector from './VIPPlanSelector';
import { useState } from 'react';

interface Props {
  signal: Signal;
  hasAccess: boolean;
  onViewSetup?: () => void;
  onViewResult?: () => void;
  forceShowClosed?: boolean; // show even VIP-locked if closed
}

export default function SignalCard({ signal, hasAccess, onViewSetup, onViewResult, forceShowClosed }: Props) {
  const navigate = useNavigate();
  const [showVIPSelector, setShowVIPSelector] = useState(false);
  const isBuy = signal.direction === 'BUY';
  const hasSetup = !!(signal as any).setup_image_url;
  const hasResult = !!(signal as any).result_image_url;

  // Closed VIP signals are visible to everyone (to entice non-VIP to join)
  const isVIPLocked = signal.is_vip && !hasAccess && !forceShowClosed && signal.status !== 'closed';

  const typeBadge = {
    forex: { bg: 'bg-blue-500/15', text: 'text-blue-400', border: 'border-blue-500/20', label: '💱 FOREX' },
    gold: { bg: 'bg-yellow-500/15', text: 'text-yellow-400', border: 'border-yellow-500/20', label: '🥇 GOLD' },
    crypto: { bg: 'bg-purple-500/15', text: 'text-purple-400', border: 'border-purple-500/20', label: '₿ CRYPTO' },
  }[signal.type] || { bg: 'bg-muted', text: 'text-foreground', border: 'border-border', label: signal.type?.toUpperCase() };

  const statusDot = {
    active: 'bg-green-400 animate-pulse',
    closed: 'bg-muted-foreground',
    pending: 'bg-yellow-400 animate-pulse',
  }[signal.status] || 'bg-muted-foreground';

  if (isVIPLocked) {
    return (
      <>
        {showVIPSelector && <VIPPlanSelector onClose={() => setShowVIPSelector(false)} />}
        <div className="relative bg-card border border-border rounded-2xl overflow-hidden">
          <div className="blur-[3px] pointer-events-none p-4">
            <div className="flex items-center justify-between mb-2.5">
              <span className={`text-xs px-2.5 py-1 rounded-full font-bold border ${typeBadge.bg} ${typeBadge.text} ${typeBadge.border}`}>{typeBadge.label}</span>
              <span className={`text-sm font-black px-3 py-1.5 rounded-xl ${isBuy ? 'buy-badge' : 'sell-badge'}`}>{signal.direction}</span>
            </div>
            <p className="font-black text-xl text-foreground mb-3">{signal.pair}</p>
            <div className="grid grid-cols-3 gap-2">
              <div className="bg-muted/50 rounded-xl p-2 text-center"><p className="text-[9px] text-muted-foreground">ENTRY</p><p className="text-xs font-bold text-foreground">{signal.entry}</p></div>
              <div className="bg-red-500/10 rounded-xl p-2 text-center"><p className="text-[9px] text-red-400">STOP LOSS</p><p className="text-xs font-bold text-red-400">{signal.stop_loss}</p></div>
              <div className="bg-green-500/10 rounded-xl p-2 text-center"><p className="text-[9px] text-green-400">TARGET</p><p className="text-xs font-bold text-green-400">{signal.take_profit}</p></div>
            </div>
          </div>
          <div className="absolute inset-0 vip-lock rounded-2xl flex flex-col items-center justify-center gap-2 p-4">
            <div className="w-10 h-10 rounded-2xl gradient-pink flex items-center justify-center pink-glow-xs mb-1">
              <Lock className="w-5 h-5 text-white" />
            </div>
            <p className="text-sm font-black text-white">VIP Signal</p>
            <p className="text-xs text-white/60 text-center">Upgrade to VIP to view this signal</p>
            <button onClick={() => setShowVIPSelector(true)} className="mt-1 px-5 py-2 gradient-pink rounded-xl text-white text-xs font-bold pink-glow-xs press">
              <Crown className="w-3.5 h-3.5 inline mr-1" /> Get VIP
            </button>
          </div>
        </div>
      </>
    );
  }

  return (
    <div className={`bg-card border rounded-2xl p-4 transition-all card-hover ${signal.is_pinned ? 'border-primary/40 pink-glow-xs' : 'border-border'}`}>
      {/* Top row */}
      <div className="flex items-center justify-between mb-3">
        <div className="flex items-center gap-2">
          <span className={`text-[11px] px-2.5 py-1 rounded-full font-bold border ${typeBadge.bg} ${typeBadge.text} ${typeBadge.border}`}>{typeBadge.label}</span>
          {signal.is_pinned && <Pin className="w-3.5 h-3.5 text-primary fill-primary" />}
          {signal.is_vip && <span className="text-[10px] px-2 py-0.5 bg-primary/15 text-primary rounded-full font-bold border border-primary/20">VIP</span>}
        </div>
        <div className="flex items-center gap-2">
          <div className="flex items-center gap-1">
            <span className={`w-1.5 h-1.5 rounded-full ${statusDot}`} />
            <span className="text-[10px] text-muted-foreground capitalize">{signal.status}</span>
          </div>
          <span className={`text-sm font-black px-3 py-1.5 rounded-xl flex items-center gap-1 ${isBuy ? 'buy-badge' : 'sell-badge'}`}>
            {isBuy ? <TrendingUp className="w-3.5 h-3.5" /> : <TrendingDown className="w-3.5 h-3.5" />}
            {signal.direction}
          </span>
        </div>
      </div>

      <p className="font-black text-2xl text-foreground mb-3 tracking-tight">{signal.pair}</p>

      <div className="grid grid-cols-3 gap-2 mb-3">
        <div className="bg-muted/40 border border-border/50 rounded-xl p-2.5 text-center">
          <p className="text-[9px] text-muted-foreground font-medium mb-0.5 uppercase tracking-wide">Entry</p>
          <p className="text-sm font-black text-foreground">{signal.entry}</p>
        </div>
        <div className="bg-red-500/8 border border-red-500/15 rounded-xl p-2.5 text-center">
          <p className="text-[9px] text-red-400 font-medium mb-0.5 uppercase tracking-wide">Stop Loss</p>
          <p className="text-sm font-black text-red-400">{signal.stop_loss}</p>
        </div>
        <div className="bg-green-500/8 border border-green-500/15 rounded-xl p-2.5 text-center">
          <p className="text-[9px] text-green-400 font-medium mb-0.5 uppercase tracking-wide">Target</p>
          <p className="text-sm font-black text-green-400">{signal.take_profit}</p>
        </div>
      </div>

      {/* Result/pips for closed signals */}
      {(signal as any).result && signal.status === 'closed' && (
        <div className="flex items-center gap-2 mb-2">
          <span className={`text-xs font-black px-2.5 py-1 rounded-full ${(signal as any).result === 'win' ? 'bg-green-500/15 text-green-400' : 'bg-red-500/15 text-red-400'}`}>
            {(signal as any).result === 'win' ? '✅ WIN' : '❌ LOSS'}
          </span>
          {(signal as any).pips && (
            <span className={`text-xs font-black px-2 py-0.5 rounded-full ${(signal as any).result === 'win' ? 'bg-green-500/10 text-green-400' : 'bg-red-500/10 text-red-400'}`}>
              {(signal as any).result === 'win' ? '+' : ''}{(signal as any).pips} pips
            </span>
          )}
        </div>
      )}

      {signal.notes && (
        <p className="text-xs text-muted-foreground leading-relaxed border-t border-border/40 pt-2.5 mb-2">{signal.notes}</p>
      )}

      {/* View Setup / View Result buttons — Setup first, then Result */}
      {(hasSetup || hasResult) && (
        <div className="flex gap-2 mt-2 pt-2 border-t border-border/30">
          {hasSetup && onViewSetup && (
            <button
              onClick={onViewSetup}
              className="flex items-center gap-1.5 px-3 py-1.5 bg-blue-500/10 border border-blue-500/25 rounded-xl text-blue-400 text-xs font-bold press hover:bg-blue-500/20 transition-all"
            >
              <ImageIcon className="w-3 h-3" /> View Setup
            </button>
          )}
          {hasResult && signal.status === 'closed' && onViewResult && (
            <button
              onClick={onViewResult}
              className="flex items-center gap-1.5 px-3 py-1.5 bg-green-500/10 border border-green-500/25 rounded-xl text-green-400 text-xs font-bold press hover:bg-green-500/20 transition-all"
            >
              <Eye className="w-3 h-3" /> View Result
            </button>
          )}
        </div>
      )}
    </div>
  );
}
