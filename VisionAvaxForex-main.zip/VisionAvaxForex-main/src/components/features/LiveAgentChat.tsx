import { useState, useEffect, useRef } from 'react';
import { X, Send, ExternalLink, Shield, Bot, Copy, Check } from 'lucide-react';
import { supabase } from '@/lib/supabase';
import { useAuth } from '@/contexts/AuthContext';

interface Message {
  id: string;
  role: 'user' | 'agent';
  content: string;
  time: string;
}

const FONT_SIZES: Record<string, string> = {
  xs2: '10px', xs: '11px', sm: '13px', md: '14px',
  lg: '16px', xl: '18px', '2xl': '20px', '3xl': '24px',
};
const FONT_MAP: Record<string, string> = {
  inter: '"Inter", sans-serif', roboto: '"Roboto", sans-serif',
  poppins: '"Poppins", sans-serif', nunito: '"Nunito", sans-serif',
  ubuntu: '"Ubuntu", sans-serif', oswald: '"Oswald", sans-serif',
  mono: '"Courier New", monospace', serif: '"Georgia", serif',
  playfair: '"Playfair Display", serif', cursive: 'cursive',
  italic: 'italic "Inter", sans-serif', fantasy: 'fantasy',
  thin: '100 "Inter", sans-serif', default: 'inherit',
};

// ── Copy-able Message Bubble ──
function MessageBubble({ msg, isEffectiveAdmin, showCustomAvatar, avatarUrl, bubbleOwn, bubbleOther, fontSize, fontFamily, renderContent }: {
  msg: { id: string; role: 'user' | 'agent'; content: string; time: string };
  isEffectiveAdmin: boolean;
  showCustomAvatar: boolean;
  avatarUrl: string;
  bubbleOwn: string;
  bubbleOther: string;
  fontSize: string;
  fontFamily: string;
  renderContent: (content: string) => React.ReactNode;
}) {
  const [copied, setCopied] = useState(false);

  async function handleCopy() {
    try {
      await navigator.clipboard.writeText(msg.content);
      setCopied(true);
      setTimeout(() => setCopied(false), 1800);
    } catch {
      // fallback
      const el = document.createElement('textarea');
      el.value = msg.content;
      document.body.appendChild(el);
      el.select();
      document.execCommand('copy');
      document.body.removeChild(el);
      setCopied(true);
      setTimeout(() => setCopied(false), 1800);
    }
  }

  return (
    <div className={`flex ${msg.role === 'user' ? 'justify-end' : 'justify-start'} gap-2 group`}>
      {msg.role === 'agent' && (
        <div className={`w-7 h-7 rounded-full overflow-hidden flex items-center justify-center flex-shrink-0 self-end mb-1 ${isEffectiveAdmin ? 'bg-primary/20' : 'gradient-pink'}`}>
          {showCustomAvatar
            ? <img src={avatarUrl} alt="" className="w-full h-full object-cover" />
            : isEffectiveAdmin
              ? <Shield className="w-3.5 h-3.5 text-primary" />
              : <Bot className="w-3.5 h-3.5 text-white" />
          }
        </div>
      )}
      <div style={{ maxWidth: '78%' }} className="relative">
        <div
          className="px-3 py-2 shadow-sm"
          style={{
            background: msg.role === 'user' ? bubbleOwn : bubbleOther,
            borderRadius: msg.role === 'user' ? '18px 18px 4px 18px' : '18px 18px 18px 4px',
            fontSize,
            fontFamily,
          }}
        >
          <p className="text-white leading-relaxed">{renderContent(msg.content)}</p>
        </div>
        <div className={`flex items-center gap-1 mt-0.5 ${msg.role === 'user' ? 'justify-end' : 'justify-start'}`}>
          <p className="text-[10px] text-white/40">{msg.time}</p>
          {/* Copy button — always visible on agent messages */}
          {msg.role === 'agent' && (
            <button
              onClick={handleCopy}
              className="flex items-center gap-0.5 px-1.5 py-0.5 rounded-lg bg-white/10 hover:bg-white/20 transition-all press ml-1"
              title="Copy message"
            >
              {copied
                ? <Check className="w-3 h-3 text-green-400" />
                : <Copy className="w-3 h-3 text-white/50" />
              }
              <span className="text-[9px] text-white/40">{copied ? 'Copied!' : 'Copy'}</span>
            </button>
          )}
        </div>
      </div>
    </div>
  );
}

// Pending password check state
type AdminAuthState = 'none' | 'awaiting_password' | 'verified';

interface Props {
  onClose: () => void;
  adminMode?: boolean;
}

export default function LiveAgentChat({ onClose, adminMode = false }: Props) {
  const { user, profile, isAdmin } = useAuth();
  const [messages, setMessages] = useState<Message[]>([]);
  const [input, setInput] = useState('');
  const [loading, setLoading] = useState(false);
  const [agentTyping, setAgentTyping] = useState(false);
  const [adminAuthState, setAdminAuthState] = useState<AdminAuthState>(
    adminMode && isAdmin ? 'verified' : 'none'
  );
  const [agentSettings, setAgentSettings] = useState({
    name: adminMode ? 'Admin AI Assistant' : 'AVAX Support',
    avatar_url: '',
    bg_url: '',
    bg_color: adminMode ? '#080b1a' : '#0d0d1a',
    bubble_own: '#FF1493',
    bubble_other: adminMode ? '#151b3a' : '#1e1e2e',
    font_size: 'md',
    font_family: 'default',
    whatsapp_number: '+255746715235',
  });
  const bottomRef = useRef<HTMLDivElement>(null);
  const inputRef = useRef<HTMLTextAreaElement>(null);
  const chatHistoryRef = useRef<{ role: string; content: string }[]>([]);

  useEffect(() => {
    if (!adminMode) {
      supabase.from('site_settings')
        .select('agent_name,agent_avatar_url,agent_bg_url,agent_bg_color,agent_bubble_own,agent_bubble_other,agent_font_size,agent_font_family,whatsapp_number')
        .eq('id', 'main').single()
        .then(({ data }) => {
          if (data) {
            setAgentSettings({
              name: (data as any).agent_name || 'AVAX Support',
              avatar_url: (data as any).agent_avatar_url || '',
              bg_url: (data as any).agent_bg_url || '',
              bg_color: (data as any).agent_bg_color || '#0d0d1a',
              bubble_own: (data as any).agent_bubble_own || '#FF1493',
              bubble_other: (data as any).agent_bubble_other || '#1e1e2e',
              font_size: (data as any).agent_font_size || 'md',
              font_family: (data as any).agent_font_family || 'default',
              whatsapp_number: (data as any).whatsapp_number || '+255746715235',
            });
          }
        });
    }

    const greeting: Message = adminMode
      ? {
          id: 'init',
          role: 'agent',
          content: isAdmin
            ? `Habari Admin! 👋 Mimi ni AI Assistant wako.\n\nNaweza kufanya mabadiliko ya moja kwa moja kwenye website yako:\n• 📞 Badilisha namba ya WhatsApp au malipo\n• 📢 Badilisha hero title/subtitle\n• 🤖 Badilisha jina la agent\n• 📋 Toa taarifa za platform\n• 💡 Mapendekezo ya kuboresha\n\nNiambie mabadiliko unayotaka kufanya!`
            : `Hello! Admin AI is for admins only.`,
          time: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
        }
      : {
          id: 'init',
          role: 'agent',
          content: `Karibu! 👋 Ninaweza kukusaidia na:\n• 📊 Bei za VIP na jinsi ya kujiunga\n• 💳 Jinsi ya kulipa\n• 📱 Kupakua App\n• 🎓 Kozi na masomo\n\nUna swali gani?`,
          time: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
        };
    setMessages([greeting]);
    chatHistoryRef.current = [{ role: 'assistant', content: greeting.content }];
  }, [adminMode, isAdmin]);

  useEffect(() => {
    bottomRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [messages, agentTyping]);

  async function sendMessage() {
    const text = input.trim();
    if (!text || loading) return;
    setInput('');

    const userMsg: Message = {
      id: Date.now().toString(),
      role: 'user',
      content: text,
      time: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
    };
    setMessages(prev => [...prev, userMsg]);
    chatHistoryRef.current.push({ role: 'user', content: text });

    // Handle admin password verification on client side
    if (!adminMode && adminAuthState === 'awaiting_password') {
      setLoading(true);
      // Verify password server-side
      const { data } = await supabase.functions.invoke('live-agent', {
        body: { passwordAttempt: text },
      });
      setLoading(false);

      if (data?.passwordCorrect) {
        setAdminAuthState('verified');
        const confirmMsg: Message = {
          id: Date.now().toString() + '_sys',
          role: 'agent',
          content: `✅ Utambulisho wa Admin umekubaliwa!\n\nSasa una mamlaka ya kubadilisha mipangilio ya website. Niambie mabadiliko unayotaka kufanya.`,
          time: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
        };
        setMessages(prev => [...prev, confirmMsg]);
        chatHistoryRef.current.push({ role: 'assistant', content: confirmMsg.content });
        return;
      } else {
        const wrongMsg: Message = {
          id: Date.now().toString() + '_sys',
          role: 'agent',
          content: `❌ Password si sahihi. Tafadhali jaribu tena au wasiliana nasi kwa usaidizi.`,
          time: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
        };
        setAdminAuthState('none');
        setMessages(prev => [...prev, wrongMsg]);
        chatHistoryRef.current.push({ role: 'assistant', content: wrongMsg.content });
        return;
      }
    }

    // Check if user is identifying as admin (trigger password prompt client-side)
    if (!adminMode && adminAuthState === 'none') {
      const lowerText = text.toLowerCase();
      if (lowerText.includes('mimi ni admin') || lowerText.includes('i am admin') || lowerText.includes('admin mimi') || lowerText.includes('niko admin')) {
        setAdminAuthState('awaiting_password');
        const askPasswordMsg: Message = {
          id: Date.now().toString() + '_ask',
          role: 'agent',
          content: `🔐 Ninahitaji kuthibitisha utambulisho wako.\n\nTafadhali tuma password ya admin kuendelea.`,
          time: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
        };
        setMessages(prev => [...prev, askPasswordMsg]);
        chatHistoryRef.current.push({ role: 'assistant', content: askPasswordMsg.content });
        return;
      }
    }

    setLoading(true);
    setAgentTyping(true);

    const isEffectiveAdmin = adminMode || adminAuthState === 'verified';

    const { data, error } = await supabase.functions.invoke('live-agent', {
      body: {
        messages: chatHistoryRef.current.slice(-20),
        stream: false,
        isAdmin: isEffectiveAdmin,
        adminVerified: isEffectiveAdmin && (adminMode ? isAdmin : true),
      },
    });

    setAgentTyping(false);
    setLoading(false);

    if (error || !data?.text) {
      const errMsg: Message = {
        id: Date.now().toString() + '_err',
        role: 'agent',
        content: 'Kuna tatizo la muunganisho. Tafadhali jaribu tena.',
        time: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
      };
      setMessages(prev => [...prev, errMsg]);
      return;
    }

    // If DB changes were made, add a confirmation indicator
    const responseText = data.dbChanged
      ? data.text + '\n\n✅ *Mabadiliko yamehifadhiwa kwenye database.*'
      : data.text;

    const agentMsg: Message = {
      id: Date.now().toString() + '_agent',
      role: 'agent',
      content: responseText,
      time: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
    };
    setMessages(prev => [...prev, agentMsg]);
    chatHistoryRef.current.push({ role: 'assistant', content: data.text });
  }

  function handleKey(e: React.KeyboardEvent) {
    if (e.key === 'Enter' && !e.shiftKey) { e.preventDefault(); sendMessage(); }
  }

  const fontSize = FONT_SIZES[agentSettings.font_size] || '14px';
  const fontFamily = FONT_MAP[agentSettings.font_family] || 'inherit';
  const bgStyle = agentSettings.bg_url
    ? { backgroundImage: `url(${agentSettings.bg_url})`, backgroundSize: 'cover', backgroundPosition: 'center' }
    : { background: agentSettings.bg_color };

  function renderMessageContent(content: string) {
    const parts = content.split(/(https?:\/\/[^\s\n]+)/g);
    return parts.map((part, i) => {
      if (part.match(/^https?:\/\//)) {
        return (
          <a key={i} href={part} target="_blank" rel="noopener noreferrer"
            className="underline text-blue-300 inline-flex items-center gap-0.5 break-all" style={{ fontSize }}>
            {part.length > 45 ? part.substring(0, 45) + '...' : part}
            <ExternalLink className="w-3 h-3 inline flex-shrink-0 ml-0.5" />
          </a>
        );
      }
      return <span key={i} style={{ whiteSpace: 'pre-wrap' }}>{part}</span>;
    });
  }

  const isEffectiveAdmin = adminMode || adminAuthState === 'verified';
  const agentDisplayName = adminMode ? 'Admin AI Assistant' : agentSettings.name;

  // Avatar: use agent's custom avatar, or icon
  const showCustomAvatar = !adminMode && agentSettings.avatar_url;

  return (
    <div className="fixed inset-0 z-[600] flex flex-col animate-fade-in" style={{ ...bgStyle, fontFamily }}>
      {/* Header */}
      <div
        className="flex-shrink-0 flex items-center gap-3 px-4 py-3 border-b border-white/10"
        style={{ background: 'rgba(0,0,0,0.65)', backdropFilter: 'blur(16px)', paddingTop: 'max(12px, env(safe-area-inset-top))' }}
      >
        <div className={`w-10 h-10 rounded-full overflow-hidden flex items-center justify-center flex-shrink-0 ring-2 ring-primary/50 ${isEffectiveAdmin ? 'bg-primary/20' : 'gradient-pink'}`}>
          {showCustomAvatar
            ? <img src={agentSettings.avatar_url} alt={agentDisplayName} className="w-full h-full object-cover" />
            : isEffectiveAdmin
              ? <Shield className="w-5 h-5 text-primary" />
              : <Bot className="w-5 h-5 text-white" />
          }
        </div>
        <div className="flex-1">
          <div className="flex items-center gap-2">
            <p className="font-black text-white text-sm">{agentDisplayName}</p>
            {isEffectiveAdmin && (
              <span className="text-[9px] px-1.5 py-0.5 bg-primary/30 text-primary rounded font-bold">ADMIN</span>
            )}
          </div>
          <div className="flex items-center gap-1.5">
            <span className="w-1.5 h-1.5 rounded-full bg-green-400 animate-pulse" />
            <span className="text-[10px] text-green-400 font-medium">
              {isEffectiveAdmin ? 'Admin Mode · Full Access' : 'Online · AI Support'}
            </span>
          </div>
        </div>
        {!adminMode && (
          <a
            href={`https://wa.me/${agentSettings.whatsapp_number.replace('+', '')}`}
            target="_blank" rel="noopener noreferrer"
            className="w-9 h-9 rounded-full flex items-center justify-center press flex-shrink-0"
            style={{ background: '#25D366' }}
          >
            <svg viewBox="0 0 24 24" fill="white" className="w-5 h-5">
              <path d="M17.472 14.382c-.297-.149-1.758-.867-2.03-.967-.273-.099-.471-.148-.67.15-.197.297-.767.966-.94 1.164-.173.199-.347.223-.644.075-.297-.15-1.255-.463-2.39-1.475-.883-.788-1.48-1.761-1.653-2.059-.173-.297-.018-.458.13-.606.134-.133.298-.347.446-.52.149-.174.198-.298.298-.497.099-.198.05-.371-.025-.52-.075-.149-.669-1.612-.916-2.207-.242-.579-.487-.5-.669-.51-.173-.008-.371-.01-.57-.01-.198 0-.52.074-.792.372-.272.297-1.04 1.016-1.04 2.479 0 1.462 1.065 2.875 1.213 3.074.149.198 2.096 3.2 5.077 4.487.709.306 1.262.489 1.694.625.712.227 1.36.195 1.871.118.571-.085 1.758-.719 2.006-1.413.248-.694.248-1.289.173-1.413-.074-.124-.272-.198-.57-.347z"/>
              <path d="M12 0C5.373 0 0 5.373 0 12c0 2.123.558 4.112 1.534 5.836L.057 23.786l6.063-1.59A11.945 11.945 0 0012 24c6.627 0 12-5.373 12-12S18.627 0 12 0zm0 22c-1.851 0-3.594-.473-5.115-1.306l-.366-.217-3.598.945.962-3.513-.24-.372A9.944 9.944 0 012 12C2 6.477 6.477 2 12 2s10 4.477 10 10-4.477 10-10 10z"/>
            </svg>
          </a>
        )}
        <button onClick={onClose} className="w-9 h-9 rounded-full bg-white/10 flex items-center justify-center press flex-shrink-0">
          <X className="w-5 h-5 text-white" />
        </button>
      </div>

      {/* Messages */}
      <div className="flex-1 overflow-y-auto px-4 py-3 space-y-2">
        {messages.map(msg => (
          <MessageBubble
            key={msg.id}
            msg={msg}
            isEffectiveAdmin={isEffectiveAdmin}
            showCustomAvatar={!!showCustomAvatar}
            avatarUrl={agentSettings.avatar_url}
            bubbleOwn={agentSettings.bubble_own}
            bubbleOther={agentSettings.bubble_other}
            fontSize={fontSize}
            fontFamily={fontFamily}
            renderContent={renderMessageContent}
          />
        ))}

        {agentTyping && (
          <div className="flex justify-start gap-2">
            <div className={`w-7 h-7 rounded-full flex items-center justify-center flex-shrink-0 self-end mb-1 ${isEffectiveAdmin ? 'bg-primary/20' : 'gradient-pink'}`}>
              {isEffectiveAdmin ? <Shield className="w-3.5 h-3.5 text-primary" /> : <Bot className="w-3.5 h-3.5 text-white" />}
            </div>
            <div className="px-4 py-3 rounded-2xl" style={{ background: agentSettings.bubble_other, borderRadius: '18px 18px 18px 4px' }}>
              <div className="flex gap-1 items-center">
                <div className="w-2 h-2 rounded-full bg-white/60 animate-bounce" style={{ animationDelay: '0ms' }} />
                <div className="w-2 h-2 rounded-full bg-white/60 animate-bounce" style={{ animationDelay: '150ms' }} />
                <div className="w-2 h-2 rounded-full bg-white/60 animate-bounce" style={{ animationDelay: '300ms' }} />
              </div>
            </div>
          </div>
        )}
        <div ref={bottomRef} />
      </div>

      {/* Input */}
      <div
        className="flex-shrink-0 px-3 py-3 border-t border-white/10 flex gap-2 items-end"
        style={{ background: 'rgba(0,0,0,0.65)', backdropFilter: 'blur(16px)', paddingBottom: 'max(12px, env(safe-area-inset-bottom))' }}
      >
        <textarea
          ref={inputRef}
          value={input}
          onChange={e => setInput(e.target.value)}
          onKeyDown={handleKey}
          placeholder={
            adminAuthState === 'awaiting_password'
              ? 'Ingiza password ya admin...'
              : isEffectiveAdmin
                ? 'Ambia AI mabadiliko unayotaka...'
                : 'Andika ujumbe wako...'
          }
          rows={1}
          className="flex-1 bg-white/10 border border-white/20 rounded-2xl px-4 py-2.5 text-white placeholder-white/40 outline-none focus:border-primary/50 resize-none text-sm"
          style={{ maxHeight: 120, fontFamily, fontSize }}
        />
        <button
          onClick={sendMessage}
          disabled={!input.trim() || loading}
          className="w-11 h-11 rounded-full gradient-pink flex items-center justify-center flex-shrink-0 press disabled:opacity-40 pink-glow-xs"
        >
          {loading
            ? <div className="w-4 h-4 border-2 border-white border-t-transparent rounded-full animate-spin" />
            : <Send className="w-4 h-4 text-white" />
          }
        </button>
      </div>
    </div>
  );
}
