import type { BadgeStyle } from '@/types';

interface VIPBadgeProps {
  size?: 'xs' | 'sm' | 'md' | 'lg';
  badgeStyle?: BadgeStyle;
  animate?: boolean;
  onClick?: () => void;
}

// ── Color palettes ─────────────────────────────────────────────
const COLORS: Record<string, { from: string; to: string; glow: string }> = {
  blue:  { from: '#4DAEFF', to: '#0A5FD1', glow: '0 2px 8px rgba(24,119,242,0.55)' },
  black: { from: '#5a5a5a', to: '#1a1a1a', glow: '0 2px 8px rgba(0,0,0,0.5)' },
  red:   { from: '#FF5252', to: '#C00000', glow: '0 2px 8px rgba(192,0,0,0.55)' },
  gold:  { from: '#FFE044', to: '#C47600', glow: '0 2px 8px rgba(196,118,0,0.55)' },
  green: { from: '#4ADE80', to: '#15803D', glow: '0 2px 8px rgba(21,128,61,0.55)' },
  gray:  { from: '#9CA3AF', to: '#4B5563', glow: '0 2px 8px rgba(75,85,99,0.4)' },
};

function getColor(style: BadgeStyle) {
  if (style.startsWith('blue'))  return COLORS.blue;
  if (style.startsWith('black')) return COLORS.black;
  if (style.startsWith('red'))   return COLORS.red;
  if (style.startsWith('green')) return COLORS.green;
  if (style.startsWith('gray'))  return COLORS.gray;
  return COLORS.gold;
}

// ── Shield path (Facebook-style) ──────────────────────────────
function ShieldPath({ gradId }: { gradId: string }) {
  return (
    <path
      d="M12 2.25L4.5 5.5V11c0 4.97 3.2 9.6 7.5 11 4.3-1.4 7.5-6.03 7.5-11V5.5L12 2.25Z"
      fill={`url(#${gradId})`}
    />
  );
}

// ── Smooth 12-point star seal (Instagram-style) ───────────────
function StarPath({ gradId }: { gradId: string }) {
  const pts: string[] = [];
  const cx = 12, cy = 12, r1 = 10.5, r2 = 7.5, n = 12;
  for (let i = 0; i < n * 2; i++) {
    const angle = (Math.PI / n) * i - Math.PI / 2;
    const r = i % 2 === 0 ? r1 : r2;
    pts.push(`${(cx + Math.cos(angle) * r).toFixed(2)},${(cy + Math.sin(angle) * r).toFixed(2)}`);
  }
  return <polygon points={pts.join(' ')} fill={`url(#${gradId})`} />;
}

// ── Bold 16-point starburst ───────────────────────────────────
function BurstPath({ gradId }: { gradId: string }) {
  const pts: string[] = [];
  const cx = 12, cy = 12, r1 = 10.5, r2 = 7, n = 16;
  for (let i = 0; i < n * 2; i++) {
    const angle = (Math.PI / n) * i - Math.PI / 2;
    const r = i % 2 === 0 ? r1 : r2;
    pts.push(`${(cx + Math.cos(angle) * r).toFixed(2)},${(cy + Math.sin(angle) * r).toFixed(2)}`);
  }
  return <polygon points={pts.join(' ')} fill={`url(#${gradId})`} />;
}

// ── Filled circle (Twitter/X-style) ──────────────────────────
function CirclePath({ gradId }: { gradId: string }) {
  return <circle cx="12" cy="12" r="10.5" fill={`url(#${gradId})`} />;
}

// ── Wavy cloud/flower (8-petal) ───────────────────────────────
function WavyPath({ gradId }: { gradId: string }) {
  // 8-lobed cloud shape
  const pts: string[] = [];
  const cx = 12, cy = 12, r1 = 10.5, r2 = 8.5, n = 8;
  for (let i = 0; i < n * 2; i++) {
    const angle = (Math.PI / n) * i - Math.PI / 2;
    const r = i % 2 === 0 ? r1 : r2;
    pts.push(`${(cx + Math.cos(angle) * r).toFixed(2)},${(cy + Math.sin(angle) * r).toFixed(2)}`);
  }
  return <polygon points={pts.join(' ')} fill={`url(#${gradId})`} />;
}

// ── Main badge component ───────────────────────────────────────
export default function VIPBadge({
  size = 'sm',
  badgeStyle = 'blue_shield',
  animate = false,
  onClick,
}: VIPBadgeProps) {
  const dim = { xs: 14, sm: 17, md: 22, lg: 30 }[size];
  const uid = `${badgeStyle}-${dim}`;
  const color = getColor(badgeStyle);
  // shape is the part after the first underscore
  const shape = badgeStyle.replace(/^[^_]+_/, '') as 'shield' | 'star' | 'burst' | 'circle' | 'wavy';

  return (
    <svg
      width={dim}
      height={dim}
      viewBox="0 0 24 24"
      fill="none"
      xmlns="http://www.w3.org/2000/svg"
      title="Verified"
      aria-label="Verified"
      onClick={onClick}
      style={{
        flexShrink: 0,
        display: 'inline-block',
        verticalAlign: 'middle',
        cursor: onClick ? 'pointer' : 'default',
        filter: `drop-shadow(${color.glow})`,
        animation: animate ? 'badgePop 0.4s cubic-bezier(0.34,1.56,0.64,1)' : undefined,
        transition: 'filter 0.2s ease',
      }}
    >
      <defs>
        <linearGradient id={`grad-${uid}`} x1="12" y1="1" x2="12" y2="23" gradientUnits="userSpaceOnUse">
          <stop offset="0%" stopColor={color.from} />
          <stop offset="100%" stopColor={color.to} />
        </linearGradient>
        <linearGradient id={`shine-${uid}`} x1="6" y1="2" x2="16" y2="10" gradientUnits="userSpaceOnUse">
          <stop offset="0%" stopColor="white" stopOpacity="0.30" />
          <stop offset="100%" stopColor="white" stopOpacity="0" />
        </linearGradient>
      </defs>

      {/* Badge shape */}
      {shape === 'shield' && <ShieldPath gradId={`grad-${uid}`} />}
      {shape === 'star'   && <StarPath   gradId={`grad-${uid}`} />}
      {shape === 'burst'  && <BurstPath  gradId={`grad-${uid}`} />}
      {shape === 'circle' && <CirclePath gradId={`grad-${uid}`} />}
      {shape === 'wavy'   && <WavyPath   gradId={`grad-${uid}`} />}

      {/* Shine overlay for shield */}
      {shape === 'shield' && (
        <path
          d="M12 3.5L5.5 6.5V11c0 4.3 2.7 8.3 6.5 9.5 3.8-1.2 6.5-5.2 6.5-9.5V6.5L12 3.5Z"
          fill={`url(#shine-${uid})`}
        />
      )}
      {/* Shine overlay for circle */}
      {shape === 'circle' && (
        <circle cx="12" cy="12" r="10.5" fill={`url(#shine-${uid})`} />
      )}

      {/* White checkmark */}
      <path
        d="M8.5 12L11 14.5L15.5 9.5"
        stroke="white"
        strokeWidth={shape === 'burst' || shape === 'wavy' ? 2.2 : 2}
        strokeLinecap="round"
        strokeLinejoin="round"
        fill="none"
      />
    </svg>
  );
}
