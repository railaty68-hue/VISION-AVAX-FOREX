import { useState, useEffect, useRef } from 'react';
import { playNotificationSound } from '@/lib/notificationSound';
import { Bell, X, CheckCheck, TrendingUp, Crown, Info, Megaphone, Trash2, BookOpen, MessageCircle } from 'lucide-react';
import { supabase } from '@/lib/supabase';
import { useAuth } from '@/contexts/AuthContext';
import { Notification } from '@/types';

// Persist deleted notification IDs in localStorage so they don't come back
const LS_DELETED_NOTIFS = 'vaf_deleted_notif_ids';

function getDeletedIds(): Set<string> {
  try {
    const raw = localStorage.getItem(LS_DELETED_NOTIFS);
    if (raw) return new Set(JSON.parse(raw));
  } catch {}
  return new Set();
}
function saveDeletedIds(ids: Set<string>) {
  try {
    // Keep only last 500 to avoid bloat
    const arr = Array.from(ids).slice(-500);
    localStorage.setItem(LS_DELETED_NOTIFS, JSON.stringify(arr));
  } catch {}
}

const typeIcons: Record<string, React.ElementType> = {
  signal: TrendingUp, vip: Crown, announcement: Megaphone,
  update: Info, general: Bell, course: BookOpen,
  message: MessageCircle, referral_reward: Crown,
};

const typeColors: Record<string, string> = {
  signal: 'text-green-400 bg-green-500/15', vip: 'text-primary bg-primary/15',
  announcement: 'text-yellow-400 bg-yellow-500/15', update: 'text-orange-400 bg-orange-500/15',
  general: 'text-blue-400 bg-blue-500/15', course: 'text-purple-400 bg-purple-500/15',
  message: 'text-cyan-400 bg-cyan-500/15', referral_reward: 'text-yellow-400 bg-yellow-500/15',
};

interface Props {
  onClose: () => void;
}

export default function NotificationCenter({ onClose }: Props) {
  const { user } = useAuth();
  const [notifications, setNotifications] = useState<Notification[]>([]);
  const [loading, setLoading] = useState(true);
  const deletedIdsRef = useRef<Set<string>>(getDeletedIds());

  useEffect(() => {
    if (!user) return;
    fetchNotifications();
    const interval = setInterval(fetchNotifications, 15000);
    return () => clearInterval(interval);
  }, [user]);

  async function fetchNotifications() {
    if (!user) return;
    const { data } = await supabase
      .from('notifications')
      .select('*')
      .or(`target_user_id.eq.${user.id},target_user_id.is.null`)
      .order('created_at', { ascending: false })
      .limit(80);
    if (data) {
      // Filter out locally deleted ones
      const filtered = (data as Notification[]).filter(n => !deletedIdsRef.current.has(n.id));
      setNotifications(filtered);
    }
    setLoading(false);
  }

  async function markAllRead() {
    if (!user) return;
    await supabase
      .from('notifications')
      .update({ is_read: true })
      .eq('target_user_id', user.id)
      .eq('is_read', false);
    setNotifications(prev => prev.map(n => ({ ...n, is_read: true })));
  }

  async function deleteNotification(id: string, e: React.MouseEvent) {
    e.stopPropagation();
    // Add to local deleted set immediately
    deletedIdsRef.current.add(id);
    saveDeletedIds(deletedIdsRef.current);
    // Remove from UI immediately
    setNotifications(prev => prev.filter(n => n.id !== id));
    // Delete from DB
    await supabase.from('notifications').delete().eq('id', id);
  }

  async function deleteAllRead() {
    if (!user) return;
    const readItems = notifications.filter(n => n.is_read);
    const readIds = readItems.map(n => n.id);
    if (readIds.length === 0) return;
    // Add all to deleted set
    readIds.forEach(id => deletedIdsRef.current.add(id));
    saveDeletedIds(deletedIdsRef.current);
    setNotifications(prev => prev.filter(n => !n.is_read));
    await supabase.from('notifications').delete().in('id', readIds);
  }

  async function markRead(n: Notification) {
    if (n.is_read) return;
    await supabase.from('notifications').update({ is_read: true }).eq('id', n.id);
    setNotifications(prev => prev.map(item => item.id === n.id ? { ...item, is_read: true } : item));
  }

  const unreadCount = notifications.filter(n => !n.is_read).length;

  return (
    <div
      className="fixed inset-0 z-[150] flex flex-col animate-fade-in"
      style={{ background: 'hsl(var(--background))', paddingTop: 'env(safe-area-inset-top)' }}
    >
      {/* Header */}
      <div className="flex items-center justify-between px-4 py-4 border-b border-border flex-shrink-0 bg-background">
        <div className="flex items-center gap-2">
          <Bell className="w-5 h-5 text-primary" />
          <h2 className="font-black text-foreground text-lg">Notifications</h2>
          {unreadCount > 0 && (
            <span className="min-w-[22px] h-5 px-1 gradient-pink rounded-full flex items-center justify-center text-[10px] text-white font-black">
              {unreadCount > 99 ? '99+' : unreadCount}
            </span>
          )}
        </div>
        <div className="flex items-center gap-2">
          {unreadCount > 0 && (
            <button
              onClick={markAllRead}
              className="flex items-center gap-1 px-2.5 py-1.5 bg-muted rounded-xl text-xs text-muted-foreground hover:text-foreground transition-all press"
            >
              <CheckCheck className="w-3.5 h-3.5" /> Mark all read
            </button>
          )}
          {notifications.some(n => n.is_read) && (
            <button
              onClick={deleteAllRead}
              className="flex items-center gap-1 px-2.5 py-1.5 bg-red-500/10 rounded-xl text-xs text-red-400 hover:bg-red-500/20 transition-all press"
            >
              <Trash2 className="w-3.5 h-3.5" /> Clear read
            </button>
          )}
          <button onClick={onClose} className="p-2 rounded-xl bg-muted hover:bg-muted/80 press">
            <X className="w-5 h-5 text-foreground" />
          </button>
        </div>
      </div>

      {/* Notification list */}
      <div
        className="flex-1 overflow-y-auto px-3 py-3 space-y-2"
        style={{ paddingBottom: 'max(80px, env(safe-area-inset-bottom))' }}
      >
        {loading ? (
          Array.from({ length: 5 }).map((_, i) => (
            <div key={i} className="h-16 bg-muted/30 rounded-2xl animate-pulse" />
          ))
        ) : notifications.length === 0 ? (
          <div className="flex flex-col items-center justify-center py-20 text-center">
            <div className="w-16 h-16 rounded-3xl bg-muted/50 flex items-center justify-center mb-4">
              <Bell className="w-8 h-8 text-muted-foreground opacity-40" />
            </div>
            <p className="text-foreground font-bold mb-1">No notifications yet</p>
            <p className="text-xs text-muted-foreground">You'll receive signals, VIP updates, and announcements here</p>
          </div>
        ) : (
          notifications.map(n => {
            const Icon = typeIcons[n.type] || Bell;
            const colorClass = typeColors[n.type] || 'text-blue-400 bg-blue-500/15';
            return (
              <div
                key={n.id}
                onClick={() => markRead(n)}
                className={`flex items-start gap-3 p-3 rounded-2xl border transition-all cursor-pointer ${
                  n.is_read
                    ? 'bg-card border-border/50 opacity-80'
                    : 'bg-primary/5 border-primary/25 shadow-sm'
                }`}
              >
                <div className={`w-9 h-9 rounded-xl ${colorClass} flex items-center justify-center flex-shrink-0`}>
                  <Icon className="w-4 h-4" />
                </div>
                <div className="flex-1 min-w-0">
                  <p className="text-sm font-bold leading-tight mb-0.5 text-foreground">{n.title}</p>
                  <p className="text-xs text-muted-foreground leading-relaxed">{n.body}</p>
                  <p className="text-[10px] text-muted-foreground mt-1.5">
                    {new Date(n.created_at).toLocaleString()}
                  </p>
                </div>
                <div className="flex flex-col items-center gap-2 flex-shrink-0">
                  {!n.is_read && (
                    <span className="w-2.5 h-2.5 rounded-full bg-primary flex-shrink-0" />
                  )}
                  <button
                    onClick={e => deleteNotification(n.id, e)}
                    className="w-7 h-7 rounded-lg bg-muted/60 hover:bg-red-500/20 flex items-center justify-center transition-all press"
                  >
                    <X className="w-3.5 h-3.5 text-muted-foreground" />
                  </button>
                </div>
              </div>
            );
          })
        )}
      </div>
    </div>
  );
}
