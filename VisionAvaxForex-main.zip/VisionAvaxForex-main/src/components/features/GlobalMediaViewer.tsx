import { useState, useEffect, useRef } from 'react';
import { X, ChevronLeft, ChevronRight, Download, ZoomIn, ZoomOut } from 'lucide-react';

interface MediaItem {
  url: string;
  type: 'image' | 'video';
}

interface Props {
  items: MediaItem[];
  initialIndex?: number;
  onClose: () => void;
}

export default function GlobalMediaViewer({ items, initialIndex = 0, onClose }: Props) {
  const [current, setCurrent] = useState(initialIndex);
  const [scale, setScale] = useState(1);
  const touchStart = useRef<number>(0);

  useEffect(() => {
    const handler = (e: KeyboardEvent) => {
      if (e.key === 'Escape') onClose();
      if (e.key === 'ArrowLeft') go(-1);
      if (e.key === 'ArrowRight') go(1);
    };
    window.addEventListener('keydown', handler);
    return () => window.removeEventListener('keydown', handler);
  }, [current]);

  function go(dir: number) {
    setScale(1);
    setCurrent(c => Math.max(0, Math.min(items.length - 1, c + dir)));
  }

  function onTouchStart(e: React.TouchEvent) {
    touchStart.current = e.touches[0].clientX;
  }
  function onTouchEnd(e: React.TouchEvent) {
    const delta = e.changedTouches[0].clientX - touchStart.current;
    if (Math.abs(delta) > 60) go(delta < 0 ? 1 : -1);
  }

  const item = items[current];
  if (!item) return null;

  return (
    <div
      className="fixed inset-0 z-[9000] bg-black flex flex-col"
      style={{ paddingTop: 'env(safe-area-inset-top)', paddingBottom: 'env(safe-area-inset-bottom)' }}
    >
      {/* Header */}
      <div className="flex items-center justify-between px-4 py-3 flex-shrink-0 bg-black/60">
        <button onClick={onClose} className="w-9 h-9 rounded-full bg-white/10 flex items-center justify-center press">
          <X className="w-5 h-5 text-white" />
        </button>
        <span className="text-white text-sm font-bold">{current + 1} / {items.length}</span>
        <a href={item.url} download target="_blank" rel="noreferrer" className="w-9 h-9 rounded-full bg-white/10 flex items-center justify-center press">
          <Download className="w-4 h-4 text-white" />
        </a>
      </div>

      {/* Media */}
      <div
        className="flex-1 flex items-center justify-center relative overflow-hidden"
        onTouchStart={onTouchStart}
        onTouchEnd={onTouchEnd}
      >
        {item.type === 'video' ? (
          <video
            key={item.url}
            src={item.url}
            controls
            autoPlay
            className="max-w-full max-h-full"
            style={{ maxHeight: 'calc(100vh - 120px)' }}
          />
        ) : (
          <img
            key={item.url}
            src={item.url}
            alt=""
            className="max-w-full max-h-full object-contain transition-transform duration-200"
            style={{ transform: `scale(${scale})`, maxHeight: 'calc(100vh - 120px)', cursor: scale > 1 ? 'zoom-out' : 'zoom-in' }}
            onClick={() => setScale(s => s === 1 ? 2 : 1)}
          />
        )}

        {/* Navigation arrows */}
        {current > 0 && (
          <button onClick={() => go(-1)} className="absolute left-2 top-1/2 -translate-y-1/2 w-10 h-10 rounded-full bg-black/50 flex items-center justify-center press">
            <ChevronLeft className="w-6 h-6 text-white" />
          </button>
        )}
        {current < items.length - 1 && (
          <button onClick={() => go(1)} className="absolute right-2 top-1/2 -translate-y-1/2 w-10 h-10 rounded-full bg-black/50 flex items-center justify-center press">
            <ChevronRight className="w-6 h-6 text-white" />
          </button>
        )}
      </div>

      {/* Thumbnail strip */}
      {items.length > 1 && (
        <div className="flex-shrink-0 flex gap-1.5 overflow-x-auto px-4 py-2 bg-black/60 justify-center">
          {items.map((it, i) => (
            <button
              key={i}
              onClick={() => { setScale(1); setCurrent(i); }}
              className={`flex-shrink-0 w-10 h-10 rounded-lg overflow-hidden border-2 transition-all press ${i === current ? 'border-white' : 'border-transparent opacity-50'}`}
            >
              {it.type === 'video'
                ? <video src={it.url} className="w-full h-full object-cover" muted />
                : <img src={it.url} alt="" className="w-full h-full object-cover" />
              }
            </button>
          ))}
        </div>
      )}
    </div>
  );
}
