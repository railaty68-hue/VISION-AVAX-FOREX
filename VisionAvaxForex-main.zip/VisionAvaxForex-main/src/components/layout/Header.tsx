import { Link, useNavigate, useLocation } from 'react-router-dom';
import { Shield, Bell, MessageCircle } from 'lucide-react';
import { useAuth } from '@/contexts/AuthContext';
import VIPBadge from '@/components/features/VIPBadge';
import NotificationCenter from '@/components/features/NotificationCenter';
import VIPPlanSelector from '@/components/features/VIPPlanSelector';
import { isVIPActive, supabase } from '@/lib/supabase';
import { useState, useEffect, useRef } from 'react';
import { playNotificationSound } from '@/lib/notificationSound';

// ── Persist read DM conversations so badge doesn't bounce back ──
const LS_DM_READ_KEY = 'vaf_dm_read_conv_map'; // convId → lastReadAt timestamp
function getDMReadMap(): Record<string, number> {
  try { return JSON.parse(localStorage.getItem(LS_DM_READ_KEY) || '{}'); } catch { return {}; }
}
function setDMReadMap(map: Record<string, number>) {
  try { localStorage.setItem(LS_DM_READ_KEY, JSON.stringify(map)); } catch {}
}
export function markConversationRead(convId: string) {
  const map = getDMReadMap();
  map[convId] = Date.now();
  setDMReadMap(map);
}

export default function Header() {
  const { user, profile, isAdmin, theme } = useAuth();
  const navigate = useNavigate();
  const location = useLocation();
  const [unreadCount, setUnreadCount] = useState(0);
  const [unreadDMs, setUnreadDMs] = useState(0);
  const [showNotifications, setShowNotifications] = useState(false);
  const [showVIPSelector, setShowVIPSelector] = useState(false);
  const [showHeader, setShowHeader] = useState(true);
  const [headerConfig, setHeaderConfig] = useState<any>({
    logoFontSize: '13',
    logoFontStyle: 'gradient',
    logoPosition: 'center',
    showMessengerIcon: true,
    showBellIcon: true,
    memberNameSize: 'sm',
    badgeSpacing: 'normal',
  });
  const prevCount = useRef(0);
  const prevDMs = useRef(0);
  // Track which conversations the user has opened this session
  const openedConvsRef = useRef<Set<string>>(new Set());

  useEffect(() => {
    supabase.from('site_settings').select('show_header,header_config').eq('id', 'main').single()
      .then(({ data }) => {
        if (data) {
          setShowHeader((data as any).show_header !== false);
          if ((data as any).header_config) {
            setHeaderConfig((prev: any) => ({ ...prev, ...(data as any).header_config }));
          }
        }
      });
  }, []);

  // Bell badge + sound
  useEffect(() => {
    if (!user) return;
    const check = async () => {
      const { count } = await supabase
        .from('notifications')
        .select('id', { count: 'exact', head: true })
        .eq('is_read', false)
        .or(`target_user_id.eq.${user.id},target_user_id.is.null`);
      const n = count || 0;
      if (n > prevCount.current && prevCount.current >= 0) playNotificationSound();
      prevCount.current = n;
      setUnreadCount(n);
    };
    check();
    const interval = setInterval(check, 30000);
    return () => clearInterval(interval);
  }, [user]);

  // DM badge — only count convs the user hasn't opened since last message
  useEffect(() => {
    if (!user) return;
    const checkDMs = async () => {
      // If user is currently on the messenger page, badge stays 0
      if (location.pathname === '/messenger') {
        setUnreadDMs(0);
        prevDMs.current = 0;
        return;
      }
      const { data: convs } = await supabase
        .from('conversations').select('id,last_message_at')
        .or(`participant_one.eq.${user.id},participant_two.eq.${user.id}`);
      if (!convs) return;

      const readMap = getDMReadMap();
      let total = 0;

      await Promise.all(convs.map(async (c) => {
        const lastRead = readMap[c.id] || 0;
        const lastMsgAt = c.last_message_at ? new Date(c.last_message_at).getTime() : 0;
        // If user has read this conv after the last message was sent, skip counting
        if (lastRead >= lastMsgAt) return;

        const { count } = await supabase.from('direct_messages')
          .select('id', { count: 'exact', head: true })
          .eq('conversation_id', c.id)
          .neq('sender_id', user.id)
          .eq('is_read', false)
          .eq('is_deleted', false);
        if ((count || 0) > 0) total += count || 0;
      }));

      if (total > prevDMs.current && prevDMs.current >= 0) playNotificationSound();
      prevDMs.current = total;
      setUnreadDMs(total);
    };
    checkDMs();
    const interval = setInterval(checkDMs, 15000);
    return () => clearInterval(interval);
  }, [user, location.pathname]);

  // When user navigates to messenger, reset badge and mark all convs read
  useEffect(() => {
    if (location.pathname === '/messenger' && user) {
      setUnreadDMs(0);
      prevDMs.current = 0;
      // Mark ALL conversations as read with timestamp NOW
      supabase.from('conversations')
        .select('id,last_message_at')
        .or(`participant_one.eq.${user.id},participant_two.eq.${user.id}`)
        .then(({ data }) => {
          if (!data) return;
          const map = getDMReadMap();
          const nowTs = Date.now() + 5000; // +5s buffer so badge won't re-appear immediately
          data.forEach(c => { map[c.id] = nowTs; });
          setDMReadMap(map);
        });
    }
  }, [location.pathname, user]);

  const hasVIP = isAdmin || (profile ? isVIPActive(profile) : false);
  const hasBlueTick = isAdmin || profile?.blue_tick || hasVIP;
  const badgeStyle = ((profile as any)?.badge_style as import('@/types').BadgeStyle) || 'blue_shield';
  const displayName = profile?.full_name || profile?.username || user?.username || '';

  if (
    location.pathname === '/vip' ||
    location.pathname === '/messenger' ||
    location.pathname.startsWith('/courses/') ||
    !showHeader
  ) return null;

  const headerBg = theme === 'light' ? 'rgba(255,255,255,0.92)' : 'rgba(10,11,18,0.90)';
  const borderColor = theme === 'light' ? 'rgba(0,0,0,0.08)' : 'rgba(255,255,255,0.07)';

  return (
    <>
      <header
        className="fixed top-0 left-0 right-0 z-50"
        style={{
          background: headerBg,
          backdropFilter: 'blur(20px)',
          WebkitBackdropFilter: 'blur(20px)',
          borderBottom: `1px solid ${borderColor}`,
        }}
      >
        <div className="flex items-center px-3 h-14 max-w-lg mx-auto gap-2">

          {/* ── LEFT: Profile avatar + name + badge ── */}
          {user ? (
            <button
              onClick={() => navigate('/settings')}
              className="flex items-center gap-1.5 flex-shrink-0 press min-w-0"
              style={{ maxWidth: '42%' }}
            >
              <div className="w-8 h-8 rounded-full overflow-hidden gradient-pink flex items-center justify-center ring-2 ring-primary/30 flex-shrink-0">
                {profile?.avatar_url
                  ? <img src={profile.avatar_url} alt="avatar" className="w-full h-full object-cover" />
                  : <span className="text-white text-xs font-black">
                      {(displayName || user.email)?.[0]?.toUpperCase()}
                    </span>
                }
              </div>
              <span
                className="font-black text-foreground truncate leading-none"
                style={{ fontSize: `${headerConfig.memberNameSize === 'xs' ? '11' : headerConfig.memberNameSize === 'sm' ? '13' : headerConfig.memberNameSize === 'md' ? '15' : '17'}px` }}
              >
                {displayName ? displayName.split(' ')[0].toUpperCase() : ''}
              </span>
              {hasBlueTick && (
                <span
                  className="flex items-center flex-shrink-0"
                  style={{
                    marginLeft:
                      headerConfig.badgeSpacing === 'tight' ? '-4px' :
                      headerConfig.badgeSpacing === 'closer' ? '-1px' :
                      headerConfig.badgeSpacing === 'wide' ? '5px' : '1px',
                    // Scale badge to match member name height
                    transform:
                      headerConfig.memberNameSize === 'xs' ? 'scale(0.65)' :
                      headerConfig.memberNameSize === 'sm' ? 'scale(0.75)' :
                      headerConfig.memberNameSize === 'md' ? 'scale(0.85)' : 'scale(1.0)',
                    transformOrigin: 'left center',
                  }}
                >
                  <VIPBadge size="sm" badgeStyle={badgeStyle} />
                </span>
              )}
            </button>
          ) : (
            <button
              onClick={() => navigate('/auth')}
              className="flex items-center gap-1 px-3 py-1.5 bg-muted/70 border border-border rounded-xl text-foreground text-xs font-bold press flex-shrink-0"
            >
              <Shield className="w-3.5 h-3.5 text-muted-foreground" />
              <span>LOGIN / SIGNUP</span>
            </button>
          )}

          {/* ── CENTER: Logo ── */}
          <Link
            to="/"
            className={`flex-1 flex items-center min-w-0 px-1 ${
              headerConfig.logoPosition === 'left' ? 'justify-start' :
              headerConfig.logoPosition === 'right' ? 'justify-end' : 'justify-center'
            }`}
          >
            <span
              className="font-black tracking-tight leading-none whitespace-nowrap"
              style={{
                fontSize: `${headerConfig.logoFontSize || 13}px`,
                ...(headerConfig.logoFontStyle === 'gradient' ? {
                  background: 'linear-gradient(90deg, #ffffff 0%, #ffffff 25%, #FF69B4 55%, #FF1493 100%)',
                  WebkitBackgroundClip: 'text',
                  WebkitTextFillColor: 'transparent',
                  backgroundClip: 'text',
                  filter: 'drop-shadow(0 0 8px rgba(255,20,147,0.3))',
                } : headerConfig.logoFontStyle === 'solid_pink' ? {
                  color: '#FF1493',
                } : headerConfig.logoFontStyle === 'white' ? {
                  color: '#ffffff',
                } : headerConfig.logoFontStyle === 'gold' ? {
                  background: 'linear-gradient(90deg, #f5d020 0%, #f6d365 50%, #fda085 100%)',
                  WebkitBackgroundClip: 'text',
                  WebkitTextFillColor: 'transparent',
                  backgroundClip: 'text',
                } : {
                  background: 'linear-gradient(90deg, #ffffff 0%, #ffffff 25%, #FF69B4 55%, #FF1493 100%)',
                  WebkitBackgroundClip: 'text',
                  WebkitTextFillColor: 'transparent',
                  backgroundClip: 'text',
                }),
                letterSpacing: '-0.02em',
              }}
            >
              VISION AVAX FOREX
            </span>
          </Link>

          {/* ── RIGHT: Messenger + Notifications + Admin ── */}
          <div className="flex items-center gap-1.5 flex-shrink-0">
            {user && headerConfig.showMessengerIcon !== false && (
              <button
                onClick={() => {
                  if (!hasVIP) { setShowVIPSelector(true); }
                  else { navigate('/messenger'); }
                }}
                className="relative w-8 h-8 rounded-xl bg-muted/50 border border-border/60 flex items-center justify-center hover:bg-muted transition-all press"
              >
                <MessageCircle className="w-4 h-4 text-muted-foreground" />
                {unreadDMs > 0 && (
                  <span className="absolute -top-1.5 -right-1.5 min-w-[16px] h-4 gradient-pink rounded-full text-white text-[9px] font-black flex items-center justify-center px-1 pink-glow-xs">
                    {unreadDMs > 99 ? '99+' : unreadDMs}
                  </span>
                )}
              </button>
            )}

            {user && headerConfig.showBellIcon !== false && (
              <button
                onClick={() => setShowNotifications(true)}
                className="relative w-8 h-8 rounded-xl bg-muted/50 border border-border/60 flex items-center justify-center hover:bg-muted transition-all press"
              >
                <Bell className="w-4 h-4 text-muted-foreground" />
                {unreadCount > 0 && (
                  <span className="absolute -top-1.5 -right-1.5 min-w-[16px] h-4 gradient-pink rounded-full text-white text-[9px] font-black flex items-center justify-center px-1 pink-glow-xs">
                    {unreadCount > 99 ? '99+' : unreadCount}
                  </span>
                )}
              </button>
            )}

            {isAdmin && (
              <button
                onClick={() => navigate('/admin')}
                className="w-8 h-8 rounded-xl bg-primary/15 border border-primary/30 flex items-center justify-center hover:bg-primary/25 transition-all press"
                title="Admin Dashboard"
              >
                <Shield className="w-4 h-4 text-primary" />
              </button>
            )}
          </div>
        </div>
      </header>

      {showNotifications && (
        <NotificationCenter
          onClose={() => {
            setShowNotifications(false);
            setUnreadCount(0);
            prevCount.current = 0;
          }}
        />
      )}
      {showVIPSelector && <VIPPlanSelector onClose={() => setShowVIPSelector(false)} />}
    </>
  );
}
